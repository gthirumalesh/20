package com.rackspace.brm.account.model;

public class AccountBillInfo {

	protected String billinfoObj = null;
	protected long effectiveDate = 0l;
	protected long nextBillDate = 0l;
	protected long futureBillDate = 0l;
	protected String payType = null;
	protected String billingStatus = null;
	protected String exemptFromCollection = null;
	protected String scenarioObj = null;
	protected String actgFutureDom = null;
	protected String billingSegment = null;

	public String getBillingStatus() {
		return billingStatus;
	}

	public void setBillingStatus(String billingStatus) {
		this.billingStatus = billingStatus;
	}

	public String getExemptFromCollection() {
		return exemptFromCollection;
	}

	public void setExemptFromCollection(String exemptFromCollection) {
		this.exemptFromCollection = exemptFromCollection;
	}

	public String getActgFutureDom() {
		return actgFutureDom;
	}

	public void setActgFutureDom(String actgFutureDom) {
		this.actgFutureDom = actgFutureDom;
	}

	public String getBillinfoObj() {
		return billinfoObj;
	}

	public void setBillinfoObj(String billinfoObj) {
		this.billinfoObj = billinfoObj;
	}

	public long getEffectiveDate() {
		return effectiveDate;
	}

	public void setEffectiveDate(long effectiveDate) {
		this.effectiveDate = effectiveDate;
	}

	public long getNextBillDate() {
		return nextBillDate;
	}

	public void setNextBillDate(long nextBillDate) {
		this.nextBillDate = nextBillDate;
	}

	public long getFutureBillDate() {
		return futureBillDate;
	}

	public void setFutureBillDate(long futureBillDate) {
		this.futureBillDate = futureBillDate;
	}

	public String getPayType() {
		return payType;
	}

	public void setPayType(String payType) {
		this.payType = payType;
	}

	public String getScenarioObj() {
		return scenarioObj;
	}

	public void setScenarioObj(String scenarioObj) {
		this.scenarioObj = scenarioObj;
	}

	public String getBillingSegment() {
		return billingSegment;
	}

	public void setBillingSegment(String billingSegment) {
		this.billingSegment = billingSegment;
	}

}
