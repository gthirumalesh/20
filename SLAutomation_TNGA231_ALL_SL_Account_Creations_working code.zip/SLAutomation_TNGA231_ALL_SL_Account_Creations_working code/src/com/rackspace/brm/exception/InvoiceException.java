package com.rackspace.brm.exception;

/**
 * InvoiceException is a custom exception will throw exception while doing
 * Invoice Generation.
 * 
 */
public class InvoiceException extends Exception {

	/**
	 * The Constant serialVersionUID. The serialVersionUID is used as a version
	 * control in a Serializable class. If you do not explicitly declare a
	 * serialVersionUID, JVM will do it for you automatically, based on various
	 * aspects of your Serializable class
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * Constructor of InvoiceException, exception class here copying the message
	 * that we are passing while throwing the exception to a string and then
	 * displaying that string along with the message.
	 * 
	 * @param message
	 *            display the message which passing
	 * @param cause
	 *            display the cause
	 */

	public InvoiceException(String message, Throwable cause) {
		super(message, cause);

	}

	/**
	 * Constructor of InvoiceException, exception class here copying the message
	 * that we are passing while throwing the exception to a string and then
	 * displaying that string along with the message.
	 * 
	 * @param message
	 *            display the message which passing
	 */
	public InvoiceException(String message) {
		super(message);
	}

	/**
	 * Constructor of InvoiceException, exception class here copying the cause
	 * that we are passing while throwing the exception .
	 *
	 * @param cause
	 *            display the reason
	 */
	public InvoiceException(Throwable cause) {
		super(cause);
	}

}
