package com.rackspace.sl.event.builder;

import com.rackspace.sl.event.constants.EventConstants.EventType;
import com.rackspace.sl.event.model.Event;

/**
 * The Class TemplateBuilder.
 */
public class EventBuilder {

	private Event event = null;

	/**
	 * Instantiates a new event builder.
	 *
	 * @param eventType
	 *            the event type
	 * @param templateID
	 *            the template ID
	 */
	public EventBuilder(EventType eventType, String templateID) {

		event = new Event();
		event.setTemplateType(templateID);
		event.setEventtype(eventType);

	}

	public EventBuilder(EventType eventType, String templateID, String notificationID) {

		event = new Event();
		event.setTemplateType(templateID);
		event.setEventtype(eventType);
		event.setNotificationID(notificationID);

	}
	/**
	 * Gets the Event.
	 *
	 * @return the Event
	 */
	public Event getEvent() {
		return this.event;
	}

}
