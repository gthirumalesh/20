package com.rackspace.sl.event.constants;

// TODO: Auto-generated Javadoc
/**
 * The Class TemplateConstants.
 */
public class EventConstants {

	/** The Constant BSL_SYSTEM_ROLE_URL. */
	public static final String GET_TEMPLATE_BY_ID = "https://$env.bazooka.api.rackspacecloud.com/v1/templates/";

	/** The Constant GET_NOTIFICATION_URL. */
	public static final String GET_NOTIFICATION_URL = "https://$env.bazooka.api.rackspacecloud.com/v1/templates/$templateID/notifications/$notificationID";

	/**
	 * The Enum EventType.
	 */
	public enum EventType {

		/** The get notification. */
		GET_NOTIFICATION,
		/** The get template id. */
		GET_TEMPLATE_ID,
		/** The post notification. */
		POST_NOTIFICATION

	}

	/**
	 * The Enum TemplateIDType.
	 */
	public enum TemplateType {

		/** The billing expiry cc. */
		BILLING_EXPIRY_CC,

		/** The billing predraft notification. */
		BILLING_PREDRAFT_NOTIFICATION,

		/** The billing primary method changed. */
		BILLING_PRIMARY_METHOD_CHANGED,

		/** The billing payment success cc. */
		BILLING_PAYMENT_SUCCESS_CC,

		/** The billing problem charge cc. */
		BILLING_PROBLEM_CHARGE_CC,

		/** The billing problem charge ach. */
		BILLING_PROBLEM_CHARGE_ACH,

		/** The email statement pdf. */
		EMAIL_STATEMENT_PDF,

		/** The spend threshold limit. */
		SPEND_THRESHOLD_LIMIT,

		/** The creditmemo notification. */
		CREDITMEMO_NOTIFICATION,

		/** The email invoice pdf. */
		EMAIL_INVOICE_PDF,

		/** The email invoice pdf tc. */
		EMAIL_INVOICE_PDF_TC,

		/** The expiry cc notification. */
		EXPIRY_CC_NOTIFICATION,

		/** The billing payment init ach. */
		BILLING_PAYMENT_INIT_ACH,

		/** The sepa payment failed. */
		SEPA_PAYMENT_FAILED,

		/** The sepa payment initiated. */
		SEPA_PAYMENT_INITIATED,

		/** The ukdd mandate rejection. */
		UKDD_MANDATE_REJECTION,

		/** The ukdd payment failed. */
		UKDD_PAYMENT_FAILED,

		/** The ukdd payment initiated. */
		UKDD_PAYMENT_INITIATED,

		/** The ukdd payment method activation. */
		UKDD_PAYMENT_METHOD_ACTIVATION,
		
		/** The billing refund alert. */
		BILLING_REFUND_ALERT

	}

	/**
	 * The Enum NotificationStatus.
	 */
	public enum NotificationStatus {

		/** The pending. */
		PENDING_STATUS("PENDING"),

		/** The delivered. */
		DELIVERED_STATUS("DELIVERED");

		/**
		 * The contracting entity variable represents the contracting entity.
		 */
		private String notificationStatus = null;

		/**
		 * Instantiates a new notification status.
		 *
		 * @param notificationStatus the notification status
		 */
		private NotificationStatus(String notificationStatus) {
			this.notificationStatus = notificationStatus;
		}

		/**
		 * Gets the notification status.
		 *
		 * @return the notification status
		 */
		public String getNotificationStatus() {
			return this.notificationStatus;
		}

	}

}
