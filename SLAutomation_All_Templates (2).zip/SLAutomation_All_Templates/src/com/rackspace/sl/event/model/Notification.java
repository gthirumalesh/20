
package com.rackspace.sl.event.model;

import java.util.List;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Notification {

    @SerializedName("notificationId")
    @Expose
    private String notificationId;
    @SerializedName("publishedDate")
    @Expose
    private String publishedDate;
    @SerializedName("notificationHTML")
    @Expose
    private String notificationHTML;
    @SerializedName("parameters")
    @Expose
    private Parameters parameters;
    @SerializedName("attachments")
    @Expose
    private List<Object> attachments = null;
    @SerializedName("originSystem")
    @Expose
    private String originSystem;
    @SerializedName("sender")
    @Expose
    private String sender;
    @SerializedName("recipients")
    @Expose
    private List<Recipient> recipients = null;

    public String getNotificationId() {
        return notificationId;
    }

    public void setNotificationId(String notificationId) {
        this.notificationId = notificationId;
    }

    public String getPublishedDate() {
        return publishedDate;
    }

    public void setPublishedDate(String publishedDate) {
        this.publishedDate = publishedDate;
    }

    public String getNotificationHTML() {
        return notificationHTML;
    }

    public void setNotificationHTML(String notificationHTML) {
        this.notificationHTML = notificationHTML;
    }

    public Parameters getParameters() {
        return parameters;
    }

    public void setParameters(Parameters parameters) {
        this.parameters = parameters;
    }

    public List<Object> getAttachments() {
        return attachments;
    }

    public void setAttachments(List<Object> attachments) {
        this.attachments = attachments;
    }

    public String getOriginSystem() {
        return originSystem;
    }

    public void setOriginSystem(String originSystem) {
        this.originSystem = originSystem;
    }

    public String getSender() {
        return sender;
    }

    public void setSender(String sender) {
        this.sender = sender;
    }

    public List<Recipient> getRecipients() {
        return recipients;
    }

    public void setRecipients(List<Recipient> recipients) {
        this.recipients = recipients;
    }

}
