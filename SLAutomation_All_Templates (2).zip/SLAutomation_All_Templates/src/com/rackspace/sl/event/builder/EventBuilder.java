package com.rackspace.sl.event.builder;

import com.rackspace.sl.event.constants.EventConstants.EventType;
import com.rackspace.sl.event.model.Event;

/**
 * The Class TemplateBuilder.
 */
public class EventBuilder {

	private Event event = null;

	/**
	 * Instantiates a new event builder.
	 *
	 * @param eventType
	 *            the event type
	 * @param templateID
	 *            the template ID
	 */
	public EventBuilder(EventType eventType, String templateID, String payType,String poid) {

		event = new Event();
		event.setTemplateType(templateID);
		event.setEventtype(eventType);
		event.setPayType(payType);
		event.setPoid(poid);

	}

	
	/**
	 * Gets the Event.
	 *
	 * @return the Event
	 */
	public Event getEvent() {
		return this.event;
	}

}
