package com.rackspace.sl.constants;

/**
 * The Class SLConstants.
 */
public class SLConstants {

	/** The Constant POST. */
	public static final String POST = "POST";

	/** The Constant GET. */
	public static final String GET = "GET";
	
	/** The Constant PUT. */
	public static final String PUT = "PUT";

	/** The Constant ACCEPT_APPLICATION_JSON. */
	public static final String ACCEPT_APPLICATION_JSON = "application/json";

	/** The Constant CONTENT_TYPE_APPLICATION_JSON. */
	public static final String CONTENT_TYPE_APPLICATION_JSON = "application/json";

	/** The Constant ACCEPT_APPLICATION_XML. */
	public static final String ACCEPT_APPLICATION_XML = "application/xml";

	/** The Constant CONTENT_TYPE_APPLICATION_XML. */
	public static final String CONTENT_TYPE_APPLICATION_XML = "application/xml";
	
	/** The Constant ENVIORNMENT. */
	public static final String ENVIORNMENT = "enviornment";

	/** The Constant NOTIFICATION_QUERY. */
	public static final String NOTIFICATION_QUERY = "notificationQuery";

	/** The Constant BILLING_PRIMARY_METHOD_CHANGED_FILE_PATH. */
	public static final String BILLING_PRIMARY_METHOD_CHANGED_FILE_PATH = "src/com/rackspace/brm/account/templates/BILLING_PRIMARY_METHOD_CHANGED.nap";

	/** The Constant BILLING_PROBLEM_CHARGE_CC_FILE_PATH. */
	public static final String BILLING_PROBLEM_CHARGE_CC_FILE_PATH = "src/com/rackspace/brm/account/templates/BILLING_PROBLEM_CHARGE_CC.nap";

	/** The Constant BILLING_PROBLEM_CHARGE_ACH_FILE_PATH. */
	public static final String BILLING_PROBLEM_CHARGE_ACH_FILE_PATH = "src/com/rackspace/brm/account/templates/BILLING_PROBLEM_CHARGE_ACH.nap";

	/** The Constant SPEND_THRESHOLD_LIMIT_FILE_PATH. */
	public static final String SPEND_THRESHOLD_LIMIT_FILE_PATH = "src/com/rackspace/brm/account/templates/SPEND_THRESHOLD_LIMIT.nap";

	/** The Constant BILLING_PREDRAFT_NOTIFICATION_FILE_PATH. */
	public static final String BILLING_PREDRAFT_NOTIFICATION_FILE_PATH = "src/com/rackspace/brm/account/templates/BILLING_PREDRAFT_NOTIFICATION.nap";

	/** The Constant BILLING_EXPIRY_CC_FILE_PATH. */
	public static final String BILLING_EXPIRY_CC_FILE_PATH = "src/com/rackspace/brm/account/templates/BILLING_EXPIRY_CC.nap";

	/** The Constant EMAIL_INVOICE_PDF_FILE_PATH. */
	public static final String EMAIL_INVOICE_PDF_FILE_PATH = "src/com/rackspace/brm/account/templates/EMAIL_INVOICE_PDF.nap";

	/** The Constant BILLING_PAYMENT_SUCCESS_CC_FILE_PATH. */
	public static final String BILLING_PAYMENT_SUCCESS_CC_FILE_PATH = "src/com/rackspace/brm/account/templates/BILLING_PAYMENT_SUCCESS_CC.nap";

	/** The Constant EXPIRY_CC_NOTIFICATION_FILE_PATH. */
	public static final String EXPIRY_CC_NOTIFICATION_FILE_PATH = "src/com/rackspace/brm/account/templates/EXPIRY_CC_NOTIFICATION.nap";

	/** The Constant BILLING_PAYMENT_INIT_ACH_FILE_PATH. */
	public static final String BILLING_PAYMENT_INIT_ACH_FILE_PATH = "src/com/rackspace/brm/account/templates/BILLING_PAYMENT_INIT_ACH.nap";

	/** The Constant SEPA_PAYMENT_FAILED_FILE_PATH. */
	public static final String SEPA_PAYMENT_FAILED_FILE_PATH = "src/com/rackspace/brm/account/templates/SEPA_PAYMENT_FAILED.nap";

	/** The Constant SEPA_PAYMENT_INITIATED_FILE_PATH. */
	public static final String SEPA_PAYMENT_INITIATED_FILE_PATH = "src/com/rackspace/brm/account/templates/SEPA_PAYMENT_INITIATED.nap";

	/** The Constant UKDD_MANDATE_REJECTION_FILE_PATH. */
	public static final String UKDD_MANDATE_REJECTION_FILE_PATH = "src/com/rackspace/brm/account/templates/UKDD_MANDATE_REJECTION.nap";

	/** The Constant UKDD_PAYMENT_FAILED_FILE_PATH. */
	public static final String UKDD_PAYMENT_FAILED_FILE_PATH = "src/com/rackspace/brm/account/templates/UKDD_PAYMENT_FAILED.nap";

	/** The Constant UKDD_PAYMENT_INITIATED_FILE_PATH. */
	public static final String UKDD_PAYMENT_INITIATED_FILE_PATH = "src/com/rackspace/brm/account/templates/UKDD_PAYMENT_INITIATED.nap";

	/** The Constant UKDD_PAYMENT_METHOD_ACTIVATION_FILE_PATH. */
	public static final String UKDD_PAYMENT_METHOD_ACTIVATION_FILE_PATH = "src/com/rackspace/brm/account/templates/UKDD_PAYMENT_METHOD_ACTIVATION.nap";

	/** The Constant BILLING_REFUND_ALERT_FILE_PATH. */
	public static final String BILLING_REFUND_ALERT_FILE_PATH = "src/com/rackspace/brm/account/templates/BILLING_REFUND_ALERT.nap";


	/** The Constant SEPA_FLIST_OUT_FILE. */
	public static final String FLIST_OUT_FILE = "Flist.out";

	/** The Constant DEDICATED_ACCT_CREATE_JSON_FILE_PATH. */
	public static final String DEDICATED_ACCT_CREATE_JSON_FILE_PATH = "src/com/rackspace/brm/account/templates/CreateDedicatedUSAccount.json";

	/** The Constant CREATE_DEDICATED_SL_ACCOUNT_URI. */
	public static final String CREATE_DEDICATED_SL_ACCOUNT_URI = "https://$env.billingv2.api.rackspacecloud.com/v2/accounts";

	/** The Constant GET_ACCOUNT. */
	public static final String GET_ACCOUNT = "https://$env.billingv2.api.rackspacecloud.com/v2/accounts/$accountNumber";

	/** The Constant CREATE_SL_ACCOUNT_URI. */
	public static final String CREATE_SL_ACCOUNT_URI = "https://$env.billingv2.api.rackspacecloud.com/v2/accounts";

	/** The Constant CREATE_UK_CLOUD_SL_ACCOUNT_URI. */
	public static final String CREATE_UK_CLOUD_SL_ACCOUNT_URI = "https://$env.billingv2.api.rackspacecloud.com/v2/accounts";

	/** The Constant US_CLOUD_ACCT_CREATE_JSON_FILE_PATH. */
	public static final String US_CLOUD_ACCT_CREATE_JSON_FILE_PATH = "src/com/rackspace/brm/account/templates/US_CLOUD_JSON_FILE.json";

	/** The Constant UK_CLOUD_ACCT_CREATE_JSON_FILE_PATH. */
	public static final String UK_CLOUD_ACCT_CREATE_JSON_FILE_PATH = "src/com/rackspace/brm/account/templates/UK_CLOUD_JSON_FILE.json";

}
