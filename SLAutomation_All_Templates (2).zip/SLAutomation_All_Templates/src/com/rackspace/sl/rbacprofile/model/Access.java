
package com.rackspace.sl.rbacprofile.model;

import java.util.List;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/**
 * The Class Access.
 */
public class Access {

    /** The service catalog. */
    @SerializedName("serviceCatalog")
    @Expose
    private List<ServiceCatalog> serviceCatalog = null;
    
    /** The user. */
    @SerializedName("user")
    @Expose
    private User user;
    
    /** The token. */
    @SerializedName("token")
    @Expose
    private Token token;

    /**
     * Gets the service catalog.
     *
     * @return the service catalog
     */
    public List<ServiceCatalog> getServiceCatalog() {
        return serviceCatalog;
    }

    /**
     * Sets the service catalog.
     *
     * @param serviceCatalog the new service catalog
     */
    public void setServiceCatalog(List<ServiceCatalog> serviceCatalog) {
        this.serviceCatalog = serviceCatalog;
    }

    /**
     * Gets the user.
     *
     * @return the user
     */
    public User getUser() {
        return user;
    }

    /**
     * Sets the user.
     *
     * @param user the new user
     */
    public void setUser(User user) {
        this.user = user;
    }

    /**
     * Gets the token.
     *
     * @return the token
     */
    public Token getToken() {
        return token;
    }

    /**
     * Sets the token.
     *
     * @param token the new token
     */
    public void setToken(Token token) {
        this.token = token;
    }

}
