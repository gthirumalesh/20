
package com.rackspace.sl.rbacprofile.action;

import com.rackspace.sl.globalauth.dao.GlobalAuthDAO;
import com.rackspace.sl.rbacprofile.model.RBACProfile;

import io.restassured.mapper.ObjectMapperType;
import io.restassured.response.Response;

/**
 * The Class RBACprofileAction.
 */
public class RBACProfileAction {
	
	/**
	 * Gets the token.
	 *
	 * @param ipRBACprofile the ip RBA cprofile
	 * @return the token
	 * @throws Exception the exception
	 */
	public RBACProfile getToken(RBACProfile ipRBACprofile) throws Exception {
		
		GlobalAuthDAO globalAuthDAO;
		
		switch (ipRBACprofile.getRbacProfileType()) {
		case BSL_SYSTEM_ROLE:
			
			globalAuthDAO = new GlobalAuthDAO();
			
			ipRBACprofile = globalAuthDAO.getToken(ipRBACprofile);
			
		case PROMOTION_AUTH:
			break;
		
		}
		
		return ipRBACprofile;
		
	}
	
}
