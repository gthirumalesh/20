package com.rackspace.brm.account.model;

public class InvoiceServiceSummary {

	protected String service = null;
	protected double grossCharge = 0.0d;
	protected double discountAmount = 0.0d;
	protected double netCharge = 0.0d;
	protected double taxes = 0.0d;
	protected double totalCharge = 0.0d;

	public String getService() {
		return service;
	}

	public void setService(String service) {
		this.service = service;
	}

	public double getGrossCharge() {
		return grossCharge;
	}

	public void setGrossCharge(double grossCharge) {
		this.grossCharge = grossCharge;
	}

	public double getDiscountAmount() {
		return discountAmount;
	}

	public void setDiscountAmount(double discountAmount) {
		this.discountAmount = discountAmount;
	}

	public double getNetCharge() {
		return netCharge;
	}

	public void setNetCharge(double netCharge) {
		this.netCharge = netCharge;
	}

	public double getTaxes() {
		return taxes;
	}

	public void setTaxes(double taxes) {
		this.taxes = taxes;
	}

	public double getTotalCharge() {
		return totalCharge;
	}

	public void setTotalCharge(double totalCharge) {
		this.totalCharge = totalCharge;
	}
}
