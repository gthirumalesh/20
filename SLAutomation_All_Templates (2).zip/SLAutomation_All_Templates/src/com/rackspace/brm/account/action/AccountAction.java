package com.rackspace.brm.account.action;

import com.portal.pcm.FList;
import com.rackspace.brm.account.dao.DedicatedAccountDAO;
import com.rackspace.brm.account.model.Account;
import com.rackspace.brm.common.BRMUtils;
import com.rackspace.brm.common.Utils;

/**
 * The Class AccountAction is for business logic account action methods.
 */
public class AccountAction {

	/**
	 * Instantiates a new account action.
	 */

	/**
	 * Default constructor to instantiate an object
	 */
	public AccountAction() {

	}

	/**
	 * Creates the account.
	 *
	 * @param ipAccount the ip account
	 * @return the account
	 * @throws Exception the exception
	 */
	public Account createAccount(Account ipAccount) throws Exception {
		Account opAccount = null;
		switch (ipAccount.getAccountType()) {
		case DEDICATED:
			DedicatedAccountDAO dedicatedAccountDAO = new DedicatedAccountDAO();
			opAccount = dedicatedAccountDAO.createCustomerAccountInBRM(ipAccount);
		case US_CLOUD:
			break;
		case UK_CLOUD:
			break;
			
		}
		return opAccount;
	}
	
	/**
	 * Mapping of two accounts.
	 * 
	 * @param parent
	 *            the parent
	 * @param child
	 *            the child
	 */
	public void mappingOfTwoAccounts(String parent, String child) {
		try {
			DedicatedAccountDAO dedicatedAccountDAO = new DedicatedAccountDAO();
			String flistData = BRMUtils.buildInputMappingFlist(parent, child);
			FList outFlist = dedicatedAccountDAO.consolidateCustomerAccountInBRM(flistData);

		} catch (Exception e) {
			Utils.APP_LOGS.error(e);
		}

	}
	
	
}
