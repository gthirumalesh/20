package com.rackspace.brm.common.model;

/**
 * The Class CommandObject.
 */
public class CommandObject {

	/** The type. */
	private String type = null;

	/** The command. */
	private String command = null;

	/** The optional parameters. */
	private String optionalParameters = null;

	/** The std out. */
	private String stdOut = null;

	/** The std err. */
	private String stdErr = null;

	/**
	 * Instantiates a new command object.
	 */
	public CommandObject() {
	}

	/**
	 * Gets the type.
	 *
	 * @return the type
	 */
	public String getType() {
		return type;
	}

	/**
	 * Sets the type.
	 *
	 * @param type
	 *            the new type
	 */
	public void setType(String type) {
		this.type = type;
	}

	/**
	 * Gets the command.
	 *
	 * @return the command
	 */
	public String getCommand() {
		return command;
	}

	/**
	 * Sets the command.
	 *
	 * @param command
	 *            the new command
	 */
	public void setCommand(String command) {
		this.command = command;
	}

	/**
	 * Gets the optional parameters.
	 *
	 * @return the optional parameters
	 */
	public String getOptionalParameters() {
		return optionalParameters;
	}

	/**
	 * Sets the optional parameters.
	 *
	 * @param optionalParameters
	 *            the new optional parameters
	 */
	public void setOptionalParameters(String optionalParameters) {
		this.optionalParameters = optionalParameters;
	}

	/**
	 * Gets the std out.
	 *
	 * @return the std out
	 */
	public String getStdOut() {
		return stdOut;
	}

	/**
	 * Sets the std out.
	 *
	 * @param stdOut
	 *            the new std out
	 */
	public void setStdOut(String stdOut) {
		this.stdOut = stdOut;
	}

	/**
	 * Gets the std err.
	 *
	 * @return the std err
	 */
	public String getStdErr() {
		return stdErr;
	}

	/**
	 * Sets the std err.
	 *
	 * @param stdErr
	 *            the new std err
	 */
	public void setStdErr(String stdErr) {
		this.stdErr = stdErr;
	}

}
