package com.rackspace.brm.connection;

import java.util.Properties;

import org.apache.log4j.Logger;

import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;
import com.rackspace.brm.common.PropertyUtil;
import com.rackspace.brm.common.Utils;

public class BRMJSchConnection {

	private static volatile boolean isInitialized = false;
	private static Session session = null;

	private BRMJSchConnection() {

	}

	// getting the Session object to connect putty
	public static synchronized Session getJschSession() {
		if (!isInitialized) {

			Utils.APP_LOGS.info("Entered into getJschSession");
			try {
				JSch jsch = new JSch();
				Properties properties = PropertyUtil.getCommonProperties();
				String host = properties.getProperty("hostname");
				System.out.println("Host:" + host);
				String username = properties.getProperty("username");
				System.out.println("Username:" + username);
				String passwd = properties.getProperty("Password");
				System.out.println("Password:" + passwd);
				session = jsch.getSession(username, host, 22);
				session.setConfig("StrictHostKeyChecking", "no");
				session.setPassword(passwd);
				System.out.println("Session:"+session);
				session.connect();
				isInitialized = true;

			} catch (JSchException e) {
				Utils.APP_LOGS.error("JSch connection can not initialiZed."
						+ "Please check before proceeding to execute test cases");
			}

		}
		return session;
	}

	public static void main(String[] args) throws Exception {
		System.out.println(BRMJSchConnection.getJschSession());
		System.out.println(BRMJSchConnection.getJschSession());
		System.out.println(BRMJSchConnection.getJschSession());
	}
}
