
package com.rackspace.sl.event.model;


public class Parameters {


}
