package com.rackspace.sl.payment.dao;

import java.io.IOException;
import java.io.StringWriter;

import org.apache.velocity.Template;
import org.apache.velocity.VelocityContext;
import org.apache.velocity.app.VelocityEngine;

import com.portal.pcm.EBufException;
import com.rackspace.brm.account.model.Account;
import com.rackspace.brm.common.PropertyUtil;
import com.rackspace.sl.connection.RestAPIConnection;
import com.rackspace.sl.constants.SLConstants;
import com.rackspace.sl.payment.constants.PaymentConstants;
import com.rackspace.sl.payment.model.MethodResponse;
import com.rackspace.sl.payment.model.Payment;
import com.rackspace.sl.payment.model.PaymentCard;
import com.rackspace.sl.payment.model.PaymentResponse;
import com.rackspace.sl.paymentmodel.model.PaymentDetail;
import com.rackspace.sl.rbacprofile.model.RBACProfile;

import io.restassured.mapper.ObjectMapperType;
import io.restassured.response.Response;

// TODO: Auto-generated Javadoc
/**
 * The Class PaymentDAO.
 */
public class PaymentDAO {

	/** The input string json. */
	String inputStringJson = null;

	/**
	 * Creates the CC method.
	 *
	 * @param ipPaymentCard the ip payment card
	 * @param rbacProfile the rbac profile
	 * @param opAccount the op account
	 * @return the payment card
	 * @throws Exception the exception
	 */
	/*
	 * ACH method
	 */
	public PaymentCard createCCMethod(PaymentCard ipPaymentCard, RBACProfile rbacProfile, Account opAccount)
			throws Exception {
		/*
		 * create ACH method
		 */
		String inputStringJSON = prepareAuthXMLfile(ipPaymentCard, rbacProfile, opAccount);

		String uri = PaymentConstants.GET_PSL_CC_ACCOUNT
				.replace("$env", PropertyUtil.getBslProperties().getProperty(SLConstants.ENVIORNMENT))
				.replace("$accountNumber", opAccount.getAccountNumber());

		System.out.println("PayamentURIPath**createCCMethod**" + uri);
		System.out.println("AccountNumber===createCCMethod===" + opAccount.getAccountNumber());

		Response response = RestAPIConnection.executeGetRestAPIConnectionPostWithToken(uri,
				SLConstants.ACCEPT_APPLICATION_JSON, SLConstants.CONTENT_TYPE_APPLICATION_JSON, rbacProfile.getToken(),
				inputStringJSON);

		System.out.println("Rest API call end \n");

		System.out.println("RestAPiResponsecode***createACHMethod***" + response.getStatusCode());
		System.out.println("PAYMENT_ADD_CC METHOD Response FROM REST API" + response.getBody().asString());

		// Notification notificationJSONParser = response.as(Notification.class,
		// ObjectMapperType.GSON);

		Payment payment = response.as(Payment.class, ObjectMapperType.GSON);
		// PaymentResponse paymentResponse = response.as(PaymentResponse.class,
		// ObjectMapperType.GSON);
		PaymentDetail methodResponse = response.as(PaymentDetail.class, ObjectMapperType.GSON);

		System.out.println("HolderName ======" + payment.getMethod().getPaymentCard().getCardHolderName());
		System.out.println("cardNaumber ======" + payment.getMethod().getPaymentCard().getCardNumber());
		System.out.println("cardType ======" + payment.getMethod().getPaymentCard().getCardType());
		System.out.println("cardVerificationNumber ======" + ipPaymentCard.getCardVerificationNumber());
		System.out.println("ExpireDate ======" + payment.getMethod().getPaymentCard().getExpirationDate());

		// System.out.println("methodID ======" +
		// payment.getMethod().getPaymentCard().getPaymentResponse().getMethodResponse().getId());

		// System.out.println("methodID ====== " +
		// paymentResponse.getMethodResponse().getId());
		System.out.println("methodID === " + methodResponse.getMethod().getId());

		// ipElectronicCheck.setMethodid(paymentResponse.getMethodResponse().getId());

		System.out.println("status code for response: " + response.getStatusCode());

		// ipPaymentCard.setPaymentResponse(paymentResponse);
		ipPaymentCard.setUrnID(methodResponse.getMethod().getId());
		ipPaymentCard.setResponseCode(response.getStatusCode());
		// String id = ipPaymentCard.getMethodResponse().getId();
		// System.out.println("=id=" + id);
		return ipPaymentCard;

	}

	/*
	 * finalized method creation prepareXMLfile
	 */

	/**
	 * Prepare auth XM lfile.
	 *
	 * @param ipPaymentCard the ip payment card
	 * @param rbacProfile the rbac profile
	 * @param opAccount the op account
	 * @return the string
	 * @throws Exception the exception
	 */
	private String prepareAuthXMLfile(PaymentCard ipPaymentCard, RBACProfile rbacProfile, Account opAccount)
			throws Exception {

		String opcTemplate = SLConstants.CREATE_CC_METHOD_FILE_PATH;

		VelocityEngine velocityEngine = new VelocityEngine();
		StringWriter writer = null;
		try {
			velocityEngine.init();

			// next, get the Template
			Template template = velocityEngine.getTemplate(opcTemplate);
			// create a context and add data
			VelocityContext velocityContext = new VelocityContext();

			velocityContext.put("CardHolderName", ipPaymentCard.getCardHolderName());
			velocityContext.put("CardNumber", ipPaymentCard.getCardNumber());
			velocityContext.put("CardTyp", ipPaymentCard.getCardType());
			velocityContext.put("ExpirationDate", ipPaymentCard.getExpirationDate());
			velocityContext.put("CardVerificationNumber", ipPaymentCard.getCardVerificationNumber());

			// now render the template into a StringWriter
			writer = new StringWriter();
			template.merge(velocityContext, writer);

		} catch (Exception ex) {
			throw new Exception("Error occured while preparing flist string using velocity template builder", ex);
		}
		// CREATING CUST COMMIT NAP FILE IN LOCAL DIRECTORY FOR REFERENCE
		System.out.println("CREATE_CC_METHOD JSON FILE \n" + writer.toString());
		return writer.toString();

	}

	/**
	 * Do put default method.
	 *
	 * @param ipPaymentCard the ip payment card
	 * @param myRBACprofile the my RBA cprofile
	 * @param ipAccount the ip account
	 * @return the payment card
	 * @throws Exception the exception
	 */
	public PaymentCard doPutDefaultMethod(PaymentCard ipPaymentCard, RBACProfile myRBACprofile, Account ipAccount)
			throws Exception {

		String inputStringJson = this.preparePutDefaultMethodJsonString(ipAccount, ipPaymentCard, myRBACprofile);

		String uri = PaymentConstants.GET_PSL_SET_DEFAULT_METHOD
				.replace("$env", PropertyUtil.getBslProperties().getProperty(SLConstants.ENVIORNMENT))
				.replace("$accountNumber", ipAccount.getAccountNumber());
		System.out.println("setDefaultMethod uri =====" + uri);
		Response response = RestAPIConnection.executePutRestAPIConnectionWithToken(uri,
				SLConstants.ACCEPT_APPLICATION_JSON, SLConstants.CONTENT_TYPE_APPLICATION_JSON,
				myRBACprofile.getToken(), inputStringJson);
		// System.out.println("response ===" + response);

		Payment payment = response.as(Payment.class, ObjectMapperType.GSON);
		// PaymentResponse paymentResponse = response.as(PaymentResponse.class,
		// ObjectMapperType.GSON);
		MethodResponse methodResponse = response.as(MethodResponse.class, ObjectMapperType.GSON);

		// System.out.println("ipElectronicCheck.getUrnID()=======
		// "+payment.getPaymentResponse().getMethodResponse().getId());
		// System.out.println("Token ===== " + myRBACprofile.getToken());
		System.out.println("=====AccountNumber======  " + ipAccount.getAccountNumber());
		System.out.println("Response Code doPutDefaultMethod ==== " + response.getStatusCode());
		ipPaymentCard.setMethodResponse(methodResponse);

		ipPaymentCard.setResponseCode(response.getStatusCode());
		return ipPaymentCard;

	}

	/*
	 * setDefault method
	 */

	/**
	 * Prepare put default method json string.
	 *
	 * @param ipAccount the ip account
	 * @param ipPaymentCard the ip payment card
	 * @param myRBACprofile the my RBA cprofile
	 * @return the string
	 * @throws Exception the exception
	 */
	private String preparePutDefaultMethodJsonString(Account ipAccount, PaymentCard ipPaymentCard,
			RBACProfile myRBACprofile) throws Exception {

		String opcTemplate = SLConstants.SET_DEFAULT_PAYMENT_METHOD_FILE_PATH;

		VelocityEngine velocityEngine = new VelocityEngine();
		StringWriter writer = null;
		try {
			velocityEngine.init();

			// next, get the Template
			Template template = velocityEngine.getTemplate(opcTemplate);
			// create a context and add data
			VelocityContext velocityContext = new VelocityContext();

			// opElectronicCheck.getPaymentResponse().getMethodResponse().getId()

			velocityContext.put("URNID", ipPaymentCard.getUrnID());
			velocityContext.put("accountNumber", ipAccount.getAccountNumber());

			// now render the template into a StringWriter
			writer = new StringWriter();
			template.merge(velocityContext, writer);

		} catch (Exception ex) {
			throw new Exception("Error occured while preparing flist string using velocity template builder", ex);
		}
		// CREATING CUST COMMIT NAP FILE IN LOCAL DIRECTORY FOR REFERENCE
		System.out.println("SetDefaultMethod JsonFile  \n" + writer.toString());
		return writer.toString();
	}

	/**
	 * Sets the get default method.
	 *
	 * @param ipPaymentCard the ip payment card
	 * @param rbacProfile the rbac profile
	 * @param ipAccount the ip account
	 * @return the payment card
	 * @throws Exception the exception
	 */
	public PaymentCard setGetDefaultMethod(PaymentCard ipPaymentCard, RBACProfile rbacProfile, Account ipAccount)
			throws Exception {

		String uri = PaymentConstants.GET_PSL_SET_DEFAULT_METHOD
				.replace("$env", PropertyUtil.getBslProperties().getProperty(SLConstants.ENVIORNMENT))
				.replace("$accountNumber", ipAccount.getAccountNumber());

		System.out.println("setGetDefaultMethod.... uri ......" + uri);
		System.out.println("AccountNumber ===============" + ipAccount.getAccountNumber());

		Response response = RestAPIConnection.executeGetRestAPIConnectionWithToken(uri,
				SLConstants.ACCEPT_APPLICATION_JSON, SLConstants.CONTENT_TYPE_APPLICATION_JSON, rbacProfile.getToken(),
				"");
		System.out.println("Rest API call end\n");
		System.out.println("RESTAPIResponseData******" + response.getStatusCode());

		/*
		 * RequestSpecification httpRequest =
		 * RestAssured.given().header("X-Auth-Token", rbacProfile.getToken())
		 * .accept("application/json").contentType("application/json").body("");
		 */

		System.out.println("response************" + response.getStatusCode());

		Payment payment = response.as(Payment.class, ObjectMapperType.GSON);
		PaymentResponse paymentResponse = response.as(PaymentResponse.class, ObjectMapperType.GSON);

		// System.out.println("Method ID ==== setGetDefaultMethod ====
		// "+paymentResponse.getMethodResponse().getId());

		// ipElectronicCheck.setPaymentResponse(paymentResponse);
		System.out.println("Respose Code" + response.getStatusCode());
		ipPaymentCard.setResponseCode(response.getStatusCode());
		return ipPaymentCard;

	}

	/*
	 * Validate AccountNumber from PSL
	 */

	/**
	 * Gets the customer account in PSL.
	 *
	 * @param opAccount the op account
	 * @param rbacProfile the rbac profile
	 * @return the customer account in PSL
	 * @throws IOException Signals that an I/O exception has occurred.
	 * @throws EBufException the e buf exception
	 * @throws Exception the exception
	 */
	public int getCustomerAccountInPSL(Account opAccount, RBACProfile rbacProfile)
			throws IOException, EBufException, Exception {

		String uri = SLConstants.GET_ACCOUNT_PSL
				.replace("$env", PropertyUtil.getBslProperties().getProperty(SLConstants.ENVIORNMENT))
				.replace("$accountNumber", opAccount.getAccountNumber());

		Response response = RestAPIConnection.executeGetRestAPIConnectionWithToken(uri,
				SLConstants.ACCEPT_APPLICATION_JSON, SLConstants.CONTENT_TYPE_APPLICATION_JSON, rbacProfile.getToken(),
				"");
		System.out.println("response.getStatusCode()===validatePSLAccount===PaymentDAO===" + response.getStatusCode());
		return response.getStatusCode();

	}

	/**
	 * Validate CC method.
	 *
	 * @param rbacProfile the rbac profile
	 * @param ipAccount the ip account
	 * @return the int
	 * @throws IOException Signals that an I/O exception has occurred.
	 * @throws EBufException the e buf exception
	 * @throws Exception the exception
	 */
	/*
	 * getResponse with create CC Method from PSL
	 */
	public int validateCCMethod(RBACProfile rbacProfile, Account ipAccount)
			throws IOException, EBufException, Exception {

		String uri = PaymentConstants.GET_PSL_CC_ACCOUNT
				.replace("$env", PropertyUtil.getBslProperties().getProperty(SLConstants.ENVIORNMENT))
				.replace("$accountNumber", ipAccount.getAccountNumber());
		System.out.println("==========" + uri);
		Response response = RestAPIConnection.executeGetRestAPIConnectionWithToken(uri,
				SLConstants.ACCEPT_APPLICATION_JSON, SLConstants.CONTENT_TYPE_APPLICATION_JSON, rbacProfile.getToken(),
				"");

		System.out.println("Responsecode===validateCCMethod===PaymentDAO===" + response.getStatusCode());
		System.out.println("Rest API call end\n");

		return response.getStatusCode();
	}

	/**
	 * Validate set default method.
	 *
	 * @param opPaymentCard the op payment card
	 * @param opAccount the op account
	 * @param rbacProfile the rbac profile
	 * @return the int
	 * @throws IOException Signals that an I/O exception has occurred.
	 * @throws EBufException the e buf exception
	 * @throws Exception the exception
	 */
	/*
	 * SetDefault Method Response validation
	 */
	public int validateSetDefaultMethod(PaymentCard opPaymentCard, Account opAccount, RBACProfile rbacProfile)
			throws IOException, EBufException, Exception {
		String inputStringJson = this.preparePutDefaultMethodJsonStringResponse(opPaymentCard, opAccount, rbacProfile);
		String uri = PaymentConstants.GET_PSL_SET_DEFAULT_METHOD
				.replace("$env", PropertyUtil.getBslProperties().getProperty(SLConstants.ENVIORNMENT))
				.replace("$accountNumber", opAccount.getAccountNumber());
		System.out.println("getResponseSetDefaultMethod uri === " + uri);
		Response response = RestAPIConnection.executePutRestAPIConnectionWithToken(uri,
				SLConstants.ACCEPT_APPLICATION_JSON, SLConstants.CONTENT_TYPE_APPLICATION_JSON, rbacProfile.getToken(),
				inputStringJson);

		PaymentResponse paymentResponse = response.as(PaymentResponse.class, ObjectMapperType.GSON);
		System.out.println("MethodID ==== " + opPaymentCard.getUrnID());

		System.out.println("Rest API call end\n");
		System.out.println("RESTAPIResponse code***getResponseSetDefaultMethod***" + response.getStatusCode());

		return response.getStatusCode();
	}

	/**
	 * Prepare put default method json string response.
	 *
	 * @param opPaymentCard the op payment card
	 * @param opAccount the op account
	 * @param rbacProfile the rbac profile
	 * @return the string
	 * @throws Exception the exception
	 */
	private String preparePutDefaultMethodJsonStringResponse(PaymentCard opPaymentCard, Account opAccount,
			RBACProfile rbacProfile) throws Exception {

		String opcTemplate = SLConstants.SET_DEFAULT_PAYMENT_METHOD_FILE_PATH;

		VelocityEngine velocityEngine = new VelocityEngine();
		StringWriter writer = null;
		try {
			velocityEngine.init();

			// next, get the Template
			Template template = velocityEngine.getTemplate(opcTemplate);
			// create a context and add data
			VelocityContext velocityContext = new VelocityContext();

			velocityContext.put("URNID", opPaymentCard.getUrnID());

			// now render the template into a StringWriter
			writer = new StringWriter();
			template.merge(velocityContext, writer);

		} catch (Exception ex) {
			throw new Exception("Error occured while preparing flist string using velocity template builder", ex);
		}
		// CREATING CUST COMMIT JSON FILE IN LOCAL DIRECTORY FOR REFERENCE
		System.out.println("getResponseSetDefaultMethod ========\n" + writer.toString());
		return writer.toString();
	}

	/**
	 * Validate get support method.
	 *
	 * @param opAccount the op account
	 * @param rbacProfile the rbac profile
	 * @return the int
	 * @throws IOException Signals that an I/O exception has occurred.
	 * @throws EBufException the e buf exception
	 * @throws Exception the exception
	 */
	/*
	 * Get supported Method Response from PSL
	 */
	public int validateGetSupportMethod(Account opAccount, RBACProfile rbacProfile)
			throws IOException, EBufException, Exception {

		String uri = PaymentConstants.GET_SUPPORTED_METHODS.replace("$env",
				PropertyUtil.getBslProperties().getProperty(SLConstants.ENVIORNMENT));
		Response response = RestAPIConnection.executeGetRestAPIConnectionMethodWithToken(uri,
				SLConstants.ACCEPT_APPLICATION_JSON, SLConstants.CONTENT_TYPE_APPLICATION_JSON, rbacProfile.getToken(),
				opAccount.getAccountNumber(), "");

		/*
		 * RequestSpecification httpRequest =
		 * RestAssured.given().header("X-Auth-Token", rbacProfile.getToken())
		 * .header("X-Rax-AccountNumber",
		 * opAccount.getAccountNumber()).accept("application/json")
		 * .contentType("application/json").body("");
		 */

		System.out.println("Rest API call end\n");
		System.out.println("RESTAPIResponseData***getsupportedResponseINPSL***" + response.getStatusCode());
		return response.getStatusCode();
	}

	/*
	 * GetSupported Method for Billing
	 * 
	 */

	/**
	 * Gets the supported method.
	 *
	 * @param ipPaymentCard the ip payment card
	 * @param rbacProfile the rbac profile
	 * @param ipAccount the ip account
	 * @return the supported method
	 * @throws Exception the exception
	 */
	public PaymentCard getSupportedMethod(PaymentCard ipPaymentCard, RBACProfile rbacProfile, Account ipAccount)
			throws Exception {

		String uri = PaymentConstants.GET_SUPPORTED_METHODS.replace("$env",
				PropertyUtil.getBslProperties().getProperty(SLConstants.ENVIORNMENT));
		System.out.println("PayamentURIPath****" + uri);
		System.out.println("accountNumber" + ipAccount.getAccountNumber());

		Response response = RestAPIConnection.executeGetRestAPIConnectionMethodWithToken(uri,
				SLConstants.ACCEPT_APPLICATION_JSON, SLConstants.CONTENT_TYPE_APPLICATION_JSON, rbacProfile.getToken(),
				ipAccount.getAccountNumber(), "");
		System.out.println("Rest API call end\n");
		System.out.println("RESTAPIResponseData******" + response.getStatusCode());
		/*
		 * RequestSpecification httpRequest =
		 * RestAssured.given().header("X-Auth-Token", rbacProfile.getToken())
		 * .accept("application/json").contentType("application/json").body("");
		 */
		System.out.println("response************" + response.getStatusCode());
		// System.out.println("responseBody************" + response.getBody());

		Payment payment = response.as(Payment.class, ObjectMapperType.GSON);
	/*	PaymentResponse paymentResponse = response.as(PaymentResponse.class, ObjectMapperType.GSON);*/

		System.out.println("notificationJSONParser.getRecipients().get(0).getStatus() "
				+ ipPaymentCard.getUrnID());

		System.out.println("status code for response: " + response.getStatusCode());

		return ipPaymentCard;

	}

	/**
	 * Validate get default method.
	 *
	 * @param ipPaymentCard the ip payment card
	 * @param rbacProfile the rbac profile
	 * @param opAccount the op account
	 * @return the int
	 * @throws Exception the exception
	 */
	public int validateGetDefaultMethod(PaymentCard ipPaymentCard, RBACProfile rbacProfile, Account opAccount)
			throws Exception {

		String inputStringJson = this.preparePutValidateGetDefaultMethodString(ipPaymentCard, rbacProfile, opAccount);

		String uri = PaymentConstants.GET_PSL_SET_DEFAULT_METHOD
				.replace("$env", PropertyUtil.getBslProperties().getProperty(SLConstants.ENVIORNMENT))
				.replace("$accountNumber", opAccount.getAccountNumber());
		System.out.println("validateGetDefaultMethod uri =====" + uri);
		Response response = RestAPIConnection.executePutRestAPIConnectionWithToken(uri,
				SLConstants.ACCEPT_APPLICATION_JSON, SLConstants.CONTENT_TYPE_APPLICATION_JSON, rbacProfile.getToken(),
				inputStringJson);
		System.out.println("response ===" + response);
		Payment payment = response.as(Payment.class, ObjectMapperType.GSON);
		PaymentResponse paymentResponse = response.as(PaymentResponse.class, ObjectMapperType.GSON);

		//System.out.println("ipElectronicCheck.getUrnID()======= " + ipPaymentCard.getUrnID());
		System.out.println("=====AccountNumber======  " + opAccount.getAccountNumber());
		System.out.println("Response Code ===== validateGetDefaultMethod ==== " + response.getStatusCode());
		return response.getStatusCode();

	}

	/**
	 * Prepare put validate get default method string.
	 *
	 * @param ipPaymentCard the ip payment card
	 * @param rbacProfile the rbac profile
	 * @param opAccount the op account
	 * @return the string
	 * @throws Exception the exception
	 */
	private String preparePutValidateGetDefaultMethodString(PaymentCard ipPaymentCard, RBACProfile rbacProfile,
			Account opAccount) throws Exception {
		String opcTemplate = SLConstants.SET_DEFAULT_PAYMENT_METHOD_FILE_PATH;

		VelocityEngine velocityEngine = new VelocityEngine();
		StringWriter writer = null;
		try {
			velocityEngine.init();

			// next, get the Template
			Template template = velocityEngine.getTemplate(opcTemplate);
			// create a context and add data
			VelocityContext velocityContext = new VelocityContext();

			velocityContext.put("URNID", ipPaymentCard.getUrnID());

			// now render the template into a StringWriter
			writer = new StringWriter();
			template.merge(velocityContext, writer);

		} catch (Exception ex) {
			throw new Exception("Error occured while preparing flist string using velocity template builder", ex);
		}
		// CREATING CUST COMMIT NAP FILE IN LOCAL DIRECTORY FOR REFERENCE
		System.out.println("preparePutDefaultMethodString========\n" + writer.toString());
		return writer.toString();
	}

}
