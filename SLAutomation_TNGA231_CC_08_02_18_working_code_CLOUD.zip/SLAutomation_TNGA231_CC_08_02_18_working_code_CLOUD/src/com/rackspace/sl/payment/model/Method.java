
package com.rackspace.sl.payment.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

// TODO: Auto-generated Javadoc
/**
 * The Class Method.
 */
public class Method {

    /** The disabled. */
    @SerializedName("disabled")
    @Expose
    private String disabled;
    
    /** The payment card. */
    @SerializedName("paymentCard")
    @Expose
    private PaymentCard paymentCard;
  /*  
    @SerializedName("paymentResponse")
    @Expose
    private PaymentResponse paymentResponse;*/

    /**
   * Gets the disabled.
   *
   * @return the disabled
   */
  public String getDisabled() {
        return disabled;
    }

    /**
     * Sets the disabled.
     *
     * @param disabled the new disabled
     */
    public void setDisabled(String disabled) {
        this.disabled = disabled;
    }

    /**
     * Gets the payment card.
     *
     * @return the payment card
     */
    public PaymentCard getPaymentCard() {
        return paymentCard;
    }

    /**
     * Sets the payment card.
     *
     * @param paymentCard the new payment card
     */
    public void setPaymentCard(PaymentCard paymentCard) {
        this.paymentCard = paymentCard;
    }

/*	public PaymentResponse getPaymentResponse() {
		return paymentResponse;
	}

	public void setPaymentResponse(PaymentResponse paymentResponse) {
		this.paymentResponse = paymentResponse;
	}*/

}
