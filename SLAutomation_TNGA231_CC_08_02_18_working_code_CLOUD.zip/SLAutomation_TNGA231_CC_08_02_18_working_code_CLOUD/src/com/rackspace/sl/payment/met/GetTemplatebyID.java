package com.rackspace.sl.payment.met;

import io.restassured.RestAssured;
import io.restassured.http.Method;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class GetTemplatebyID {

	public static void main(String[] args) {

		executeGetRestAPIConnectionPostWithToken();

	}

	public static synchronized void executeGetRestAPIConnectionPostWithToken() {

		String body = "<auth xmlns=\"http://docs.openstack.org/identity/api/v2.0\"> \r\n" + 
				"  <apiKeyCredentials xmlns=\"http://docs.rackspace.com/identity/api/ext/RAX-KSKEY/v1.0\" \r\n" + 
				"	username=\"user_302733\" apiKey=\"0f97f489c848438090250d50c7e1ea88\"/>\r\n" + 
				"</auth>";
		System.out.println("body" + body);
		RestAssured.baseURI = "https://staging.identity.api.rackspacecloud.com/v2.0/tokens";
		RestAssured.useRelaxedHTTPSValidation();
		RequestSpecification httpRequest = RestAssured.given().accept("application/json")
				.contentType("application/xml").body(body);
		Response response = httpRequest.request(Method.POST);
		String responseBody = response.getBody().asString();

		System.out.println("Response Body of Template" + responseBody);

		int responseCode = response.getStatusCode();

		System.out.println("responseCode*****" + responseCode);

	}

}
