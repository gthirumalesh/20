
package com.rackspace.sl.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/**
 * The Class Role.
 */
public class Role {

    /** The role name. */
    @SerializedName("roleName")
    @Expose
    private String roleName;
    
    /** The is default. */
    @SerializedName("isDefault")
    @Expose
    private Boolean isDefault;
    
    /** The preferences. */
    @SerializedName("preferences")
    @Expose
    private Preferences preferences;

    /**
     * Gets the role name.
     *
     * @return the role name
     */
    public String getRoleName() {
        return roleName;
    }

    /**
     * Sets the role name.
     *
     * @param roleName the new role name
     */
    public void setRoleName(String roleName) {
        this.roleName = roleName;
    }

    /**
     * Gets the checks if is default.
     *
     * @return the checks if is default
     */
    public Boolean getIsDefault() {
        return isDefault;
    }

    /**
     * Sets the checks if is default.
     *
     * @param isDefault the new checks if is default
     */
    public void setIsDefault(Boolean isDefault) {
        this.isDefault = isDefault;
    }

    /**
     * Gets the preferences.
     *
     * @return the preferences
     */
    public Preferences getPreferences() {
        return preferences;
    }

    /**
     * Sets the preferences.
     *
     * @param preferences the new preferences
     */
    public void setPreferences(Preferences preferences) {
        this.preferences = preferences;
    }

}
