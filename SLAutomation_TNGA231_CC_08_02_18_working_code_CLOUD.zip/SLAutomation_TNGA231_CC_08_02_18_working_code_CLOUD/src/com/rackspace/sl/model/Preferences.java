
package com.rackspace.sl.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/**
 * The Class Preferences.
 */
public class Preferences {

    /** The is invoice email delivery. */
    @SerializedName("isInvoiceEmailDelivery")
    @Expose
    private Boolean isInvoiceEmailDelivery;
    
    /** The threshold notification option. */
    @SerializedName("thresholdNotificationOption")
    @Expose
    private Boolean thresholdNotificationOption;

    /**
     * Gets the checks if is invoice email delivery.
     *
     * @return the checks if is invoice email delivery
     */
    public Boolean getIsInvoiceEmailDelivery() {
        return isInvoiceEmailDelivery;
    }

    /**
     * Sets the checks if is invoice email delivery.
     *
     * @param isInvoiceEmailDelivery the new checks if is invoice email delivery
     */
    public void setIsInvoiceEmailDelivery(Boolean isInvoiceEmailDelivery) {
        this.isInvoiceEmailDelivery = isInvoiceEmailDelivery;
    }

    /**
     * Gets the threshold notification option.
     *
     * @return the threshold notification option
     */
    public Boolean getThresholdNotificationOption() {
        return thresholdNotificationOption;
    }

    /**
     * Sets the threshold notification option.
     *
     * @param thresholdNotificationOption the new threshold notification option
     */
    public void setThresholdNotificationOption(Boolean thresholdNotificationOption) {
        this.thresholdNotificationOption = thresholdNotificationOption;
    }

}
