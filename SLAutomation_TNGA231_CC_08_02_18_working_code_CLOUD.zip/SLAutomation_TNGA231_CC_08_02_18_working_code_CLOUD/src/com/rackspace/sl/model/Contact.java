
package com.rackspace.sl.model;

import java.util.List;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/**
 * The Class Contact.
 */
public class Contact {

    /** The contact id. */
    @SerializedName("contactId")
    @Expose
    private String contactId;
    
    /** The first name. */
    @SerializedName("firstName")
    @Expose
    private String firstName;
    
    /** The last name. */
    @SerializedName("lastName")
    @Expose
    private String lastName;
    
    /** The middle name. */
    @SerializedName("middleName")
    @Expose
    private String middleName;
    
    /** The salutation. */
    @SerializedName("salutation")
    @Expose
    private String salutation;
    
    /** The title. */
    @SerializedName("title")
    @Expose
    private String title;
    
    /** The email. */
    @SerializedName("email")
    @Expose
    private String email;
    
    /** The address. */
    @SerializedName("address")
    @Expose
    private Address address;
    
    /** The roles. */
    @SerializedName("roles")
    @Expose
    private List<Role> roles = null;
    
    /** The phone numbers. */
    @SerializedName("phoneNumbers")
    @Expose
    private PhoneNumbers phoneNumbers;

    /**
     * Gets the contact id.
     *
     * @return the contact id
     */
    public String getContactId() {
        return contactId;
    }

    /**
     * Sets the contact id.
     *
     * @param contactId the new contact id
     */
    public void setContactId(String contactId) {
        this.contactId = contactId;
    }

    /**
     * Gets the first name.
     *
     * @return the first name
     */
    public String getFirstName() {
        return firstName;
    }

    /**
     * Sets the first name.
     *
     * @param firstName the new first name
     */
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    /**
     * Gets the last name.
     *
     * @return the last name
     */
    public String getLastName() {
        return lastName;
    }

    /**
     * Sets the last name.
     *
     * @param lastName the new last name
     */
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    /**
     * Gets the middle name.
     *
     * @return the middle name
     */
    public String getMiddleName() {
        return middleName;
    }

    /**
     * Sets the middle name.
     *
     * @param middleName the new middle name
     */
    public void setMiddleName(String middleName) {
        this.middleName = middleName;
    }

    /**
     * Gets the salutation.
     *
     * @return the salutation
     */
    public String getSalutation() {
        return salutation;
    }

    /**
     * Sets the salutation.
     *
     * @param salutation the new salutation
     */
    public void setSalutation(String salutation) {
        this.salutation = salutation;
    }

    /**
     * Gets the title.
     *
     * @return the title
     */
    public String getTitle() {
        return title;
    }

    /**
     * Sets the title.
     *
     * @param title the new title
     */
    public void setTitle(String title) {
        this.title = title;
    }

    /**
     * Gets the email.
     *
     * @return the email
     */
    public String getEmail() {
        return email;
    }

    /**
     * Sets the email.
     *
     * @param email the new email
     */
    public void setEmail(String email) {
        this.email = email;
    }

    /**
     * Gets the address.
     *
     * @return the address
     */
    public Address getAddress() {
        return address;
    }

    /**
     * Sets the address.
     *
     * @param address the new address
     */
    public void setAddress(Address address) {
        this.address = address;
    }

    /**
     * Gets the roles.
     *
     * @return the roles
     */
    public List<Role> getRoles() {
        return roles;
    }

    /**
     * Sets the roles.
     *
     * @param roles the new roles
     */
    public void setRoles(List<Role> roles) {
        this.roles = roles;
    }

    /**
     * Gets the phone numbers.
     *
     * @return the phone numbers
     */
    public PhoneNumbers getPhoneNumbers() {
        return phoneNumbers;
    }

    /**
     * Sets the phone numbers.
     *
     * @param phoneNumbers the new phone numbers
     */
    public void setPhoneNumbers(PhoneNumbers phoneNumbers) {
        this.phoneNumbers = phoneNumbers;
    }

}
