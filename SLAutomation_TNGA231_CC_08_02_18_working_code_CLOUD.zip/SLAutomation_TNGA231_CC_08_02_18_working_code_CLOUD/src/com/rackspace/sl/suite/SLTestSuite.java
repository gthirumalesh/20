package com.rackspace.sl.suite;

import java.io.IOException;

import org.junit.Assert;
import org.testng.Reporter;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.rackspace.brm.account.constants.AccountConstants.AccountType;
import com.rackspace.brm.account.model.Account;
import com.rackspace.brm.common.Utils;
import com.rackspace.brm.validation.AccountValidation;
import com.rackspace.sl.account.action.AccountAction;
import com.rackspace.sl.account.builder.AccountBuilder;
import com.rackspace.sl.constants.SLConstants;
import com.rackspace.sl.event.action.EventAction;
import com.rackspace.sl.event.builder.EventBuilder;
import com.rackspace.sl.event.constants.EventConstants.EventType;
import com.rackspace.sl.event.model.Event;
import com.rackspace.sl.payment.action.PaymentAction;
import com.rackspace.sl.payment.builder.PaymentBuilder;
import com.rackspace.sl.payment.constants.PaymentConstants.CardTypes;
import com.rackspace.sl.payment.model.PaymentCard;
import com.rackspace.sl.rbacprofile.action.RBACProfileAction;
import com.rackspace.sl.rbacprofile.builder.RBACProfileBuilder;
import com.rackspace.sl.rbacprofile.constants.RBACProfileConstants.RBACprofileType;
import com.rackspace.sl.rbacprofile.model.RBACProfile;
import com.rackspace.sl.validation.NotificationValidation;

/**
 * The Class SLTestSuite.
 */

public class SLTestSuite {

	/**
	 * Prepare report folder.
	 */
	@BeforeTest(alwaysRun = true)
	public void prepareReportFolder() {
		try {
			Utils.APP_LOGS.info("Enter: prepareReportFolder()");

			Utils.prepareTestDirectory();

			Utils.APP_LOGS.info("Exit: prepareReportFolder()");

		} catch (IOException e) {

			Utils.APP_LOGS.error("IOException in prepareReportFolder " + e);
		}
	}

	/**
	 * S L T S ACC T 01 validate create AQ notification for billing primary
	 * method changed.
	 *
	 * @param templateType
	 *            the template type
	 * @param profile
	 *            the profile
	 * @param currency
	 *            the currency
	 * @param payType
	 *            the pay type
	 * @param notificationOption
	 *            the notification option
	 * @param contractingEntity
	 *            the contracting entity
	 * @param invoiceDeliveryMethod
	 *            the invoice delivery method
	 * @param supportTeam
	 *            the support team
	 * @param paymentTerm
	 *            the pay term
	 * @param vatNumber
	 *            the vat number
	 * @param paymentType
	 *            the payment type
	 * @param inPvt
	 *            the in pvt
	 * @param polarity
	 *            the polarity
	 * @param testMethodName
	 *            the test method name
	 * @param suiteName
	 *            the suite name
	 * @param jsonFileName
	 *            the json file name
	 * @param xmlFileName
	 *            the xml file name
	 * @param xmlParentTagName
	 *            the xml parent tag name
	 */
	@Test(groups = { "Component", "Regression" })
	@Parameters({ "In_TemplateType", "In_Profile", "In_Currency", "In_Paytype", "In_NotificationOption",
			"In_ContractingEntity", "In_InvoiceDeliveryMethod", "In_SupportTeam", "In_PaymentTerm", "In_VatNumber",
			"In_PaymentType", "In_Pvt", "In_Polarity", "Out_Testname", "Out_Suitename", "Out_JsonFileName",
			"Out_XmlFileName", "Out_XmlParentTagName", "In_CardVerificationNumber", "In_CardHolderName",
			"In_CardNumber", "In_CardType", "In_ExpireDate" })

	/*
	 * Get Template Call from Bazooka.... Step2
	 */
	public void SL_TS_ACCT_01_PAYMENT_ADDED_CC(String templateType, String profile, String currency, String payType,
			String notificationOption, String contractingEntity, String invoiceDeliveryMethod, String supportTeam,
			String paymentTerm, String vatNumber, String paymentType, String inPvt, String polarity,
			String testMethodName, String suiteName, String jsonFileName, String xmlFileName, String xmlParentTagName,
			String cardVerificationNumber, String cardHolderName, String cardNumber, String cardType,
			String expireDate) {

		try {

			Utils.APP_LOGS.info("Starting SL_TS_ACCT_01_PAYMENT_ADDED_CC testcase");

			// STEP 1: Generate Token
			RBACProfileBuilder rbacProfileBuilder = null;

			if (Utils.isNullOrEmpty(profile) || profile.equals(RBACprofileType.BSL_SYSTEM_ROLE.toString())) {
				rbacProfileBuilder = new RBACProfileBuilder(RBACprofileType.BSL_SYSTEM_ROLE);
			} else if (profile.equals(RBACprofileType.PROMOTION_AUTH.toString())) {
				rbacProfileBuilder = new RBACProfileBuilder(RBACprofileType.PROMOTION_AUTH);
			}

			RBACProfile ipRBACProfile = rbacProfileBuilder.getRBACProfile();
			// Create RBACprofileAction object
			RBACProfileAction rbacProfileAction = new RBACProfileAction();
			ipRBACProfile = rbacProfileAction.getToken(ipRBACProfile);
			System.out.println("TOKEN :"+ipRBACProfile.getToken());
			// Validate Token Generation
			Assert.assertNotNull(ipRBACProfile.getToken());

			String step1 = "Step 1: Token generated successfully for ";

			Utils.APP_LOGS.info(step1 + RBACprofileType.BSL_SYSTEM_ROLE);
			Utils.APP_LOGS.info(
					"The generated Token for " + RBACprofileType.BSL_SYSTEM_ROLE + " is " + ipRBACProfile.getToken());
			Reporter.log(step1 + RBACprofileType.BSL_SYSTEM_ROLE);

			// STEP 2: Validate the GET TEMPLATE call from BAZOOKA to fetch the
			// template for "PAYMENT_ADDED_ACH"
			EventBuilder eventGetTemplateByIDBuilder = new EventBuilder(EventType.GET_TEMPLATE_ID, templateType);
			Event emailTemplateByIDEvent = eventGetTemplateByIDBuilder.getEvent();
			String emailTemplateByIDEventas = emailTemplateByIDEvent.getTemplateType();
			Utils.APP_LOGS.info("%%%%%%%%%%%%%%%%%%%%%% " + emailTemplateByIDEventas);

			EventAction eventTemplateByIDAction = new EventAction();
			Assert.assertTrue(eventTemplateByIDAction.getTemplateById(emailTemplateByIDEvent, ipRBACProfile));

			String step2 = "Step 2: Validate the GET TEMPLATE call from BAZOOKA to fetch the template for PAYMENT_ADDED_ACH";

			Utils.APP_LOGS.info(step2);
			Reporter.log(step2);
			// STEP 3: Create a default dedicated account using BSL V2 "create
			// account" api

			AccountBuilder accountBuilder = new AccountBuilder(AccountType.US_CLOUD, Utils.generateTenantId(),
					Utils.generateTenantId(), currency, payType, notificationOption, contractingEntity,
					invoiceDeliveryMethod, supportTeam, paymentTerm, vatNumber, paymentType, invoiceDeliveryMethod,
					notificationOption, Utils.getISO8601StringForCurrentDate(),
					String.valueOf(Utils.converToEpochTime(Utils.getPreviousMonthPvtDate(inPvt))), paymentType);
			/*
			 * Get accountNumber from BSL ...step4
			 */
			Account ipAccount = accountBuilder.getAccount();

			AccountAction accountAction = new AccountAction();

			/*
			 * CreateAccount DefaultDedicatedAccount ...step3
			 */
			Account opAccount = accountAction.createAccount(ipAccount, ipRBACProfile);
			System.out.println("============================"+opAccount.getStartDate());
			/*
			 * Get Account call from BSL step4
			 */
			System.out.println("Accountno############" + opAccount.getAccountNumber());
			/*
			 * Validate Get AccountNumber from BSL
			 */
			// Assert.assertFalse(Utils.isNullOrEmpty(opAccount.getAccountNumber()));
			/*
			 * AccountNumber Validation From FROm BSL step5
			 */
			// Assert.assertTrue(accountAction.validateSLAccount(opAccount,
			// ipRBACProfile));

			// STEP 4: Validating BSL Account , Get Account call from BSL
			/*Assert.assertEquals(200, accountAction.validateBSLAccount(opAccount, ipRBACProfile));

			PaymentBuilder paymentBuilder = new PaymentBuilder(CardTypes.VISA, cardVerificationNumber, cardHolderName,
					cardNumber, expireDate, cardType);

			PaymentCard ipPaymentCard = paymentBuilder.getPayments();

			PaymentAction paymentAction = new PaymentAction();
			
			 * validate Account from PSL step5
			 
			PaymentCard opPaymentCard = new PaymentCard();
			// STEP 5 & 6: Validating Get Account call from BSL
			Assert.assertEquals(200, paymentAction.validatePSLAccount(opAccount, ipRBACProfile));
			// step:validate Get supported method
			Assert.assertEquals(200, paymentAction.validateGetSupportedMethod(opAccount, ipRBACProfile));

			// STEP : create CCMethod
			opPaymentCard = paymentAction.createCCMethod(ipPaymentCard, ipRBACProfile, opAccount);
			Assert.assertEquals(201, opPaymentCard.getResponseCode());

			Utils.APP_LOGS.info("URNID" + opPaymentCard.getUrnID());

			// STEP :set Default Method
			PaymentCard opPaymentCard1 = paymentAction.createDefaultMethod(opPaymentCard, ipRBACProfile, opAccount);
			Assert.assertEquals(201, opPaymentCard1.getResponseCode());

			// Assert.assertEquals(200,paymentAction.validateSetDefaultMethod(opPaymentCard1,ipRBACProfile,opAccount
			// ));
			// Get Default Method

			PaymentCard opPaymentCard2 = paymentAction.createGetDefaultMethod(opPaymentCard, ipRBACProfile, opAccount);
			Assert.assertEquals(200, opPaymentCard2.getResponseCode());

			// validateGet Default Method
			// Assert.assertEquals(200,paymentAction.validateGetDefaultMethod(opPaymentCard2,ipRBACProfile,opAccount));

			// Step 12 Validate Notification Event NotificationEvent =
			eventTemplateByIDAction.getNotificationID(opAccount.getAccountNumber(), SLConstants.NOTIFICATION_QUERY);

			String step12 = "Step 12: Validate Notification in Bazooka DB";

			Utils.APP_LOGS.info(step12);
			Reporter.log(step12);

			EventBuilder eventGetNotificationBuilder = new EventBuilder(EventType.GET_NOTIFICATION, templateType);
			Event emailNotificationEvent = eventGetNotificationBuilder.getEvent();

			emailNotificationEvent = eventTemplateByIDAction.getNotification(emailNotificationEvent, ipRBACProfile);

			NotificationValidation.validateNotificationStatus(emailNotificationEvent);

			String step13 = "Step 13: Validate Notification using Get Notification";

			Utils.APP_LOGS.info(step13);
			Reporter.log(step13);
*/
		} catch (NullPointerException e) {
			Utils.APP_LOGS.error("Null pointer exception in SL_TS_ACCT_01_PAYMENT_ADDED_ACH " + e);
		} catch (Exception e) {
			Utils.APP_LOGS.error("Exception while executing SL_TS_ACCT_01_PAYMENT_ADDED_ACH " + e);
		}

	}

}
