package com.rackspace.brm.usage.model;

import com.rackspace.brm.usage.constants.UsageConstants.UsageType;

// TODO: Auto-generated Javadoc
/**
 * The Class CloudUsage.
 */
public class CloudUsage extends Usage {

	/**
	 * Instantiates a new cloud usage.
	 */
	public CloudUsage() {
		super(UsageType.CLOUD);
		// TODO Auto-generated constructor stub
	}

	/** The record type. */
	protected String recordType = null;
	
	/** The usage record ID. */
	protected String usageRecordID = null;
	
	/** The service code. */
	protected String serviceCode = null;
	
	/** The account number. */
	protected String accountNumber = null;

	/**
	 * Gets the record type.
	 *
	 * @return the record type
	 */
	public String getRecordType() {
		return recordType;
	}

	/**
	 * Sets the record type.
	 *
	 * @param recordType the new record type
	 */
	public void setRecordType(String recordType) {
		this.recordType = recordType;
	}

	/**
	 * Gets the usage record ID.
	 *
	 * @return the usage record ID
	 */
	public String getUsageRecordID() {
		return usageRecordID;
	}

	/**
	 * Sets the usage record ID.
	 *
	 * @param usageRecordID the new usage record ID
	 */
	public void setUsageRecordID(String usageRecordID) {
		this.usageRecordID = usageRecordID;
	}

	/**
	 * Gets the service code.
	 *
	 * @return the service code
	 */
	public String getServiceCode() {
		return serviceCode;
	}

	/**
	 * Sets the service code.
	 *
	 * @param serviceCode the new service code
	 */
	public void setServiceCode(String serviceCode) {
		this.serviceCode = serviceCode;
	}

	/**
	 * Gets the account number.
	 *
	 * @return the account number
	 */
	public String getAccountNumber() {
		return accountNumber;
	}

	/**
	 * Sets the account number.
	 *
	 * @param accountNumber the new account number
	 */
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

}
