package com.rackspace.brm.account.constants;

/**
 * The Class AccountConstants.
 */
public final class AccountConstants {

	
	/**
	 * AccountType section to hold all enumerators.
	 */

	public enum AccountType {
		
		/** The dedicated. */
		DEDICATED, 
 /** The uscloud. */
 US_CLOUD, 
 /** The ukcloud. */
 UK_CLOUD
	}

	/**
	 * The ENUM BillingType holds the billing type like daily billing and
	 * monthly billing.
	 */
	public enum BillingType {
		
		/** The daily billing. */
		DAILY_BILLING, 
 /** The monthly billing. */
 MONTHLY_BILLING,
	}

	/**
	 * The ContractingEntity is a ENUM, holds the Contracting Entities.
	 */
	public enum ContractingEntity {

		/** The us. */
		US("100"), /** The nl. */
 NL("300"), /** The hk. */
 HK("400"), /** The au. */
 AU("500"), /** The ch. */
 CH("600"), /** The mx. */
 MX("720"), /** The de. */
 DE("730"), /** The oca. */
 OCA("163"), /** The ca. */
 CA("164"), /** The tc. */
 TC(
				"169"), 
 /** The sg. */
 SG("");

		/** The contracting entity variable represents the contracting entity. */
		private String contractingEntity = null;

		/**
		 * Instantiates a new contracting entity.
		 *
		 * @param contractingEntity
		 *            used for to get the contractingEntity
		 */
		private ContractingEntity(String contractingEntity) {
			this.contractingEntity = contractingEntity;
		}

		/**
		 * Gets the contracting entity.
		 * 
		 * @return the contracting entity used for to set the contractingEntity
		 */
		public String getContractingEntity() {
			return this.contractingEntity;
		}
	}

	/**
	 * The Currency is a Enum, holds the Currency type like USD GBP AUD,EUR,
	 * HKD.
	 */
	public enum Currency {

		/** The usd. */
		USD("840"), /** The gbp. */
 GBP("826"), /** The aud. */
 AUD("36"), /** The eur. */
 EUR("978"), /** The hkd. */
 HKD("344");

		/**
		 * The currency this variable represents the currency.
		 */
		private String currency = null;

		/**
		 * Instantiates a new currency.
		 * 
		 * @param currency
		 *            used for set the currency. like USD, AUD, EUR or GBP.
		 */
		private Currency(String currency) {
			this.currency = currency;
		}

		/**
		 * Gets the currency.
		 *
		 * @return the currency used for get the currency
		 */
		public String getCurrency() {
			return this.currency;
		}
	}
	
	
	/**
	 * The Currency is a Enum, holds the Currency type like USD GBP AUD,EUR,
	 * HKD.
	 */
	public enum CurrencySymbol {

		/** The usd. */
		USD("$"),
		/** The gbp. */
		GBP("�"),
		/** The aud. */
		AUD("$"),
		/** The eur. */
		EUR("�"),
		/** The hkd. */
		HKD("$");

		/**
		 * The currency this variable represents the currency.
		 */
		private String currencySymbol = null;

		/**
		 * Instantiates a new currency.
		 *
		 * @param currencySymbol
		 *            the currency symbol
		 */
		private CurrencySymbol(String currencySymbol) {
			this.currencySymbol = currencySymbol;
		}

		/**
		 * Gets the currency.
		 *
		 * @return the currency used for get the currency
		 */
		public String getcurrencySymbol() {
			return this.currencySymbol;
		}
	}
	
	
	/**
	 * The Enum PayType.
	 */
	public enum PayType {

		/** The invoice. */
		INVOICE("840"), /** The gbp. */
 GBP("826"), /** The aud. */
 AUD("36"), /** The eur. */
 EUR("978"), /** The hkd. */
 HKD("344");

		/**
		 * The currency this variable represents the currency.
		 */
		private String payType = null;

		/**
		 * Instantiates a new currency.
		 *
		 * @param payType the pay type
		 */
		private PayType(String payType) {
			this.payType = payType;
		}

		/**
		 * Gets the currency.
		 *
		 * @return the currency used for get the currency
		 */
		public String getPayType() {
			return this.payType;
		}
	}
	

	/**
	 * The BillingSegment is Enum type, holds the Billing segment like US_CLOUD,
	 * UK_CLOUD, DEDICATED.
	 * 
	 */
	public enum BillingSegment {

		/** The us cloud. */
		US_CLOUD("2001"), /** The uk cloud. */
 UK_CLOUD("2002"), /** The dedicated. */
 DEDICATED("2004");

		/**
		 * The billing segment. this variable represents the billingSegment.
		 */
		private String billingSegment = null;

		/**
		 * Instantiates a new billing segment.
		 * 
		 * @param billingSegment
		 *            used for to set the billingSegment
		 */
		private BillingSegment(String billingSegment) {
			this.billingSegment = billingSegment;
		}

		/**
		 * Gets the billing segment.
		 *
		 * @return the billing segment used for to get the billingSegment
		 */
		public String getBillingSegment() {
			return this.billingSegment;
		}
	}

	/**
	 * The BillingSegment is Enum type, holds the Billing segment like US_CLOUD,
	 * UK_CLOUD, DEDICATED.
	 * 
	 */
	public enum GLSegment {

		/** The us cloud. */
		US_CLOUD(".cloud.us"), /** The uk cloud. */
 UK_CLOUD(".cloud.uk"), /** The dedicated. */
 DEDICATED(".dedicated");

		/**
		 * The billing segment. this variable represents the billingSegment.
		 */
		private String glSegment = null;

		/**
		 * Instantiates a new billing segment.
		 *
		 * @param glSegment the gl segment
		 */
		private GLSegment(String glSegment) {
			this.glSegment = glSegment;
		}
		
		

		/**
		 * Gets the billing segment.
		 *
		 * @return the billing segment used for to get the billingSegment
		 */
		public String getGLSegment() {
			return this.glSegment;
		}
	}

	
	/**
	 * The main method.
	 *
	 * @param args the arguments
	 */
	public static void main(String[] args) {
		
		System.out.println(BillingSegment.US_CLOUD.getBillingSegment());
		System.out.println(Currency.USD.getCurrency());
	}
}
