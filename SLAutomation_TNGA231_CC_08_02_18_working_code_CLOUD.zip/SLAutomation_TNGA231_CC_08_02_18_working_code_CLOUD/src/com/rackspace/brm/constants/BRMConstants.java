package com.rackspace.brm.constants;

import java.util.*;

public final class BRMConstants {

	//Constants variable for reading properties
	public static final String PIN_ENVIRONMENT_USER="pinEnviornment";
	public static final String BRM_CM_LOG_DIR="cmLogFromLocation";
	public static final String REPLACE_ENV_STRING="$env$";
	public static final String BRM_DM_LOG_DIR="dmLogFromLocation";
	public static final String PVT_COMMAND_STRING="pvtCmd";
	public static final String SHELL_COMMAND="shell";
	public static final String SUDO_COMMAND="sudocommand";
	public static final String EXIT_NEWLINE="exit\n";
	public static final String SFTP="sftp";
	
	//NAP FILE NAME KEYWORDS
	public static final String PO_FLIST_NAP_FILE_NAME_LABEL="PO_Flist_RAX_OP_CUST_COMMIT_CUSTOMER.in.";

	public static final String PROGRAM_NAME="TESTNG AUTOMATION";
	public static final String PAYMENT_OFFSET= "paymentOffset";
	public static final String BANK_NO = "bankNumber";
	public static final String BANK_CODE = "bankCode";

	
	//Dedicated usage files
	
	public static final String EBS_BILLING_DAILY="EBS_BillingLinesdaily";
	public static final String EBS_BILLING_MONTHLY ="EBS_BillingLinesmonthly";
	public static final String EBS_BILLING_FILE_EXTN=".csv";
	public static final String PDF_FILE_EXTN=".pdf";
	public static final String PDF_FROM_LOCATION="pdfFromLocation";
	
	
	public static final String CONTACT_TYPE_PRIMARY = "PRIMARY";
	public static final String CONTACT_TYPE_BILLING = "BILLING";

	public static final String[] DEFAULT_ACCOUNT_NAMEINFO = { "San Antonio", "TX", "78258", "US" };

	/**
	 * This section to hold all opcode names
	 */

	public static final String CUSTOMER_CUST_COMMIT_OPCODE = "RAX_OP_CUST_COMMIT_CUSTOMER";
	public static final int RAX_OP_CUST_COMMIT_CUSTOMER = 100080;
	public static final String DEDICATED_PO_OPCODE = "RAX_OP_CUST_ADD_SERVICE_BILLINFO";
	public static final int RAX_OP_CUST_MOVE_ACCOUNT = 100251;
	public static final String INVOICE_TYPE_DEFAULT = "default";
	public static final String INVOICE_TYPE_PO = "pobill ";
	public static final String INVOICE_TYPE_STATEMENT = "statement";
	public static final String RAX_INVOICE_QUERY = "raxInvoiceQuery";
	public static final int PCM_OP_PUBLISH_GEN_PAYLOAD = 1301;

	/**
	 * This section to hold template name, file path etc.
	 */

	public static final String DEDICATED_ACCT_CREATE_OPC_FILE_PATH = "src/com/rackspace/brm/account/templates/RAX_OP_CUST_COMMIT_CUSTOMER_dedicated_CC.nap";
	public static final String CLOUD_ACCT_CREATE_OPC_FILE_PATH = "yyy";
	public static final String DEDICATED_PO_CREATE_OPC_FILE_PATH = "zzz";
	public static final String PCM_OP_PUBLISH_GEN_PAYLOAD_FILE_PATH = "src/com/rackspace/brm/account/templates/PCM_OP_PUBLISH_GEN_PAYLOAD.nap";
	public static final String BILLING_PROBLEM_CHARGE_CC_FILE_PATH = "src/com/rackspace/brm/account/templates/BILLING_PROBLEM_CHARGE_CC.nap";
	public static final String BILLING_PROBLEM_CHARGE_ACH_FILE_PATH = "src/com/rackspace/brm/account/templates/BILLING_PROBLEM_CHARGE_ACH.nap";
	public static final String SPEND_THRESHOLD_LIMIT_FILE_PATH = "src/com/rackspace/brm/account/templates/SPEND_THRESHOLD_LIMIT.nap";
	public static final String BILLING_PREDRAFT_NOTIFICATION_FILE_PATH = "src/com/rackspace/brm/account/templates/BILLING_PREDRAFT_NOTIFICATION.nap";
	public static final String BILLING_EXPIRY_CC_FILE_PATH = "src/com/rackspace/brm/account/templates/BILLING_EXPIRY_CC.nap";
	public static final String EMAIL_INVOICE_PDF_FILE_PATH = "src/com/rackspace/brm/account/templates/EMAIL_INVOICE_PDF.nap";
	public static final String BILLING_PAYMENT_SUCCESS_CC_FILE_PATH = "src/com/rackspace/brm/account/templates/BILLING_PAYMENT_SUCCESS_CC.nap";
	public static final String EXPIRY_CC_NOTIFICATION_FILE_PATH = "src/com/rackspace/brm/account/templates/EXPIRY_CC_NOTIFICATION.nap";
	public static final String UKDD_PAYMENT_INITIATED_FILE_PATH="src/com/rackspace/brm/account/templates/UKDD_PAYMENT_INITIATED.nap";
	public static final String UKDD_PAYMENT_FAILED_FILE_PATH="src/com/rackspace/brm/account/templates/UKDD_PAYMENT_FAILED.nap";
	public static final String ACCOUNTCREATION_ACH_FILE_PATH ="src/com/rackspace/brm/account/templates/CreateAchUSAccount.json";
	/**
	 * Created for dedicated usage billing type
	 */
	public static final String DEDICATED_DAILY_BILLING_TYPE = "abc";
	public static final String DEDICATED_MONTHLY_BILLING_TYPE = "def";
	public static final String DEDICATED_MONTHLY_USAGE_FILE_PATH = "src/com/rackspace/brm/usage/templates/EBS_BillingLines_Monthly_Usage.csv";
	public static final String DEDICATED_DAILY_USAGE_FILE_PATH = "src/com/rackspace/brm/usage/templates/EBS_BillingLines_Daily_Usage.csv";

	
	public static final String CURRENCY_SYMBOL_840 = "$";
	public static final String CURRENCY_SYMBOL_826 = "�";
	public static final String CURRENCY_SYMBOL_36 = "$";
	public static final String CURRENCY_SYMBOL_978 = "�";
	public static final String CURRENCY_SYMBOL_344 = "$";
	
	
	public static final boolean isSuccessTrue = true;
	public static final boolean isSuccessFalse = false;
	
	
	
	
    public static final String FLIST_FOLDER_PATH_PROPERTY = "fListFolderPath";
    public static final String CSV_FOLDER_PATH_PROPERTY = "csvFolderPath";
    public static final String USAGE_FOLDER_PATH_PROPERTY = "usageFolderPath";
    public static final String PDF_FOLDER_PATH_PROPERTY = "pdfFolderPath";
    public static final String GL_FOLDER_PATH_PROPERTY = "glFolderPath";
    public static final String CMLOGS_FOLDER_PATH_PROPERTY = "cmlogsFolderPath";
    public static final String DMLOGS_FOLDER_PATH_PROPERTY = "dmlogsFolderPath";
    public static final String TAXLOGS_FOLDER_PATH_PROPERTY = "taxlogsFolderPath";
    public static final String JSON_FOLDER_PATH_PROPERTY = "jsonFolderPath";
    public static final String XML_FOLDER_PATH_PROPERTY = "xmlFolderPath";
    public static final String HTML_FOLDER_PATH_PROPERTY = "htmlFolderPath";

	
	

	/**
	 * This section to hold all enumerators
	 * 
	 *
	 */

	public enum AccountType {
		DEDICATED, CLOUD
	}

	public enum BillingType {
		DAILY_BILLING, MONTHLY_BILLING,
	}

	public enum PaymentType {
		CC, ACH_DD, UKDD, NLSEPA
	}

	public static String currencySymbol(String currency) {

		HashMap<String, String> CURRENCY_SYMBOL = new HashMap<String, String>();

		CURRENCY_SYMBOL.put("840", "$");
		CURRENCY_SYMBOL.put("826", "�");
		CURRENCY_SYMBOL.put("36", "$");
		CURRENCY_SYMBOL.put("978", "�");
		CURRENCY_SYMBOL.put("344", "$");

		String value = (String) CURRENCY_SYMBOL.get(currency);

		return value;

	}
}
