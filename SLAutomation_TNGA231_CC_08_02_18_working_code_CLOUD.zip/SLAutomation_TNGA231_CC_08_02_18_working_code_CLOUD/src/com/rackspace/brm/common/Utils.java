package com.rackspace.brm.common;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.Writer;
import java.nio.charset.Charset;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Properties;
import java.util.TimeZone;

import org.apache.log4j.Logger;
import org.json.JSONException;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;
import com.jcraft.jsch.SftpException;
import com.rackspace.brm.connection.BRMDBConnection;
import com.rackspace.brm.connection.BRMJSchConnection;
import com.rackspace.brm.connection.BazookaDBConnection;
import com.rackspace.brm.constants.BRMConstants;

/**
 * The Class UtilitiesMethods.
 */
public class Utils {

	/**
	 * The APP_LOGS used for capturing the message to be logged to the log file.
	 */
	public static final Logger APP_LOGS = Logger.getLogger("LoggerName");

	/** The createTestCaseFolder used to store create test case reports. */
	public static File createTestCaseFolder = null;

	/** The accounts PO billing directory. */
	public static File accountsPOBillingDirectory = null;

	/** The base file path. */
	public static File baseFilePath = new File(System.getProperty("user.dir") + File.separator + "TestNG_tests"
			+ File.separator + "report" + File.separator + "suite" + File.separator + "Accounts_PO_Billing");;

	/** The createFlistFolder used to store the FList in folder. */
	public static File createFlistFolderName = null;

	/** The createPinLogsFolder used to store the pin logs reports. */
	public static File createPinLogsFolder = null;

	/** The createJSonFolder used to store the JSON Report. */
	public static File createJSonFolder = null;

	/** The createHTMLFolder used to store the html Reports. */
	public static File createHTMLFolder = null;

	/**
	 * This methods contains the generates unique number with data methods, so
	 * that it can be used for account creation.
	 *
	 * @return account number
	 */
	public static String generateTenantId() {

		String tenantId = null;
		try {

			SimpleDateFormat sdfDate = new SimpleDateFormat("MMddHHmmss");
			Date now = new Date();
			String strDate = sdfDate.format(now);
			tenantId = strDate.toString();
		} catch (Exception e) {
			APP_LOGS.error("Account number cannot be created in generateAccountNo()", e);
		}
		return tenantId;
	}
	
	
	/**
	 * This methods contains the generates unique number with data methods, so
	 * that it can be used for account creation.
	 *
	 * @return account number
	 */
	public static String generatecurrentDate() {

		String currentDate = null;
		try {

			SimpleDateFormat sdfDate = new SimpleDateFormat("dd/MM/YYYY");
			Date now = new Date();
			String strDate = sdfDate.format(now);
			currentDate = strDate.toString();
		} catch (Exception e) {
			APP_LOGS.error("Account number cannot be created in generateAccountNo()", e);
		}
		return currentDate;
	}
	

	/**
	 * Gets the pvt for billing.
	 *
	 * @param dbParam            the db param
	 * @return the pvt for billing
	 * @throws Exception             the exception
	 */
	public static String getPvtNextBill(String dbParam) throws Exception {

		ResultSet rs = null;
		String queryResult = null;
		String query = null;
		PreparedStatement stmt = null;
		java.sql.Connection con = null;
		String billPvt = null;
		String pvtDateFormat = null;

		try {

			query = PropertyUtil.getCommonProperties().getProperty("nextBillDateQuery");

			con = BRMDBConnection.getBRMDBConnection();

			// create the statement object
			stmt = con.prepareStatement(query);
			stmt.setString(1, dbParam);

			rs = stmt.executeQuery();
			while (rs.next()) {
				queryResult = rs.getString(1);
			}

			pvtDateFormat = "MMddyyyy";

			// parsing String to Long
			long l = Long.parseLong(queryResult);

			l = l * 1000;
			// converting pvt to HumanDateFormat
			Timestamp timestamp = new Timestamp(l);
			Calendar cal = Calendar.getInstance();
			cal.setTimeInMillis(timestamp.getTime());
			// cal.add(Calendar.DAY_OF_WEEK, +4);
			timestamp = new Timestamp(cal.getTime().getTime());

			DateFormat forma = new SimpleDateFormat(pvtDateFormat);
			forma.setTimeZone(TimeZone.getTimeZone("UTC"));
			billPvt = forma.format(timestamp);
		}

		catch (ClassNotFoundException e) {
			APP_LOGS.error("Class Not Found Exception was caught in getPvtNextBill()" + e.getMessage());
		} catch (SQLException e) {
			APP_LOGS.error("DB connection cannot to be established in getPvtNextBill()" + e.getMessage());
		} catch (Exception e) {
			APP_LOGS.error("Specified file coudn't found or read in getPvtNextBill()" + e.getMessage());
		} finally {
			if (con != null) {
				try {
					stmt.close();
					rs.close();
					// con.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		return billPvt;

	}

	/**
	 * Generate random ID.
	 *
	 * @return the string
	 * @throws IOException
	 *             Signals that an I/O exception has occurred.
	 */
	public static String generateRandomID() throws IOException {
		return generateTenantId();
	}

	/**
	 * Conver to epoch time.
	 *
	 * @param argInDate
	 *            the arg in date
	 * @return the long
	 */
	public static long converToEpochTime(String argInDate) {
		long retEpochTime = 0;
		Date date = null;

		SimpleDateFormat df = new SimpleDateFormat("MMddHHmmyyyy");
		try {
			date = df.parse(argInDate);
		} catch (Exception ex) {
			ex.printStackTrace();
			return 0;
		}
		retEpochTime = (date.getTime()) / 1000;

		return retEpochTime;
	}

	/**
	 * This method used to read file contents.
	 *
	 * @param fileName
	 *            used to store the file name
	 * @return the string
	 */
	public static String readFile(String fileName) {

		StringBuilder sbBuilder = null;

		BufferedReader br = null;
		try {
			sbBuilder = new StringBuilder();
			br = new BufferedReader(new FileReader(fileName));
			String line = null;
			while ((line = br.readLine()) != null) {
				sbBuilder.append(line);
				sbBuilder.append("\n");
			}

		} catch (FileNotFoundException e) {
			APP_LOGS.error("Specified file cannot be found or read in readFile()");
		} catch (IOException e) {
			APP_LOGS.error("File cannot be found in readFile()");
		} finally {
			try {
				br.close();
			} catch (IOException e) {
				APP_LOGS.error("File not closed in readFile()");
			}
		}
		return sbBuilder.toString();
	}

	/**
	 * This createAccountsPOBillingDirectory() method used to creates the folder
	 * Accounts_PO_Billing.
	 *
	 * @throws IOException
	 *             Signals that an I/O exception has occurred
	 */

	public static void createAccountsPOBillingDirectory() throws IOException {
		accountsPOBillingDirectory = new File(baseFilePath + "");
		try {
			accountsPOBillingDirectory.mkdir();
		} catch (Exception e) {
			APP_LOGS.error(" Accounts_PO_Billing Folder not created createAccountsPOBillingDirectory()");
		}
	}

	/**
	 * This method used to creates the folder TS_ACCT in Accounts_PO_Billing.
	 *
	 * @throws IOException
	 *             Signals that an I/O exception has occurred
	 */

	public static void createTestCaseFolder() throws IOException {

		int testCaseIncrement = 1;

		String timestamp = generateTenantId();
		String folderName = "TS_ACCT_00";
		createTestCaseFolder = new File(File.separator + accountsPOBillingDirectory + File.separator + folderName
				+ testCaseIncrement + "_" + timestamp);
		try {
			createTestCaseFolder.mkdir();
		} catch (Exception e) {
			APP_LOGS.error("Test Case Folder not created createTestCaseFolder()");
		}
	}

	/**
	 * This testCaseDirectoryPath() method used to get the path of the test Case
	 * Folder Path.
	 *
	 * @return the string
	 */

	public static String testCaseFolderPath() {
		String testCasePath = createTestCaseFolder.toString();
		return testCasePath;
	}

	/**
	 * This createFlistFolder() method used to creates the folder Input and
	 * Output FList Folder in Accounts_PO_Billing.
	 *
	 * @throws IOException
	 *             Signals that an I/O exception has occurred
	 */
	public static void createFlistFolder() throws IOException {

		createFlistFolderName = new File(File.separator + createTestCaseFolder + File.separator + "Flist");
		try {
			createFlistFolderName.mkdir();
		} catch (Exception e) {
			APP_LOGS.error("Input and Output Flist folder not created createFlistFolder()");
		}
	}

	/**
	 * This flistFolderPath() method used to get the path of the FList Folder
	 * Path.
	 *
	 * @return FList Path
	 */
	public static String flistFolderPath() {
		String flistPath = createFlistFolderName.toString();
		return flistPath;
	}

	/**
	 * 
	 * This createPinLogsFolder() method used to creates Pinlog folder(cm_logs
	 * and dm_logs) in Accounts_PO_Billing.
	 * 
	 * @return createPinLogsFolder
	 * @throws IOException
	 *             Signals that an I/O exception has occurred.
	 */
	public static String createPinLogsFolder() throws IOException {

		createPinLogsFolder = new File(
				File.separator + createTestCaseFolder + File.separator + "pinlogs" + File.separator);
		try {
			createPinLogsFolder.mkdir();
		} catch (Exception e) {
			APP_LOGS.error("Pinlog output folder not created in createPinLogsFolder()");
		}
		return createPinLogsFolder.toString();
	}

	/**
	 * This pinLogsFolderDirectoryPath() method used to get the path of the Pin
	 * Logs Folder.
	 * 
	 * @return pinLogspath
	 */
	public static String pinLogsFolderDirectoryPath() {
		String pinLogspath = createPinLogsFolder.toString();
		return pinLogspath;
	}

	/**
	 * This createJSonFolder() method used to creates Json output folder in
	 * Accounts_PO_Billing.
	 *
	 * @throws IOException
	 *             Signals that an I/O exception has occurred.
	 */
	public static void createJSonFolder() throws IOException {

		createJSonFolder = new File(File.separator + createTestCaseFolder + File.separator + "Json");
		try {
			createJSonFolder.mkdir();

		} catch (Exception e) {
			APP_LOGS.error("Json output folder not created in createJSonFolder()");
		}
	}

	/**
	 * 
	 * This createHTMLFolder() method used to creates HTML output in
	 * Accounts_PO_Billing.
	 * 
	 * @throws IOException
	 *             Signals that an I/O exception has occurred.
	 */
	public static void createHTMLFolder() throws IOException {

		createHTMLFolder = new File(File.separator + createTestCaseFolder + File.separator + "HTML");
		try {
			createHTMLFolder.mkdir();

		} catch (Exception e) {
			APP_LOGS.error("HTML output folder not created createHTMLFolder()");
		}
	}

	/**
	 * 
	 * This createFile() method used to creates Input and output FList files in
	 * Accounts_PO_Billing.
	 * 
	 * @param content
	 *            used to set the Content of the In and Out FLists
	 * @param filename
	 *            used to set the File name of the In and Out FLists
	 * @return Returns the FList Filename
	 *//*
	public static String createFile(String content, String filename) {

		BufferedWriter bufferedWriter = null;
		Writer writer = null;
		File myFile = null;
		try {
			myFile = new File(createFlistFolderName + File.separator + filename + ".txt");
			if (!myFile.exists()) {
				myFile.createNewFile();
			}
			writer = new FileWriter(myFile);
			bufferedWriter = new BufferedWriter(writer);
			bufferedWriter.write(content);
		} catch (IOException e) {
			APP_LOGS.error("File not writing  in createFile()");
		} finally {
			try {
				if (writer != null) {
					writer.flush();

				}
				if (bufferedWriter != null) {
					bufferedWriter.flush();

				}
				writer.close();
				bufferedWriter.close();
			} catch (Exception ex) {
				// APP_LOGS.error("File not writing in createFile() finally
				// block", ex);
			}
		}
		return filename;
	}*/

	/**
	 * This method used to Add JSON string in BSL.
	 *
	 * @param json
	 *            used to store the JSON object
	 * @param testcaseName
	 *            the testcase name
	 * @param Polarity
	 *            the polarity
	 * @param suite
	 *            the suite
	 * @return the JSON object
	 * @throws JSONException
	 *             the JSON exception
	 */
	public static JsonObject addingJsonString(String json, String testcaseName, String Polarity, String suite)
			throws JSONException {

		Properties properties = PropertyUtil.getBslProperties();
		json = properties.getProperty(json).replace("DATEANDTIME", Utils.getISO8601StringForCurrentDate());
		json = json.replace("SUITENAME", suite);
		json = json.replace("TESTCASENAME", testcaseName);
		json = json.replace("POLARITYVALUE", Polarity);
		json = json.replace("modules", suite);
		json = json.replaceAll(",\\s*\"commands\"\\s*", " ");

		Gson gson = new Gson();
		JsonObject inputObj = gson.fromJson(json, JsonObject.class);
		JsonObject newObject = new JsonObject();
		inputObj.get("coverage").getAsJsonArray().add(newObject);
		return inputObj;
	}

	/**
	 * This method used to return an ISO 8601 combined date and time string for
	 * current date/time.
	 *
	 * @return String with format "yyyy-MM-dd'T'HH:mm:ss'Z'"
	 */
	public static String getISO8601StringForCurrentDate() {
		Date now = new Date();
		return getISO8601StringForDate(now);
	}

	/**
	 * This method used to return an ISO 8601 combined date and time string for
	 * specified date/time.
	 *
	 * @param date
	 *            reference of the Date object
	 * @return String with format "YYYY-MM-dd'T'HH:mm:ss'Z'"
	 */

	private static String getISO8601StringForDate(Date date) {
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
		dateFormat.setTimeZone(TimeZone.getTimeZone("IST"));
		return dateFormat.format(date);
	}

	/**
	 * This method used to creates the JSON file.
	 *
	 * @param content
	 *            used to set the Content of the JSON
	 * @param filename
	 *            used to set the File name of the JSON
	 */
	public static void createJsonFile(String content, String filename) {

		BufferedWriter bufferedWriter = null;
		try {
			File myFile = new File(Utils.createJSonFolder + File.separator + filename + ".json");
			if (!myFile.exists()) {
				myFile.createNewFile();
			}
			Writer writer = new FileWriter(myFile);
			bufferedWriter = new BufferedWriter(writer);
			bufferedWriter.write(content);
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				if (bufferedWriter != null)
					bufferedWriter.close();
			} catch (Exception ex) {
				APP_LOGS.error("Json folder not created in createJsonFile()", ex);
			}
		}
	}

	/**
	 * This method used to validate mandatory Fields.
	 *
	 * @param limit
	 *            Used for currency
	 * @param poid
	 *            Used for poidId
	 * @param optin
	 *            Used for optIn flag
	 * @param conEnt
	 *            Used for contracting entity
	 * @param paperLessInv
	 *            Used for paper less invoice
	 * @param supTeam
	 *            Used for support team
	 * @param payType
	 *            the pay type Used for payType
	 * @param paymentTerm
	 *            Used the payment term
	 * @param Out_BillDueAmount
	 *            Total bill due amount
	 * 
	 * @return success or failure.
	 */

	public static String mandatoryFiledValidation(String limit, String poid, String optin, String conEnt,
			String paperLessInv, String supTeam, String payType, String paymentTerm, String Out_BillDueAmount) {

		String message = "All values passed";
		try {

			if (limit.isEmpty() || limit.equalsIgnoreCase("null")) {
				message = "Limit values are null";
			} else if (poid.isEmpty() || poid.equalsIgnoreCase("null")) {
				message = "Poid values are null";
			} else if (optin.isEmpty() || optin.equalsIgnoreCase("null")) {
				message = "Optin values are null";
			} else if (conEnt.isEmpty() || conEnt.equalsIgnoreCase("null")) {
				message = "Contract Entity values are null";
			} else if (paperLessInv.isEmpty() || paperLessInv.equalsIgnoreCase("null")) {
				message = "Paper Less Invoice values are null";
			} else if (supTeam.isEmpty() || supTeam.equalsIgnoreCase("null")) {
				message = "Support Team values are null";
			} else if (payType.isEmpty() || payType.equalsIgnoreCase("null")) {
				message = "Pay Type values are null";
			} else if (paymentTerm.isEmpty() || paymentTerm.equalsIgnoreCase("null")) {
				message = "Payment Term values are null";
			} else if (Out_BillDueAmount.isEmpty() || Out_BillDueAmount.equalsIgnoreCase("null")) {
				message = "Bill Due Amount values are null";
			}

		} catch (Exception e) {
			message = "are null";
		}
		return message;
	}

	/**
	 * Scp file transfer get.
	 *
	 * @param puttyPath
	 *            the putty path
	 * @param fileToLocation
	 *            the file to location
	 */
	public static void scpFileTransferget(String puttyPath, String fileToLocation) {

		ChannelSftp sftpChannel = null;
		Session session = null;
		Channel channel = null;
		try {
			// Getting the Session object from BRMJSCHConnection
			session = BRMJSchConnection.getJschSession();
			session.connect(1500);
			channel = session.openChannel("sftp");
			channel.connect();
			sftpChannel = (ChannelSftp) channel;
			sftpChannel.get(puttyPath, fileToLocation);
			// session.disconnect();

		} catch (JSchException e) {
			APP_LOGS.error("JSCHConnection cannot be established in scpFileTransferget()", e);
		} catch (SftpException e) {
			APP_LOGS.error("file not transferred in scpFileTransferget()", e);
		} finally {
			sftpChannel.exit();
			// channel.disconnect();
			// session.disconnect();
		}
	}

	/**
	 * Gets the amount from total.
	 *
	 * @param usageAmount            the usage amount
	 * @param rowsCount the rows count
	 * @return the amount from total
	 */
	public static double splitUsageAmountFromTotal(Double usageAmount, String rowsCount) {

		double recordAmount = usageAmount / Integer.parseInt(rowsCount);
		recordAmount = Math.round(recordAmount * 100);
		recordAmount = recordAmount / 100;
		return recordAmount;
	}

	/**
	 * Gets the previous month pvt date.
	 *
	 * @param pvtDate
	 *            the pvt date
	 * @return the previous month pvt date
	 * @throws ParseException
	 *             the parse exception
	 */
	public static String getPreviousMonthPvtDate(String pvtDate) throws ParseException {

		String previousMonthEndDate = null;
		String monthFromDate = pvtDate.substring(2, 4);
		int date = Integer.parseInt(monthFromDate);
		SimpleDateFormat dateFormat = new SimpleDateFormat("MMddHHmmyyyy");
		Date convertedDate = dateFormat.parse(pvtDate);
		if (date < 6) {
			Calendar calendar = Calendar.getInstance();
			calendar.setTime(convertedDate);
			calendar.add(Calendar.MONTH, -1);
			int max = calendar.getActualMaximum(Calendar.DAY_OF_MONTH);
			calendar.set(Calendar.DAY_OF_MONTH, max);

			Date previousMontdate = calendar.getTime();
			previousMonthEndDate = dateFormat.format(previousMontdate);

		} else {
			previousMonthEndDate = dateFormat.format(convertedDate);
		}
		return previousMonthEndDate;
	}

	/**
	 * Validate DB.
	 *
	 * @param queryName
	 *            the query name
	 * @param dbParam
	 *            the db param
	 * @return the string
	 */
	public static String retrieveDetailsFromDB(String queryName, String dbParam) {

		APP_LOGS.info("Entry: retrieveDetailsFromDB() method");
		ResultSet rs = null;
		Connection connection = null;
		String queryResult = null;
		String query = null;
		PreparedStatement stmt = null;
		try {

			query = PropertyUtil.getCommonProperties().getProperty(queryName);

			connection = BRMDBConnection.getBRMDBConnection();
			stmt = connection.prepareStatement(query);
			stmt.setString(1, dbParam);

			rs = stmt.executeQuery();
			while (rs.next()) {
				queryResult = rs.getString(1);
				System.out.println(queryResult);
			}
			APP_LOGS.info("Exit: retrieveDetailsFromDB() method");
		} catch (Exception e) {
			APP_LOGS.error("Values not able to retrieve from DB in retrieveDetailsFromDB()" + e.getMessage());
		}
		return queryResult;

	}
	
	
	
	/**
	 * Validate DB.
	 *
	 * @param queryName
	 *            the query name
	 * @param dbParam
	 *            the db param
	 * @return the string
	 */
	public static String retrieveDetailsFromBazookaDB(String queryName, String dbParam) {

		APP_LOGS.info("Entry: retrieveDetailsFromDB() method");
		ResultSet rs = null;
		Connection connection = null;
		String queryResult = null;
		String query = null;
		PreparedStatement stmt = null;
		try {

			query = PropertyUtil.getCommonProperties().getProperty(queryName);

			connection = BazookaDBConnection.getBazookaDBConnection();
			stmt = connection.prepareStatement(query);
			stmt.setString(1, dbParam);
			
			System.out.println(query + "%%%%%%%");

			rs = stmt.executeQuery();
			while (rs.next()) {
				queryResult = rs.getString(1);
			}
			APP_LOGS.info("Exit: retrieveDetailsFromDB() method");
		} catch (Exception e) {
			APP_LOGS.error("Values not able to retrieve from DB in retrieveDetailsFromDB()" + e.getMessage());
		}
		return queryResult;

	}
	

	/**
	 * Gets the pvt for billing.
	 *
	 * @param dbParam            the db param
	 * @param pvtDateFormat the pvt date format
	 * @param numberOfdaystoExtend the number ofdaysto extend
	 * @param setPvt the set pvt
	 * @param enterPvt the enter pvt
	 * @return the pvt for billing
	 * @throws Exception             the exception
	 */
	public static String getPvtForBilling(String dbParam, String pvtDateFormat, int numberOfdaystoExtend, String setPvt,
			String enterPvt) throws Exception {

		ResultSet rs = null;
		String queryResult = null;
		String query = null;
		PreparedStatement stmt = null;
		java.sql.Connection con = null;
		String billPvt = null;
		// String pvtDateFormat = null;
		try {
			query = PropertyUtil.getCommonProperties().getProperty("nextBillDateQuery");
			con = BRMDBConnection.getBRMDBConnection();
			// create the statement object
			stmt = con.prepareStatement(query);
			stmt.setString(1, dbParam);

			rs = stmt.executeQuery();
			while (rs.next()) {
				queryResult = rs.getString(1);
			}

			// parsing String to Long
			long l = Long.parseLong(queryResult);

			l = l * 1000;
			// converting pvt to HumanDateFormat
			Timestamp timestamp = new Timestamp(l);
			Calendar cal = Calendar.getInstance();
			cal.setTimeInMillis(timestamp.getTime());
			cal.add(Calendar.DAY_OF_WEEK, +numberOfdaystoExtend);
			timestamp = new Timestamp(cal.getTime().getTime());

			DateFormat forma = new SimpleDateFormat(pvtDateFormat);
			forma.setTimeZone(TimeZone.getTimeZone("UTC"));
			billPvt = forma.format(timestamp);
		}

		catch (ClassNotFoundException e) {
			APP_LOGS.error("Class Not Found Exception was caught in validateDB()" + e.getMessage());
		} catch (SQLException e) {
			APP_LOGS.error("DB connection cannot to be established in validateDB()" + e.getMessage());
		} catch (Exception e) {
			APP_LOGS.error("Specified file coudn't found or read in validateDB()" + e.getMessage());
		} finally {
			if (con != null) {
				try {
					stmt.close();
					rs.close();
					// con.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		return setPvt + billPvt + enterPvt;

	}

	/**
	 * Creates the file.
	 *
	 * @param content
	 *            the content
	 * @param filename
	 *            the filename
	 * @return the file
	 */
	public static File createFilePo(String content, String filename) {

		BufferedWriter bufferedWriter = null;
		File myFile = new File(createFlistFolderName + File.separator + "\\" + filename + ".txt");
		try {
			if (!myFile.exists()) {
				myFile.createNewFile();
			}
			Writer writer = new FileWriter(myFile);
			bufferedWriter = new BufferedWriter(writer);
			bufferedWriter.write(content);

		} catch (IOException e) {
			APP_LOGS.error("File not reading in createFile()");
		} finally {
			try {
				if (bufferedWriter != null)
					bufferedWriter.close();
			} catch (Exception ex) {
				APP_LOGS.error("File not reading  in createFile() finally block");
			}
		}
		return myFile;
	}

	/**
	 * Read output file.
	 *
	 * @param file
	 *            the file
	 * @param fildname
	 *            the fildname
	 * @param seperater
	 *            the seperater
	 * @return the string
	 */
	public static String readOutputFile(File file, String fildname, String seperater) {

		String[] strings = null;
		try {
			BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(file)));
			String line;
			while ((line = br.readLine()) != null) {
				if (line.indexOf(fildname) != -1)
					break;
			}
			strings = line.split("\\" + seperater + "");
			// System.out.println("value for " + target + " is: " + s[1]);
			br.close();
		} catch (IOException ex) {
			APP_LOGS.error("File not reading  in ReadOutputFile()");
		}
		// System.out.println("s[1].toString()" + s[1].toString());
		return strings[1].toString();
	}

	/**
	 * Gets the pvt dates.
	 *
	 * @param pvtDate the pvt date
	 * @return the pvt dates
	 * @throws ParseException the parse exception
	 */
	public static String getPvtDates(String pvtDate) throws ParseException {

		String getPvtDate = null;
		String monthFromDate = pvtDate.substring(2, 4);
		int date = Integer.parseInt(monthFromDate);
		SimpleDateFormat dateFormat = new SimpleDateFormat("MMddHHmmyyyy");
		Date convertedDate = dateFormat.parse(pvtDate);
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(convertedDate);
		if (date < 6) {

			calendar.add(Calendar.MONTH, -1);
			int max = calendar.getActualMaximum(Calendar.DAY_OF_MONTH);
			calendar.set(Calendar.DAY_OF_MONTH, max);
			Date previousMonthDate = calendar.getTime();
			getPvtDate = dateFormat.format(previousMonthDate);

		} else {

			Date currenMonthDate = calendar.getTime();
			getPvtDate = dateFormat.format(currenMonthDate);

		}
		return getPvtDate;
	}
	
	/**
	 * Gets the double value.
	 *
	 * @param numbericString the numberic string
	 * @return the double value
	 */
	public static double getDoubleValue(String numbericString) {
		double dNumericValue = 0.0d;
		try {
			dNumericValue = Double.parseDouble(numbericString);
		} catch(NumberFormatException nfEx) {
			dNumericValue = 1000.00d;
		}
		return dNumericValue;
	}
	
	public static boolean isNullOrEmpty(String value) {
        return !(value != null && value.trim().length()>0 && !value.trim().equalsIgnoreCase("null"));
     }
	
	
	public static String createFile(String content, String filename) {
        
        APP_LOGS.info("Enter: createFile() method");
        String fListFolderPath = PropertyUtil.getCommonProperties().getProperty(BRMConstants.XML_FOLDER_PATH_PROPERTY);             
        BufferedWriter bufferedWriter = null;
        Writer writer = null;
        File myFile = null;
        try {
               Utils.APP_LOGS.info("File Name: " + fListFolderPath + File.separator + filename);
               myFile = new File(fListFolderPath + File.separator + filename);
               if (!myFile.exists()) {
                     myFile.createNewFile();
               }
               writer = new FileWriter(myFile);
               bufferedWriter = new BufferedWriter(writer);
               bufferedWriter.write(content);
        } catch (IOException e) {
               e.printStackTrace();
               APP_LOGS.error("File not writing  in createFile()");
        } finally {
               try {
                     if (writer != null) {
                            writer.flush();
                            
                     }
                     if (bufferedWriter != null) {
                            bufferedWriter.flush();
                            
                     }
                     writer.close();
                     bufferedWriter.close();
               } catch (Exception ex) {
                     APP_LOGS.error("Error occured while flushing the file writer createFile finally");
               }
        }
        APP_LOGS.info("Exit: createFile() method");
        return filename;
 }

	
	public static boolean createDirectory(String filePath) {
        APP_LOGS.info("Enter: createDirectory() method");
        boolean isCreated = true;
        File file = null;
        file = new File(filePath);
        isCreated = file.mkdirs();
        APP_LOGS.info("Exit: createDirectory() method");
        return isCreated;
 }

 public static void prepareTestDirectory() throws IOException{
     Utils.createDirectory(PropertyUtil.getCommonProperties().getProperty(BRMConstants.FLIST_FOLDER_PATH_PROPERTY));
       Utils.createDirectory(PropertyUtil.getCommonProperties().getProperty(BRMConstants.CSV_FOLDER_PATH_PROPERTY));
       Utils.createDirectory(PropertyUtil.getCommonProperties().getProperty(BRMConstants.USAGE_FOLDER_PATH_PROPERTY));              
       Utils.createDirectory(PropertyUtil.getCommonProperties().getProperty(BRMConstants.PDF_FOLDER_PATH_PROPERTY));
       Utils.createDirectory(PropertyUtil.getCommonProperties().getProperty(BRMConstants.GL_FOLDER_PATH_PROPERTY));
       Utils.createDirectory(PropertyUtil.getCommonProperties().getProperty(BRMConstants.CMLOGS_FOLDER_PATH_PROPERTY));
       Utils.createDirectory(PropertyUtil.getCommonProperties().getProperty(BRMConstants.DMLOGS_FOLDER_PATH_PROPERTY));
       Utils.createDirectory(PropertyUtil.getCommonProperties().getProperty(BRMConstants.TAXLOGS_FOLDER_PATH_PROPERTY));
       Utils.createDirectory(PropertyUtil.getCommonProperties().getProperty(BRMConstants.JSON_FOLDER_PATH_PROPERTY));
       Utils.createDirectory(PropertyUtil.getCommonProperties().getProperty(BRMConstants.XML_FOLDER_PATH_PROPERTY));
       Utils.createDirectory(PropertyUtil.getCommonProperties().getProperty(BRMConstants.HTML_FOLDER_PATH_PROPERTY));
      }



	/**
	 * The main method.
	 *
	 * @param args the arguments
	 * @throws Exception the exception
	 */
	public static void main(String[] args) throws Exception {
		/*String query1 = PropertyUtil.getCommonProperties().getProperty("nextBillDateQuery");
		String query2 = PropertyUtil.getCommonProperties().getProperty("pvtCmd");
		String query3 = PropertyUtil.getCommonProperties().getProperty("nextBillDateQuery");
		String query4 = PropertyUtil.getCommonProperties().getProperty("pvtCmd");
		File file = new File("Ramesh");
		file.mkdir();
		System.out.println("Query1:" + query1 + "\nQuery2:" + query2 + file.getName() + file.getAbsolutePath());
		System.out.println("Query1:" + query3 + "\nQuery2:" + query4);*/
		
		//System.out.println(generatecurrentDate());
		
		/*String Effective_Date = Utils.generatecurrentDate();*/
		
		String Effective_Date = "120400002017";
		
		System.out.println("Effective_Date "+ Effective_Date);
		System.out.println("PVT" +Utils.converToEpochTime(Effective_Date));
	}
	
	/*
	 * 
	 */
	public static String createFile1(String content, String filename) {
        APP_LOGS.info("Enter: createFileFromPath() method");
        try (BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(new File(filename)))) {
               bufferedWriter.write(content);
        } catch (IOException e) {
               APP_LOGS.error("File not writing  in createFile()");
        }
        APP_LOGS.info("Exit: createFileFromPath() method");
        return filename;
 } 
	
public static void convertJsonToXml(String parentTag, String filename) throws JSONException, IOException {
		
		APP_LOGS.info("Enter: convertJsonToXml() method");
		String jsonFolderPath = PropertyUtil.getCommonProperties().getProperty(BRMConstants.JSON_FOLDER_PATH_PROPERTY);
		String xmlFolderPath = PropertyUtil.getCommonProperties().getProperty(BRMConstants.XML_FOLDER_PATH_PROPERTY);
		
		File inPutPath = new File(jsonFolderPath + File.separator + "BRMJsonTestResult.json");
		File outPutPath = new File(xmlFolderPath + File.separator + filename + ".xml");
		
		if (!outPutPath.exists()) {
			outPutPath.createNewFile();
		}
		
        String jsonObj = readJsonFile(inPutPath);
		
        org.json.JSONObject jsonFileObject = new org.json.JSONObject(jsonObj);
		String xml = "<?xml version=\"1.0\" encoding=\"ISO-8859-15\"?>\n<"+parentTag+">" 
                + org.json.XML.toString(jsonFileObject) + "</"+parentTag+">";
		
		FileWriter ofstream = new FileWriter(outPutPath);
        try (BufferedWriter out = new BufferedWriter(ofstream)) {
            out.write(xml);
        }
        APP_LOGS.info("Exit: convertJsonToXml() method");
	}

public static String readJsonFile(File inPutPath) throws FileNotFoundException, IOException {
    
	APP_LOGS.info("Enter: readJsonFile() method");
    StringBuilder sb = new StringBuilder();
    InputStream in = new FileInputStream(inPutPath);
    Charset encoding = Charset.defaultCharset();
    
    Reader reader = new InputStreamReader(in, encoding);
    
    int r = 0;
    while ((r = reader.read()) != -1) {
        char ch = (char) r;
        sb.append(ch);
    }
    in.close();
    reader.close();
    APP_LOGS.info("Exit: readJsonFile() method");
    return sb.toString();
}
	

}
