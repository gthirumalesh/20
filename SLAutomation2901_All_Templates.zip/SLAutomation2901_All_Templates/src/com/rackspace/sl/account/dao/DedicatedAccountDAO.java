package com.rackspace.sl.account.dao;

import java.io.File;
import java.io.IOException;
import java.io.StringWriter;

import org.apache.commons.lang3.SerializationUtils;
import org.apache.velocity.Template;
import org.apache.velocity.VelocityContext;
import org.apache.velocity.app.VelocityEngine;

import com.portal.pcm.EBufException;
import com.portal.pcm.FList;
import com.rackspace.brm.account.constants.AccountConstants;
import com.rackspace.brm.account.model.Account;
import com.rackspace.brm.common.PropertyUtil;
import com.rackspace.brm.common.Utils;
import com.rackspace.brm.common.parser.FListParser;
import com.rackspace.brm.constants.BRMConstants;
import com.rackspace.brm.jobs.OpcodeExecutor;
import com.rackspace.sl.connection.RestAPIConnection;
import com.rackspace.sl.constants.SLConstants;
import com.rackspace.sl.event.constants.EventConstants;
import com.rackspace.sl.model.AcountParser;
import com.rackspace.sl.rbacprofile.model.RBACProfile;
import com.rackspace.sl.validation.ResponseCodeValidation;

import io.restassured.mapper.ObjectMapperType;
import io.restassured.response.Response;

/**
 * The Class DedicatedAccountDAO is used to communicate with BRM
 */
public class DedicatedAccountDAO {

	/**
	 * Instantiates a new dedicated account DAO.
	 */
	public DedicatedAccountDAO() {
	}

	public String prepareCustCommitFlistString(Account account) throws Exception {
		String opcTemplate = BRMConstants.DEDICATED_ACCT_CREATE_OPC_FILE_PATH;
		VelocityEngine velocityEngine = new VelocityEngine();
		StringWriter writer = null;
		try {
			velocityEngine.init();

			/* next, get the Template */
			Template template = velocityEngine.getTemplate(opcTemplate);
			/* create a context and add data */
			VelocityContext velocityContext = new VelocityContext();
			velocityContext.put("LIMIT", account.getCurrency());
			velocityContext.put("PAYMENTTYPE", account.getPayinfoList().get(0).getPaymentType());
			velocityContext.put("OPTINFLAG", account.getAccountProfile().getOptinFlag());
			velocityContext.put("CE", account.getAccountProfile().getContractingEntity());
			velocityContext.put("PAPERLESSINVOICE", account.getAccountProfile().getPaperlessInvoiceFlag());
			velocityContext.put("SUPPORTTEAM", account.getAccountProfile().getSupportTeam());
			velocityContext.put("PAYTERM", account.getAccountProfile().getPaymentTerm());
			velocityContext.put("STARTDATE", account.getStartDate());
			velocityContext.put("ENDDATE", account.getEndDate());
			velocityContext.put("TENANT_ID", account.getTenantId());
			velocityContext.put("PAYTYPE", account.getPayinfoList().get(0).getPayType());

			/* now render the template into a StringWriter */
			writer = new StringWriter();
			template.merge(velocityContext, writer);
		} catch (Exception ex) {
			throw new Exception("Error occured while preparing flist string using velocity template builder", ex);
		}
		// CREATING CUST COMMIT NAP FILE IN LOCAL DIRECTORY FOR REFERENCE
		Utils.createFile(writer.toString(), "FList_" + "_RAX_OP_CUST_COMMIT_CUSTOMER.in." + account.getTenantId());
		return writer.toString();
	}

	/**
	 * Creates the customer account in BRM.
	 *
	 * @param inputFList
	 *            the input FList
	 * @return the outputFList
	 * @throws IOException
	 *             Signals that an I/O exception has occurred.
	 * @throws EBufException
	 *             the EBuf exception
	 */
	public FList createCustomerAccountInBRM(FList inputFList) throws IOException, EBufException {
		FList outputFlist = OpcodeExecutor.executeOpcode(inputFList, BRMConstants.CUSTOMER_CUST_COMMIT_OPCODE);
		return outputFlist;
	}

	/**
	 * Creates the customer account in BRM.
	 *
	 * @param inputStringFList
	 *            the input string FList
	 * @return the FList
	 * @throws IOException
	 *             Signals that an I/O exception has occurred.
	 * @throws EBufException
	 *             the EBuf exception
	 */
	public Account createCustomerAccountInBRM(Account ipAccount) throws IOException, EBufException, Exception {
		String inputStringFList = this.prepareCustCommitFlistString(ipAccount);
		FList outputFList = OpcodeExecutor.executeOpcode(inputStringFList, BRMConstants.RAX_OP_CUST_COMMIT_CUSTOMER);
		Account account = FListParser.parseCustCommitOutputFlist(outputFList);
		Utils.createFile(outputFList.toString(), "Flist_0_RAX_OP_CUST_COMMIT_CUSTOMER.out" + account.getTenantId());
		return account;
	}

	public boolean getCustomerAccount(Account ipAccount, RBACProfile rbacProfile) throws IOException, EBufException, Exception {
		
		String uri = SLConstants.GET_ACCOUNT.replace("$env",
				PropertyUtil.getBslProperties().getProperty(SLConstants.ENVIORNMENT)).replace("$accountNumber", ipAccount.getAccountNumber());
				
		RestAPIConnection.executeGetRestAPIConnectionWithToken(uri, SLConstants.ACCEPT_APPLICATION_JSON, SLConstants.CONTENT_TYPE_APPLICATION_JSON, rbacProfile.getToken(), "");
		
		return true;

        /* System.out.println(" *************************uri ************************"+uri );
		return true;*/
		
	}
	
	
	/**
	 * Consolidate customer account in BRM.
	 *
	 * @param inputStringFList
	 *            the input string F list
	 * @return the f list
	 * @throws IOException
	 *             Signals that an I/O exception has occurred.
	 * @throws EBufException
	 *             the e buf exception
	 */
	public FList consolidateCustomerAccountInBRM(String inputStringFList) throws IOException, EBufException {

		FList outputFList = OpcodeExecutor.executeOpcode(inputStringFList, BRMConstants.RAX_OP_CUST_MOVE_ACCOUNT);
		return outputFList;
	}

	public static void main(String[] args) throws Exception {
		DedicatedAccountDAO dao = new DedicatedAccountDAO();
		Account act = new Account();
		dao.prepareCustCommitFlistString(act);
	}

	public Account createCustomerAccountInBRM(Account ipAccount, RBACProfile myRBACprofile) throws IOException, EBufException, Exception {
	
		Account opAccount = new Account();
		
		String inputStringJson = this.prepareCustJsonString(ipAccount);
		
		//System.out.println(" inputStringJson in DedicatedAccountDAO class == \n"+inputStringJson);
		String uri = SLConstants.CREATE_DEDICATED_SL_ACCOUNT_URI.replace("$env",
				PropertyUtil.getBslProperties().getProperty(SLConstants.ENVIORNMENT));
		
		Response response = RestAPIConnection.executeGetRestAPIConnectionPostWithToken(uri, SLConstants.ACCEPT_APPLICATION_JSON, SLConstants.CONTENT_TYPE_APPLICATION_JSON, myRBACprofile.getToken(), inputStringJson);
		
		System.out.println("response in dedicateddao =======" + response.getBody().asString());
		
		opAccount = AcountParser.parseCreateAccountJson(response, ipAccount);
		
		return opAccount;
		
	}
	
	
	public String prepareCustJsonString(Account account) throws Exception {
		String opcTemplate = SLConstants.DEDICATED_ACCT_CREATE_JSON_FILE_PATH;
		VelocityEngine velocityEngine = new VelocityEngine();
		StringWriter writer = null;
		try {
			velocityEngine.init();

			/* next, get the Template */
			Template template = velocityEngine.getTemplate(opcTemplate);
			/* create a context and add data */
			VelocityContext velocityContext = new VelocityContext();
			
			
			
			velocityContext.put("SLALIASID", account.getTenantId());
			velocityContext.put("SLEXTERNALSYSTEMID", account.getAccountProfile().getCoreAccountNumber());
			velocityContext.put("SLCURRENCY", account.getCurrency());
			velocityContext.put("SLCONTRACTENTITY", account.getAccountProfile().getContractingEntity());
			velocityContext.put("SLNOTIFICATIONOPTION", account.getAccountProfile().getOptinFlag());
			
			if (account.getAccountType().equals(AccountConstants.AccountType.DEDICATED)) {
				velocityContext.put("SLLINEOFBUSINESS", AccountConstants.AccountType.DEDICATED);
			}else if (account.getAccountType().equals(AccountConstants.AccountType.UKCLOUD)){
				velocityContext.put("SLLINEOFBUSINESS", AccountConstants.AccountType.UKCLOUD);
			}else if (account.getAccountType().equals(AccountConstants.AccountType.USCLOUD)){
				velocityContext.put("SLLINEOFBUSINESS", AccountConstants.AccountType.USCLOUD);
			}
			
			velocityContext.put("SLINVOICEDELIVERYMETHOD", account.getAccountProfile().getPaperlessInvoiceFlag());
			velocityContext.put("SLSIGNUPDATE", account.getStartDate());
			velocityContext.put("SLPAYMENTTYPE", account.getAccBillInfoList().get(0).getPayType());
			velocityContext.put("SLPAYMENTTERMS", account.getAccountProfile().getPaymentTerm());
			velocityContext.put("SLTAXID", account.getAccountProfile().getVatNumber());
			
			/* now render the template into a StringWriter */
			writer = new StringWriter();
			template.merge(velocityContext, writer);
			
			//System.out.println("writer    >>>>>>>>>>>>>>>"+writer.toString());
		} catch (Exception ex) {
			throw new Exception("Error occured while preparing JSON string using velocity template builder", ex);
		}
		// CREATING CUST COMMIT NAP FILE IN LOCAL DIRECTORY FOR REFERENCE
		//Utils.createFile(writer.toString(), "FList_" + "_RAX_OP_CUST_COMMIT_CUSTOMER.in." + account.getTenantId());
		
		//System.out.println("writer Starting   >>>>>>>>>>>>>>> \n"+writer.toString()+"\n writer Ending   >>>>>>>>>>>>>>> \n");
		
		return writer.toString();
	}

}
