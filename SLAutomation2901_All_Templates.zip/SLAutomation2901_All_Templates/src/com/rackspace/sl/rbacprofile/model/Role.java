
package com.rackspace.sl.rbacprofile.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/**
 * The Class Role.
 */
public class Role {

    /** The name. */
    @SerializedName("name")
    @Expose
    private String name;
    
    /** The description. */
    @SerializedName("description")
    @Expose
    private String description;
    
    /** The id. */
    @SerializedName("id")
    @Expose
    private String id;
    
    /** The tenant id. */
    @SerializedName("tenantId")
    @Expose
    private String tenantId;

    /**
     * Gets the name.
     *
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the name.
     *
     * @param name the new name
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * Gets the description.
     *
     * @return the description
     */
    public String getDescription() {
        return description;
    }

    /**
     * Sets the description.
     *
     * @param description the new description
     */
    public void setDescription(String description) {
        this.description = description;
    }

    /**
     * Gets the id.
     *
     * @return the id
     */
    public String getId() {
        return id;
    }

    /**
     * Sets the id.
     *
     * @param id the new id
     */
    public void setId(String id) {
        this.id = id;
    }

    /**
     * Gets the tenant id.
     *
     * @return the tenant id
     */
    public String getTenantId() {
        return tenantId;
    }

    /**
     * Sets the tenant id.
     *
     * @param tenantId the new tenant id
     */
    public void setTenantId(String tenantId) {
        this.tenantId = tenantId;
    }

}
