package com.rackspace.sl.rbacprofile.constants;

/**
 * The Class RBACprofileConstants.
 */
public final class RBACProfileConstants {

	/** The Constant BSL_SYSTEM_ROLE_USERNAME. */
	public static final String BSL_SYSTEM_ROLE_USERNAME = "bslSystemRoleUsername";

	/** The Constant BSL_SYSTEM_ROLE_PASSWORD. */
	public static final String BSL_SYSTEM_ROLE_PASSWORD = "bslSystemRolePassword";

	/** The Constant PROMOTION_AUTH_USERNAME. */
	public static final String PROMOTION_AUTH_USERNAME = "promotionAuthUsername";

	/** The Constant PROMOTION_AUTH__PASSWORD. */
	public static final String PROMOTION_AUTH__PASSWORD = "promotionAuthPassword";

	/** The Constant BSL_SYSTEM_ROLE_AUTH_XML. */
	public static final String BSL_SYSTEM_ROLE_AUTH_XML = "src/com/rackspace/sl/rbacprofile/template/AuthenticationXML.xml";

	/** The Constant BSL_SYSTEM_ROLE_URL. */
	public static final String BSL_SYSTEM_ROLE_URL = "https://staging.identity.api.rackspacecloud.com/v2.0/tokens";

	/**
	 * The Enum RBACprofileType.
	 */
	public enum RBACprofileType {

		/** The bsl system role. */
		BSL_SYSTEM_ROLE,
		/** The promotion auth. */
		PROMOTION_AUTH,
		CASH_APPS_ROLE
	}

}
