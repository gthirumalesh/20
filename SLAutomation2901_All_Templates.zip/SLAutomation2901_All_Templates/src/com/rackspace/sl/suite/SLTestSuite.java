package com.rackspace.sl.suite;

import java.io.IOException;

import org.junit.Assert;
import org.testng.Reporter;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.rackspace.sl.account.action.AccountAction;
import com.rackspace.sl.account.builder.AccountBuilder;
import com.rackspace.brm.account.constants.AccountConstants.AccountType;
import com.rackspace.brm.account.model.Account;
import com.rackspace.brm.common.Utils;
import com.rackspace.brm.validation.AccountValidation;
import com.rackspace.sl.constants.SLConstants;
import com.rackspace.sl.event.action.EventAction;
import com.rackspace.sl.event.builder.EventBuilder;
import com.rackspace.sl.event.constants.EventConstants.EventType;
import com.rackspace.sl.event.model.Event;
import com.rackspace.sl.rbacprofile.action.RBACProfileAction;
import com.rackspace.sl.rbacprofile.builder.RBACProfileBuilder;
import com.rackspace.sl.rbacprofile.constants.RBACProfileConstants.RBACprofileType;
import com.rackspace.sl.rbacprofile.model.RBACProfile;
import com.rackspace.sl.validation.NotificationValidation;

/**
 * The Class SLTestSuite.
 */

public class SLTestSuite {

	/**
	 * Prepare report folder.
	 */
	@BeforeTest(alwaysRun = true)
	public void prepareReportFolder() {
		try {
			Utils.APP_LOGS.info("Enter: prepareReportFolder()");

			Utils.prepareTestDirectory();

			Utils.APP_LOGS.info("Exit: prepareReportFolder()");

		} catch (IOException e) {

			Utils.APP_LOGS.error("IOException in prepareReportFolder " + e);
		}
	}

	/**
	 * S L T S ACC T 01 validate create AQ notification for billing primary
	 * method changed.
	 *
	 * @param templateType
	 *            the template type
	 * @param profile
	 *            the profile
	 * @param currency
	 *            the currency
	 * @param payType
	 *            the pay type
	 * @param notificationOption
	 *            the notification option
	 * @param contractingEntity
	 *            the contracting entity
	 * @param invoiceDeliveryMethod
	 *            the invoice delivery method
	 * @param supportTeam
	 *            the support team
	 * @param paymentTerm
	 *            the pay term
	 * @param vatNumber
	 *            the vat number
	 * @param paymentType
	 *            the payment type
	 * @param inPvt
	 *            the in pvt
	 * @param polarity
	 *            the polarity
	 * @param testMethodName
	 *            the test method name
	 * @param suiteName
	 *            the suite name
	 * @param jsonFileName
	 *            the json file name
	 * @param xmlFileName
	 *            the xml file name
	 * @param xmlParentTagName
	 *            the xml parent tag name
	 */
	@Test(groups = { "Component", "Regression" })
	@Parameters({ "In_TemplateType", "In_Profile", "In_Currency", "In_Paytype", "In_NotificationOption",
			"In_ContractingEntity", "In_InvoiceDeliveryMethod", "In_SupportTeam", "In_PaymentTerm", "In_VatNumber",
			"In_PaymentType", "In_Pvt", "In_Polarity", "Out_Testname", "Out_Suitename", "Out_JsonFileName",
			"Out_XmlFileName", "Out_XmlParentTagName" })
	public void SL_TS_ACCT_01_validateCreateAQNotificationForBillingPrimaryMethodChanged(String templateType,
			String profile, String currency, String payType, String notificationOption, String contractingEntity,
			String invoiceDeliveryMethod, String supportTeam, String paymentTerm, String vatNumber, String paymentType,
			String inPvt, String polarity, String testMethodName, String suiteName, String jsonFileName,
			String xmlFileName, String xmlParentTagName) {

		try {

			Utils.APP_LOGS
					.info("Starting SL_TS_ACCT_01_validateCreateAQNotificationForBillingPrimaryMethodChanged testcase");

			// Step 1: Generate Token
			RBACProfileBuilder rbacProfileBuilder = null;

			if (Utils.isNullOrEmpty(profile) || profile.equals(RBACprofileType.BSL_SYSTEM_ROLE.toString())) {
				rbacProfileBuilder = new RBACProfileBuilder(RBACprofileType.BSL_SYSTEM_ROLE);
			} else if (profile.equals(RBACprofileType.PROMOTION_AUTH.toString())) {
				rbacProfileBuilder = new RBACProfileBuilder(RBACprofileType.PROMOTION_AUTH);
			}

			RBACProfile ipRBACProfile = rbacProfileBuilder.getRBACProfile();

			// Create RBACprofileAction object
			RBACProfileAction rbacProfileAction = new RBACProfileAction();
			ipRBACProfile = rbacProfileAction.getToken(ipRBACProfile);
			// Validate Token Generation
			Assert.assertNotNull(ipRBACProfile.getToken());

			String step1 = "Step 1: Token generated successfully for ";

			Utils.APP_LOGS.info(step1 + RBACprofileType.BSL_SYSTEM_ROLE);
			Utils.APP_LOGS.info(
					"The generated Token for " + RBACprofileType.BSL_SYSTEM_ROLE + " is " + ipRBACProfile.getToken());
			Reporter.log(step1 + RBACprofileType.BSL_SYSTEM_ROLE);

			// Step 2: Validate the GET TEMPLATE call from BAZOOKA to fetch the
			// template for "BILLING_PRIMARY_METHOD_CHANGED"
			EventBuilder eventGetTemplateByIDBuilder = new EventBuilder(EventType.GET_TEMPLATE_ID, templateType);
			Event emailTemplateByIDEvent = eventGetTemplateByIDBuilder.getEvent();

			String emailTemplateByIDEventas = emailTemplateByIDEvent.getTemplateType();
			System.out.println("%%%%%%%%%%%%%%%%%%%%%% Template name is : " + emailTemplateByIDEventas);
			Utils.APP_LOGS.info("%%%%%%%%%%%%%%%%%%%%%% Template name is : " + emailTemplateByIDEventas);
			EventAction eventTemplateByIDAction = new EventAction();
			Assert.assertTrue(eventTemplateByIDAction.getTemplateById(emailTemplateByIDEvent, ipRBACProfile));

			String step2 = "Step 2: Validate the GET TEMPLATE call from BAZOOKA to fetch the template for BILLING_PREDRAFT_NOTIFICATION";

			Utils.APP_LOGS.info(step2);
			Reporter.log(step2);

			// Step 3 Create a account using BSL V2 "create account" api
			AccountBuilder accountBuilder = new AccountBuilder(AccountType.DEDICATED, Utils.generateTenantId(),
					Utils.generateTenantId(), currency, payType, notificationOption, contractingEntity,
					invoiceDeliveryMethod, supportTeam, paymentTerm, vatNumber, paymentType, invoiceDeliveryMethod,
					notificationOption, Utils.getISO8601StringForCurrentDate(),
					String.valueOf(Utils.converToEpochTime(Utils.getPreviousMonthPvtDate(inPvt))), paymentType);

			Account ipAccount = accountBuilder.getAccount();

			AccountAction accountAction = new AccountAction();
			Account opAccount = accountAction.createAccount(ipAccount, ipRBACProfile);
			System.out.println("Account number ############" + opAccount.getAccountNumber());
			Assert.assertFalse(Utils.isNullOrEmpty(opAccount.getAccountNumber()));

			String step3 = "Step 3: Create a account using BSL V2 create account api";

			Utils.APP_LOGS.info(step3);
			Reporter.log(step3);

			// Step 4 Validate the account is created using "GET ACCOUNT" call
			// from BSL
			Assert.assertTrue(accountAction.validateSLAccount(opAccount, ipRBACProfile));

			String step4 = "Step 4: Validate the account is created using GET ACCOUNT call from BSL";

			Utils.APP_LOGS.info(step4);
			Reporter.log(step4);

			// Step 5 Call the "PCM_OP_PUBLISH_GEN_PAYLOAD" (opcode 1301)
			Account eventAccount = eventTemplateByIDAction.publishEvent(opAccount, emailTemplateByIDEvent);

			AccountValidation.ValidatePaymentMethod(eventAccount);

			String step5 = "Step 5: Call PCM_OP_PUBLISH_GEN_PAYLOAD (opcode 1301)";

			Utils.APP_LOGS.info(step5);
			Reporter.log(step5);

			// Step 6 Validate Notification Event NotificationEvent =
			eventTemplateByIDAction.getNotificationID(opAccount.getAccountNumber(), SLConstants.NOTIFICATION_QUERY);

			String step6 = "Step 6: Validate Notification in Bazooka DB";

			Utils.APP_LOGS.info(step6);
			Reporter.log(step6);

			/*
			 * EventBuilder eventGetNotificationBuilder = new
			 * EventBuilder(EventType.GET_NOTIFICATION, templateType); Event
			 * emailNotificationEvent = eventGetNotificationBuilder.getEvent();
			 * //emailNotificationEvent.setNotificationID(NotificationEvent.
			 * getNotificationID());
			 * 
			 * emailNotificationEvent =
			 * eventTemplateByIDAction.getNotification(emailNotificationEvent,
			 * ipRBACProfile);
			 * 
			 * 
			 * NotificationValidation.validateNotificationStatus(
			 * emailNotificationEvent);
			 * 
			 * String step7 =
			 * "Step 7: Validate Notification using Get Notification";
			 * 
			 * Utils.APP_LOGS.info(step7); Reporter.log(step7);
			 */

			/*
			 * // To create JSON object JsonObject jsonObject =
			 * Utils.addingJsonString("BRMCITJSON", testMethodName, polarity,
			 * suiteName); Utils.createJsonFile(String.valueOf(jsonObject),
			 * jsonFileName); Utils.convertJsonToXml(xmlParentTagName,
			 * xmlFileName);
			 */
		} catch (NullPointerException e) {
			Utils.APP_LOGS
					.error("Null pointer exception in SL_TS_ACCT_01_validateCreateAQNotificationForBillingPrimaryMethodChanged "
							+ e);
		} catch (Exception e) {
			Utils.APP_LOGS
					.error("Exception while executing SL_TS_ACCT_01_validateCreateAQNotificationForBillingPrimaryMethodChanged "
							+ e);
		}

	}

}
