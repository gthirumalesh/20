
package com.rackspace.sl.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/**
 * The Class BillInfo.
 */
public class BillInfo {

    /** The billing day of month. */
    @SerializedName("billingDayOfMonth")
    @Expose
    private Integer billingDayOfMonth;
    
    /** The invoice delivery method. */
    @SerializedName("invoiceDeliveryMethod")
    @Expose
    private String invoiceDeliveryMethod;

    /**
     * Gets the billing day of month.
     *
     * @return the billing day of month
     */
    public Integer getBillingDayOfMonth() {
        return billingDayOfMonth;
    }

    /**
     * Sets the billing day of month.
     *
     * @param billingDayOfMonth the new billing day of month
     */
    public void setBillingDayOfMonth(Integer billingDayOfMonth) {
        this.billingDayOfMonth = billingDayOfMonth;
    }

    /**
     * Gets the invoice delivery method.
     *
     * @return the invoice delivery method
     */
    public String getInvoiceDeliveryMethod() {
        return invoiceDeliveryMethod;
    }

    /**
     * Sets the invoice delivery method.
     *
     * @param invoiceDeliveryMethod the new invoice delivery method
     */
    public void setInvoiceDeliveryMethod(String invoiceDeliveryMethod) {
        this.invoiceDeliveryMethod = invoiceDeliveryMethod;
    }

}
