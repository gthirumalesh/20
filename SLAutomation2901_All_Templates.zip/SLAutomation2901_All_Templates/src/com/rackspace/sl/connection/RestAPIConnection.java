package com.rackspace.sl.connection;

import org.eclipse.jetty.http.HttpStatus;
import org.testng.Assert;

import com.rackspace.brm.common.Utils;
import com.rackspace.brm.constants.BRMConstants;
import com.rackspace.sl.validation.ResponseCodeValidation;

import io.restassured.RestAssured;
import io.restassured.http.Method;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

/**
 * The Class HTTPConnectionExecutor.
 */
public class RestAPIConnection {

	/**
	 * Execute get rest API connection with token.
	 *
	 * @param uri
	 *            the uri
	 * @param accept
	 *            the accept
	 * @param content
	 *            the content
	 * @param token
	 *            the token
	 * @param body
	 *            the body
	 * @return the response
	 */
	public static synchronized Response executeGetRestAPIConnectionWithToken(String uri, String accept, String content,
			String token, String body) {

		// Specify the base URL to the RESTful web service
		RestAssured.baseURI = uri;

		RestAssured.useRelaxedHTTPSValidation();

		// Get the RequestSpecification of the request that you want to sent
		// to the server. The server is specified by the BaseURI that we have
		// specified in the above step.
		RequestSpecification httpRequest = RestAssured.given().header("X-Auth-Token", token).accept(accept)
				.contentType(content).body(body);

		// Make a request to the server by specifying the method Type and the
		// method
		// URL.
		// This will return the Response from the server. Store the response in
		// a
		// variable.

		Response response = httpRequest.request(Method.GET);

		Utils.APP_LOGS.info("Enter: validate Response Code 200");

		Assert.assertEquals(response.getStatusCode(), HttpStatus.OK_200);

		Utils.APP_LOGS.info("Exit: validate Response Code 200");

		ResponseCodeValidation.validateResponseCode200(response);
		
		String responseBody = response.getBody().asString();

		System.out.println("Response Body of Template ==> ==> ==> " + responseBody);


		return response;

	}

	/**
	 * Execute get rest API connection post with token.
	 *
	 * @param uri
	 *            the uri
	 * @param accept
	 *            the accept
	 * @param content
	 *            the content
	 * @param token
	 *            the token
	 * @param body
	 *            the body
	 * @return the response
	 */
	public static synchronized Response executeGetRestAPIConnectionPostWithToken(String uri, String accept,
			String content, String token, String body) {

		// Specify the base URL to the RESTful web service
		RestAssured.baseURI = uri;

		RestAssured.useRelaxedHTTPSValidation();

		// Get the RequestSpecification of the request that you want to sent
		// to the server. The server is specified by the BaseURI that we have
		// specified in the above step.

		RequestSpecification httpRequest = null;

		httpRequest = RestAssured.given().header("X-Auth-Token", token).accept(accept).contentType(content).body(body);

		String post = "POST";

		/*
		 * if (token != null) {
		 * 
		 * httpRequest = RestAssured.given()
		 * .accept(accept).contentType(content).body(body);
		 * 
		 * }else {
		 * 
		 * httpRequest = RestAssured.given().header("X-Auth-Token", token)
		 * .accept(accept).contentType(content).body(body);
		 * 
		 * }
		 */

		// Make a request to the server by specifying the method Type and the
		// method
		// URL.
		// This will return the Response from the server. Store the response in
		// a
		// variable.
		// Response response = httpRequest.request(Method.valueOf(post));

		Response response = httpRequest.request(Method.POST);

		Utils.APP_LOGS.info("Enter: validate Response Code 201");

		// Assert.assertEquals(response.getStatusCode(),
		// HttpStatus.CREATED_201);

		Utils.APP_LOGS.info("Exit: validate Response Code 201");

		// Now let us print the body of the message to see what response
		// we have recieved from the server
		String responseBody = response.getBody().asString();

		System.out.println("Response Body of Template =========>>>>>>>>> " + responseBody);

		return response;

	}

}
