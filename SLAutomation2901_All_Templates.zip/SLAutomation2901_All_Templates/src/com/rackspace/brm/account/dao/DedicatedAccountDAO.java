package com.rackspace.brm.account.dao;

import java.io.IOException;
import java.io.StringWriter;

import org.apache.velocity.Template;
import org.apache.velocity.VelocityContext;
import org.apache.velocity.app.VelocityEngine;

import com.portal.pcm.EBufException;
import com.portal.pcm.FList;
import com.rackspace.brm.account.model.Account;
import com.rackspace.brm.common.Utils;
import com.rackspace.brm.common.parser.FListParser;
import com.rackspace.brm.constants.BRMConstants;
import com.rackspace.brm.jobs.OpcodeExecutor;

/**
 * The Class DedicatedAccountDAO is used to communicate with BRM.
 */
public class DedicatedAccountDAO {

	/**
	 * Instantiates a new dedicated account DAO.
	 */
	public DedicatedAccountDAO() {
	}

	/**
	 * Prepare cust commit flist string.
	 *
	 * @param account
	 *            the account
	 * @return the string
	 * @throws Exception
	 *             the exception
	 */
	public String prepareCustCommitFlistString(Account account) throws Exception {
		String opcTemplate = BRMConstants.DEDICATED_ACCT_CREATE_OPC_FILE_PATH;
		VelocityEngine velocityEngine = new VelocityEngine();
		StringWriter writer = null;
		try {
			velocityEngine.init();

			/* next, get the Template */
			Template template = velocityEngine.getTemplate(opcTemplate);
			/* create a context and add data */
			VelocityContext velocityContext = new VelocityContext();
			velocityContext.put("LIMIT", account.getCurrency());
			velocityContext.put("PAYMENTTYPE", account.getPayinfoList().get(0).getPaymentType());
			velocityContext.put("OPTINFLAG", account.getAccountProfile().getOptinFlag());
			velocityContext.put("CE", account.getAccountProfile().getContractingEntity());
			velocityContext.put("PAPERLESSINVOICE", account.getAccountProfile().getPaperlessInvoiceFlag());
			velocityContext.put("SUPPORTTEAM", account.getAccountProfile().getSupportTeam());
			velocityContext.put("PAYTERM", account.getAccountProfile().getPaymentTerm());
			velocityContext.put("STARTDATE", account.getStartDate());
			velocityContext.put("ENDDATE", account.getEndDate());
			velocityContext.put("TENANT_ID", account.getTenantId());
			velocityContext.put("PAYTYPE", account.getPayinfoList().get(0).getPayType());

			/* now render the template into a StringWriter */
			writer = new StringWriter();
			template.merge(velocityContext, writer);
		} catch (Exception ex) {
			throw new Exception("Error occured while preparing flist string using velocity template builder", ex);
		}
		// CREATING CUST COMMIT NAP FILE IN LOCAL DIRECTORY FOR REFERENCE
		Utils.createFile(writer.toString(), "FList_" + "_RAX_OP_CUST_COMMIT_CUSTOMER.in." + account.getTenantId());
		return writer.toString();
	}

	/**
	 * Creates the customer account in BRM.
	 *
	 * @param inputFList
	 *            the input FList
	 * @return the outputFList
	 * @throws IOException
	 *             Signals that an I/O exception has occurred.
	 * @throws EBufException
	 *             the EBuf exception
	 */
	public FList createCustomerAccountInBRM(FList inputFList) throws IOException, EBufException {
		FList outputFlist = OpcodeExecutor.executeOpcode(inputFList, BRMConstants.CUSTOMER_CUST_COMMIT_OPCODE);
		return outputFlist;
	}

	/**
	 * Creates the customer account in BRM.
	 *
	 * @param ipAccount
	 *            the ip account
	 * @return the FList
	 * @throws IOException
	 *             Signals that an I/O exception has occurred.
	 * @throws EBufException
	 *             the EBuf exception
	 * @throws Exception
	 *             the exception
	 */
	public Account createCustomerAccountInBRM(Account ipAccount) throws IOException, EBufException, Exception {
		String inputStringFList = this.prepareCustCommitFlistString(ipAccount);
		FList outputFList = OpcodeExecutor.executeOpcode(inputStringFList, BRMConstants.RAX_OP_CUST_COMMIT_CUSTOMER);
		Account account = FListParser.parseCustCommitOutputFlist(outputFList);
		Utils.createFile(outputFList.toString(), "Flist_0_RAX_OP_CUST_COMMIT_CUSTOMER.out" + account.getTenantId());
		return account;
	}

	/**
	 * Consolidate customer account in BRM.
	 *
	 * @param inputStringFList
	 *            the input string F list
	 * @return the f list
	 * @throws IOException
	 *             Signals that an I/O exception has occurred.
	 * @throws EBufException
	 *             the e buf exception
	 */
	public FList consolidateCustomerAccountInBRM(String inputStringFList) throws IOException, EBufException {

		FList outputFList = OpcodeExecutor.executeOpcode(inputStringFList, BRMConstants.RAX_OP_CUST_MOVE_ACCOUNT);
		return outputFList;
	}

	/**
	 * The main method.
	 *
	 * @param args
	 *            the arguments
	 * @throws Exception
	 *             the exception
	 */
	public static void main(String[] args) throws Exception {
		DedicatedAccountDAO dao = new DedicatedAccountDAO();
		Account act = new Account();
		dao.prepareCustCommitFlistString(act);
	}

}
