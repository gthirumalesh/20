package com.rackspace.brm.jobs;

import com.portal.pcm.EBufException;
import com.portal.pcm.FList;
import com.portal.pcm.PortalContext;
import com.rackspace.brm.common.PropertyUtil;
import com.rackspace.brm.common.Utils;
import com.rackspace.brm.connection.BRMPortalConnection;
import com.rackspace.brm.constants.BRMConstants;

/**
 * The Class OpcodeExecutor.
 */
public class OpcodeExecutor {

	/**
	 * Instantiates a new opcode executor.
	 */
	public OpcodeExecutor() {
	}

	/**
	 * Execute opcode.
	 *
	 * @param inputFList
	 *            used to store the input FList
	 * @param opcodeName
	 *            used to store the opcode name
	 * @return the outputFList
	 */
	public static FList executeOpcode(FList inputFList, String opcodeName) {
		PortalContext context = null;
		FList outputFList = null;
		int opcodeNumber = 0;
		try {
			context = BRMPortalConnection.getBRMPortalConnection();
			opcodeNumber = Integer.parseInt(PropertyUtil.getCommonProperties().getProperty(opcodeName)); // To
																											// be
																											// corrected
																											// to
																											// get
																											// the
																											// right
																											// opcode
																											// number
			outputFList = context.opcode(opcodeNumber, inputFList);
		} catch (Exception ex) {
			ex.printStackTrace();
		} finally {

		}
		return outputFList;
	}

	/**
	 * Execute opcode.
	 *
	 * @param inputStringFList
	 *            used to store the input String FList
	 * @param opcodeName
	 *            used to store the opcode name
	 * @return the outputFList
	 */
	public static FList executeOpcode(String inputStringFList, String opcodeName) {
		PortalContext context = null;
		FList outputFList = null;
		try {
			context = BRMPortalConnection.getBRMPortalConnection();
			outputFList = context.opcode(BRMConstants.RAX_OP_CUST_COMMIT_CUSTOMER,
					FList.createFromString(inputStringFList));
		} catch (Exception ex) {
			ex.printStackTrace();
		} finally {

		}
		return outputFList;
	}

	/**
	 * Execute opcode.
	 *
	 * @param inputStringFList
	 *            the input string F list
	 * @param opcodeName
	 *            the opcode name
	 * @return the f list
	 */
	public static FList executeOpcode(String inputStringFList, int opcodeName) throws EBufException {
		PortalContext context = null;
		FList outputFList = null;
		try {
			context = BRMPortalConnection.getBRMPortalConnection();
			outputFList = context.opcode(opcodeName, FList.createFromString(inputStringFList));
			Utils.APP_LOGS.info(outputFList.toString());
		} catch (EBufException ex) {
			throw ex;
		}
		return outputFList;
	}

}
