package com.rackspace.brm.jobs;

import com.rackspace.brm.common.BRMUtils;
import com.rackspace.brm.common.PropertyUtil;
import com.rackspace.brm.common.Utils;
import com.rackspace.brm.common.model.CommandObject;
import com.rackspace.brm.usage.constants.UsageConstants;
import com.rackspace.brm.usage.model.DedicatedUsage;

/**
 * The Class BRMJobExecutor.
 */
public class BRMJobExecutor {
	/**
	 * Instantiates a new BRM job executor.
	 * 
	 */

	public BRMJobExecutor() {
	}

	/**
	 * This method will move the dedicated usage file and execute sh
	 * rax_uel_script.sh -file <file name>
	 * 
	 * @throws Exception
	 */
	public static void executeDedicatedUsageUEL(DedicatedUsage dedicatedusage, 
			String processedCdrPath) throws Exception {
		try {
			Utils.APP_LOGS.info("Enter:executeDedicatedUsageUEL()");

			String usageType = dedicatedusage.getDedicatedUsageLinesType().toString().toLowerCase();
			String pinNumber = PropertyUtil.getCommonProperties().getProperty("pin");

			String dedicatedUsagePuttyPath = PropertyUtil.getCommonProperties()
					.getProperty("puttyPathForDedicatedUsage").replace("$env$", pinNumber);

			BRMUtils.scpFileTransfer("put", processedCdrPath, dedicatedUsagePuttyPath);

			Utils.APP_LOGS.info("Dedicated Usage file is transfered successfully");
			String dedicatedUsageCommandPath = PropertyUtil.getCommonProperties().getProperty("usgagePath")
					.replace("$env$", pinNumber);

			String convertCommand = PropertyUtil.getCommonProperties().getProperty("convertDosToUnix").replace("$env$",
					pinNumber);

			// String convertDosToUnix = convertCommand +
			// dedicatedusage.getTenantId() + ".csv\n";
			String convertDosToUnix = convertCommand + usageType + dedicatedusage.getTenantId() + ".csv\n";

			String dedicatedUsageCommand = PropertyUtil.getCommonProperties().getProperty("runUsage");

			// String postUsage = dedicatedUsageCommand +
			// dedicatedusage.getTenantId() + ".csv\n";
			String postUsage = dedicatedUsageCommand + usageType + dedicatedusage.getTenantId() + ".csv &\n";

			BRMUtils.toTriggerShellCommands(dedicatedUsageCommandPath, convertDosToUnix, postUsage);
			Utils.APP_LOGS.info("Exit:executeDedicatedUsageUEL()");
		} catch (Exception e) {
			e.printStackTrace();
			Utils.APP_LOGS.error("Usage not posted" + e);
		}
	}

	/**
	 * This method will move cloud usage file (SOL42) to pipeline input
	 * directory to rate the usage using pipeline rating engine
	 * 
	 * @throws Exception
	 */
	public static void processCloudUsage() throws Exception {

	}

	/**
	 * Execute cloud billing.
	 */
	public static void executeCloudBilling() {

	}

	/*	*//**
			 * Execute dedicated billing. Account Number is being passed to get
			 * next bill date to run billing
			 * 
			 * @throws Exception
			 *//*
			 * public static String executeDedicatedBilling(String
			 * accountNumber) throws Exception {
			 * 
			 * String execBilling =
			 * PropertyUtil.getCommonProperties().getProperty(
			 * "dedicatedBillingJob");
			 * 
			 * String setpvtComment = Utils.getPvtForBilling(accountNumber);
			 * BRMUtils.setPVT(setpvtComment);
			 * BRMUtils.toTriggerShellCommands(execBilling);
			 * 
			 * String billNumber=Utils.ValidateDB("billQuery",accountNumber);
			 * return billNumber;
			 * 
			 * }
			 */

	/**
	 * Execute cloud billing.
	 *
	 * @param accountPOID
	 *            the used to store account POID
	 * @param billInfoPOID
	 *            used to store the billInfo POID
	 */
	public static void executeCloudBilling(String acctPoid, String billinfoPoid) {

	}

	/**
	 * Execute dedicated billing.
	 *
	 * @param accountNumber
	 *            the account number
	 * @param out_bilingValue
	 *            the out biling value
	 * @param accountOBjid
	 *            the account O bjid
	 * @param out_dueValue
	 *            the out due value
	 * @throws Exception
	 *             the exception
	 */
	public static String executeDedicatedBilling(String accountNumber) {
		String billNumber = null;
		try {

			Utils.APP_LOGS.info("Enter:executeDedicatedBilling()");

			String billRunCmd = PropertyUtil.getCommonProperties().getProperty("billRunCmd");
			String pvtCmd = PropertyUtil.getCommonProperties().getProperty("setPvtCmd");
			int billDate = Integer.parseInt(PropertyUtil.getCommonProperties().getProperty("billDate"));
			String setPvt = Utils.getPvtForBilling(accountNumber, "MMddhhmmyyyy", billDate, pvtCmd, "\n");
			BRMUtils.setPVT(setPvt);
			BRMUtils.toTriggerShellCommands(billRunCmd);

			billNumber = Utils.retrieveDetailsFromDB("billQuery", accountNumber);

			Utils.APP_LOGS.info("Exit:executeDedicatedBilling()");
		} catch (Exception e) {
			Utils.APP_LOGS.error("Bill not  created" + e);
		}
		return billNumber;

	}

	/**
	 * Execute cloud billing.
	 *
	 * @param bDOMList
	 *            to bill info (for example, BDOM [billing day of month),
	 *            billing frequency, accounting type change
	 */
	public static void executeCloudBilling(String[] bdomList) {

	}

	/**
	 * Execute dedicated billing.
	 */
	public static void executeDedicatedBilling() {

	}

	/**
	 * Execute dedicated billing.
	 *
	 * @param acctPoid
	 *            used to store the the account POID
	 * @param billinfoPoid
	 *            used to store the billInfo POID
	 */
	public static void executeDedicatedBilling(String acctPoid, String billinfoPoid) {

	}

	/**
	 * Execute dedicated billing.
	 *
	 * @param bDomList
	 *            used to store the bDom list
	 */
	public static void executeDedicatedBilling(String[] bdomList) {

	}

	/**
	 * This method will execute invoice utilities before generating invoice PDF.
	 * The following utilities would be executed in the following sequence such
	 * as pin_inv_accts. This method should be explicitly executed with
	 * appropriate paytype separately
	 * 
	 * @payType String The possible parameters are 10001,10003,10005
	 */
	public static void executePinInvAccts(String payType) {
		try {

			Utils.APP_LOGS.info("Enter:executePinInvAccts()");
			String pinInvoice = PropertyUtil.getCommonProperties().getProperty("pinInvoice").replace("payType",
					payType);
			BRMUtils.toTriggerShellCommands(pinInvoice);
			Utils.APP_LOGS.info("Exit:executePinInvAccts()");
		} catch (Exception e) {
			Utils.APP_LOGS.error("Invoice Object not created" + e);
		}

	}

	/**
	 * This method to create custom invoice objects for hierarchical account.
	 * The usage : rax_inv_accts -mode default -start 01/01/2016 -end
	 * 12/01/2017;
	 * 
	 * @param payType
	 */
	public static void executeRaxInvAccts(String invoiceType, String billStartDate, String billEndDate) {

	}

	/**
	 * Usage: load_rax_inv_gen_cloud -paperlessOnly false �-type invoice
	 * -segment 2004 -start 01/01/2016 -end 06/01/2017;
	 */
	public static void executeInvoicePDF(String invoiceType, String billingSegment, String invoiceStartDate,
			String invoiceEndDate) {
		Utils.APP_LOGS.info("Enter: executeInvoicePDF()");

		String pdfRunJobCmd = PropertyUtil.getCommonProperties().getProperty("pdfRunJobCmd")
				.replace("$invoiceType$", invoiceType).replace("$billingSegment$", billingSegment)
				.replace("$startDate$", invoiceStartDate).replace("$endDate$", invoiceEndDate);

		BRMUtils.toTriggerShellCommands(pdfRunJobCmd);

		Utils.APP_LOGS.info("Exit: executeInvoicePDF()");
	}

	/**
	 * Usage: rax_event_extract -bill_seg uscloud -start 06/01/2020 -end
	 * 08/01/2020 -verbose
	 */

	public static void executeEventExtractCSV(String billingSegment, String billStartDate, String billEndDate) {

	}
	
	public static void main(String[] args) throws Exception {
		String usageType = UsageConstants.DedicatedUsageLinesType.DAILY.toString().toLowerCase();
		System.out.println("|UsageType|" + usageType);
		
	}

}
