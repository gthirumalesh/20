package com.rackspace.brm.common;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.PipedInputStream;
import java.io.PipedOutputStream;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;
import com.jcraft.jsch.SftpException;
import com.rackspace.brm.connection.BRMJSchConnection;
import com.rackspace.brm.constants.BRMConstants;
import com.rackspace.brm.exception.UsageException;
import com.rackspace.brm.purchaseorder.model.DedicatedPurchaseOrder;
import com.rackspace.brm.usage.model.DedicatedUsage;

/**
 * The Class BRMUtils is for business logic validation methods.
 * 
 */
public class BRMUtils {
	/**
	 * Made the constructor as private to get refrain from creating an instance from outside
	 */
	private BRMUtils() {
		
	}

	/**
	 * This method used to gets the CM logs.
	 */
	public static void getCMLogs() {
		String cmlogToLocation = Utils.pinLogsFolderDirectoryPath();
		String cmlogFromLocation = PropertyUtil.getCommonProperties().getProperty(BRMConstants.BRM_CM_LOG_DIR).replace(BRMConstants.REPLACE_ENV_STRING,
				PropertyUtil.getCommonProperties().getProperty(BRMConstants.PIN_ENVIRONMENT_USER));
		// To Transfer the cmLog File from putty
		Utils.scpFileTransferget(cmlogFromLocation, cmlogToLocation);
	}

	/**
	 * This method used to gets the DM logs.
	 */
	public static void getDMLogs() throws IOException {
		String dmlogToLocation = Utils.pinLogsFolderDirectoryPath();
		String dmlogFromLocation = PropertyUtil.getCommonProperties().getProperty(BRMConstants.BRM_DM_LOG_DIR).replace(BRMConstants.REPLACE_ENV_STRING,
				PropertyUtil.getCommonProperties().getProperty(BRMConstants.PIN_ENVIRONMENT_USER));
		// To Transfer the cmLog File from putty
		Utils.scpFileTransferget(dmlogFromLocation, dmlogToLocation);
	}

	/**
	 * This methods loads up the infranet properties to establish the connection
	 * and get current PVT
	 *
	 * @return the Current PVT
	 */

	public static String getPVT() {
		PipedOutputStream commandIO = null;
		Session session = null;
		Channel channel = null;
		PipedInputStream sessionInput = null;
		PipedInputStream sessionOutput = null;
		String pvt = null;
		String sudoCommand = null;

		try {

			pvt = PropertyUtil.getCommonProperties().getProperty(BRMConstants.PVT_COMMAND_STRING);
			sudoCommand = getSudoCommand();
			// Getting the Session object from BRMJSCHConnection
			session = BRMJSchConnection.getJschSession();
			// Read the Nap contents from template file

			session.connect();
			channel = session.openChannel("shell");

			// create the IO streams to send input to remote session.
			commandIO = new PipedOutputStream();
			sessionInput = new PipedInputStream(commandIO);
			// this set's the InputStream the remote server will read from.
			channel.setInputStream(sessionInput);

			// this will have the STDOUT from server.
			sessionOutput = (PipedInputStream) channel.getInputStream();
			channel.connect();
			commandIO.write(sudoCommand.getBytes());
			commandIO.flush();
			commandIO.write(pvt.getBytes());
			commandIO.write(BRMConstants.EXIT_NEWLINE.getBytes());
			commandIO.write(BRMConstants.EXIT_NEWLINE.getBytes());

			byte[] tmp = new byte[1024];
			int i;
			String line = null;

			// Regular Expression to match the pvt
			String pattern = "(.*?)\\s*mode\\s*\\d\\s*(\\d+)?(.*)";

			// To compile the about expression
			Pattern r = Pattern.compile(pattern);

			// to read the sessionoutput

			while ((i = sessionOutput.read(tmp, 0, tmp.length)) != -1) {

				line = new String(tmp, 0, i);

				if (line.contains("mode")) {
					Matcher m = r.matcher(line);
					if (m.find()) {
						pvt = m.group(2);
						break;
					}
				}
			}

		} catch (JSchException e) {
			Utils.APP_LOGS.error("Connection cannot be established in getPVT()", e);
		} catch (IOException e) {
			Utils.APP_LOGS.error("Specified file cannot be found or read in getPVT()", e);
		} finally {
			if (commandIO != null) {
				try {
					commandIO.close();
				} catch (IOException e) {
					Utils.APP_LOGS.error("Connection did not closed properly in getPVT()", e);
				}
			}
			if (sessionInput != null) {
				try {
					sessionInput.close();
				} catch (IOException e) {
					Utils.APP_LOGS.error("Connection did not closed properly in getPVT()", e);
				}
			}
		}

		return pvt;
	}

	/**
	 * This method used to enter sudo command in BRM instance.
	 *
	 * @return the sudo command
	 */
	public static String getSudoCommand() {
		return PropertyUtil.getCommonProperties().getProperty(BRMConstants.SUDO_COMMAND).replace(BRMConstants.REPLACE_ENV_STRING,
				PropertyUtil.getCommonProperties().getProperty(BRMConstants.PIN_ENVIRONMENT_USER));
	}

	/**
	 * Generate daily dedicated usage.
	 * 
	 * @param dedicatedUsage
	 *            the dedicated usage
	 * @return the string
	 * @throws IOException
	 *             Signals that an I/O exception has occurred.
	 */
	public static String buildInputCsvForDailyUsage(DedicatedUsage dedicatedUsage) throws IOException {

		String fromDailyUsageTemplateFile = null;
		String toDailyUsageTemplateFile = null;
		String line = "";
		String usageText = "";
		toDailyUsageTemplateFile = Utils.flistFolderPath() + File.separator + BRMConstants.EBS_BILLING_DAILY
				+ dedicatedUsage.getTenantId() + BRMConstants.EBS_BILLING_FILE_EXTN;

		BufferedReader reader = null;
		FileWriter writer = null;
		try {
			Utils.APP_LOGS.info("Enter:generateDailyDedicatedUsage()");
			fromDailyUsageTemplateFile = BRMConstants.DEDICATED_DAILY_USAGE_FILE_PATH;
			reader = new BufferedReader(new FileReader(fromDailyUsageTemplateFile));
			double amount = new Double(dedicatedUsage.getAmount()).doubleValue();
			String recordAmount = Double.toString(Utils.splitUsageAmountFromTotal(amount,
					PropertyUtil.getCommonProperties().getProperty("dailyUsageRowsCount")));
			
			while ((line = reader.readLine()) != null) {
				line = line.replaceAll("TENANTID", dedicatedUsage.getTenantId());
				line = line.replaceAll("BATCHID", dedicatedUsage.getBatchId());
				line = line.replaceAll("RECORDID", Utils.generateRandomID());
				line = line.replaceAll("FROMDATE", dedicatedUsage.getFromDate());
				line = line.replaceAll("EDMONTHYEAR", dedicatedUsage.getMonthYear());
				line = line.replaceAll("AMOUNT",recordAmount);
				line = line.replaceAll("CURRENCY", dedicatedUsage.getCurrency());
				usageText += line + "\r\n";
			}

			writer = new FileWriter(toDailyUsageTemplateFile);
			writer.write(usageText);

			Utils.APP_LOGS.info("Exit:generateDailyDedicatedUsage()");

		} catch (IOException e) {
			Utils.APP_LOGS.error("Dedicated Daily Usage can not be posted" + e);

		} finally {
			if(reader != null) reader.close();
			if(writer != null) writer.close();			
		}
		return toDailyUsageTemplateFile;

	}

	/**
	 * This method will read the usage model from Dedicated Usage class and
	 * prepare dedicated EBS usage file to be processed
	 * 
	 * @param String
	 *            billingType
	 * @param dedicatedUsage
	 * 
	 * @throws IOException
	 */
	public static String buildInputCsvForMonthlyUsage(DedicatedUsage dedicatedUsage) throws IOException {

		Utils.APP_LOGS.info("Enter:generateDedicatedMonthlyUsage()");
		String line = "";
		String usageText = "";
		String fromMonthlyUsageTemplateFile = BRMConstants.DEDICATED_MONTHLY_USAGE_FILE_PATH;

		String toMonthlyUsageTemplateFile = Utils.flistFolderPath() + File.separator + BRMConstants.EBS_BILLING_MONTHLY
				+ dedicatedUsage.getTenantId() + BRMConstants.EBS_BILLING_FILE_EXTN;
		BufferedReader reader = null;
		FileWriter writer = null;
		
		try

		{
			File file = new File(fromMonthlyUsageTemplateFile);
			reader = new BufferedReader(new FileReader(file));
			double amount = new Double(dedicatedUsage.getAmount()).doubleValue();
			String recordAmount = Double.toString(Utils.splitUsageAmountFromTotal(amount,
					PropertyUtil.getCommonProperties().getProperty("monthlyUsageRowsCount")));
			
			while ((line = reader.readLine()) != null){
				line = line.replaceAll("TENANTID", dedicatedUsage.getTenantId());
				line = line.replaceAll("BATCHID", dedicatedUsage.getBatchId());
				line = line.replaceAll("RECORDID", Utils.generateRandomID());
				line = line.replaceAll("FROMDATE", dedicatedUsage.getFromDate());
				line = line.replaceAll("ENDDATE", dedicatedUsage.getEndDate());
				line = line.replaceAll("EDMONTHYEAR", dedicatedUsage.getMonthYear());
				line = line.replaceAll("AMOUNT", recordAmount);
				line = line.replaceAll("CURRENCY", dedicatedUsage.getCurrency());
				usageText += line + "\r\n";
			}

			writer = new FileWriter(toMonthlyUsageTemplateFile);
			writer.write(usageText);
			Utils.APP_LOGS.info("Exit:generateDedicatedMonthlyUsage()");

		} catch (IOException e) {
			Utils.APP_LOGS.error("Dedicated Monthly Usage can not be posted" + e);

		} finally {
			if(reader != null) reader.close();
			if(writer != null) writer.close(); 
		}
		return toMonthlyUsageTemplateFile;
	}

	/**
	 * Gets the tenant id from input FList.
	 *
	 * @param flistData
	 *            This is input FList data
	 * @return tenantIdFromInput used to store and return tenant id
	 */
	public static String getTenantIdFromInFlist(String flistData) {

		String tenantIdFromInput = null;

		// Regular Expression to match the pvt
		String pattern = "(.*?)TENANT_ID(.*)\"(\\d+)\"";

		// To compile the about expression
		Pattern r = Pattern.compile(pattern);

		// to read the session output
		Matcher m = r.matcher(flistData);
		if (m.find()) {
			tenantIdFromInput = m.group(3);
		}
		return tenantIdFromInput;

	}

	public static boolean setPVT(String argSetPVTCommand) throws Exception {

		PipedOutputStream commandIO = null;
		Session session = null;
		Channel channel = null;
		PipedInputStream sessionInput = null;
		PipedInputStream sessionOutput = null;
		String pvtMode = null;
		String sudoCommand = null;

		try {

			sudoCommand = getSudoCommand();
			// Getting the Session object from BRMJSCHConnection
			session = BRMJSchConnection.getJschSession();
			//session.connect();
			channel = session.openChannel(BRMConstants.SHELL_COMMAND);

			// create the IO streams to send input to remote session.
			commandIO = new PipedOutputStream();
			sessionInput = new PipedInputStream(commandIO);
			// this set's the InputStream the remote server will read from.
			channel.setInputStream(sessionInput);

			// this will have the STDOUT from server.

			sessionOutput = (PipedInputStream) channel.getInputStream();
			channel.connect();

			byte[] tmp = new byte[1024];
			int i;
			String line = null;

			commandIO.write(sudoCommand.getBytes());
			commandIO.flush();
			commandIO.write(argSetPVTCommand.getBytes());
			commandIO.flush();

			// to read the session output

			while ((i = sessionOutput.read(tmp, 0, tmp.length)) != -1) {

				line = new String(tmp, 0, i);

				if (line.contains("mode")) {
					pvtMode = "2";
					break;
				}
			}

		} catch (IOException ioEx) {
			throw new IOException("Specified file cannot be found or read in setPVT()", ioEx);
		} finally {
			if (commandIO != null) {
				try {
					commandIO.close();
				} catch (IOException e) {
					Utils.APP_LOGS.error("Connection did not closed properly in setPVT()", e);
				}
			}
			if (sessionInput != null) {
				try {
					sessionInput.close();
				} catch (IOException e) {
					Utils.APP_LOGS.error("Connection did not closed properly in setPVT()", e);
				}
			}
		}

		if (("2").equalsIgnoreCase(pvtMode))
			return true;
		else
			return false;
	}

	public static String getPinVirtualTimeCommand(String argDate) {

		return "pvt -m2 " + argDate + "\n";

	}

	public static String setPvtForBilling(String argDate) {
		return argDate;

	}

	/**
	 * This method used to Scp file transfer from putty to local system.
	 *
	 * @param putOrGet
	 *            Used for put or get to transfer file
	 * @param FileToLocation
	 *            Used for file to location
	 * @param PuttyPath
	 *            Used for putty path
	 * @throws UsageException
	 *             the usage exception
	 * @throws JSchException
	 *             the j sch exception
	 * @throws SftpException
	 *             the sftp exception
	 * @throws FileNotFoundException
	 *             the file not found exception
	 */
	// Connect WINSCP and transfer files

	public static void scpFileTransfer(String putOrGet, String fileToLocation, String puttyPath) throws JSchException, SftpException, FileNotFoundException {

		Utils.APP_LOGS.info("Entered scpFileTransfer" + putOrGet);
		String SFTPWORKINGDIR = puttyPath;
		ChannelSftp channelSftp = null;
		Channel channel = null;
		try {
			Session session = BRMJSchConnection.getJschSession();
			Utils.APP_LOGS.info("Session connected");
			channel = session.openChannel(BRMConstants.SFTP);
			channel.connect();
			channelSftp = (ChannelSftp) channel;
			channelSftp.cd(SFTPWORKINGDIR);
			File f = new File(fileToLocation);
			channelSftp.put(new FileInputStream(f), f.getName());
			Utils.APP_LOGS.info("Exited scpFileTransfer" + putOrGet);
		} catch (JSchException jschException) {
			throw jschException;
		} catch (SftpException sftpException) {
			throw sftpException;
		} catch (FileNotFoundException fileNotFoundException) {
			throw fileNotFoundException;
		} finally {
			channelSftp.exit();
		}
	}

	/**
	 * Builds the input PO FList template.
	 *
	 * @param dedicatedPurchaseOrder
	 *            reference of the DedicatedPurchaseOrder
	 * @return the String type content input FList
	 * @throws IOException
	 *             Signals that an I/O exception has occurred.
	 */
	public static String buildInputPOFlist(DedicatedPurchaseOrder dedicatedPurchaseOrder) throws IOException {

		String poTemplate = null;

		poTemplate = System.getProperty("user.dir") + File.separator + 
				BRMConstants.DEDICATED_PO_CREATE_OPC_FILE_PATH;

		// Read Nap file contents and dynamically generate the input file
		String fileContents = Utils.readFile(poTemplate);
		fileContents = fileContents.replace("ACCOUNTNUMBER", dedicatedPurchaseOrder.getAccountNumber());
		fileContents = fileContents.replace("TENANTNUMBER", dedicatedPurchaseOrder.getTenantID());
		fileContents = fileContents.replace("$CURRENTPVT$", dedicatedPurchaseOrder.getPvt());
		fileContents = fileContents.replace("$NUM$", Utils.generateRandomID());

		// Converting File contents to as input FList file
		Utils.createFilePo(fileContents,BRMConstants.PO_FLIST_NAP_FILE_NAME_LABEL +
					dedicatedPurchaseOrder.getTenantID());

		return fileContents;
	}

	/**
	 * This method used for get pvt start date
	 * 
	 * @return pdfstartDate
	 */
	public static String getPVTStartDate(String argBillPvt) {

		String pdfstartDate = argBillPvt.substring(0, 2) + "/" + argBillPvt.substring(2, 4) + "/"
				+ argBillPvt.substring(8, 12);
		return pdfstartDate;
	}

	/**
	 * This method used for get pvt end date
	 * 
	 * @return dt
	 */
	public static String getPVTEndDate(String argBillPvt) throws ParseException {

		String dt;
		SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
		Calendar c = Calendar.getInstance();

		String pdfstartDate = argBillPvt.substring(0, 2) + "/" + argBillPvt.substring(2, 4) + "/"
				+ argBillPvt.substring(8, 12);
		try {
			c.setTime(sdf.parse(pdfstartDate));
		} catch (ParseException parseException) {
			// TODO Auto-generated catch block
			throw parseException;
		}
		c.add(Calendar.DATE, 1); // number of days to add
		dt = sdf.format(c.getTime());
		return dt;
	}

	/**
	 * This method used to increase Current PVT for Billing.
	 *
	 */
	public static String getPvtForBilling(String pvtDate) {

		String billPvt = null;

		// date format to set pvt
		String pvtDateFormat = "MMddhhmmyyyy.ss";// mmddhhmmccyy.ss

		// getting current pvt
		String epo = pvtDate;
		// parsing String to Long
		long l = Long.parseLong(epo);

		l = l * 1000;
		// DateFormat formatter = new SimpleDateFormat("MMM dd HH:mm:yy");

		// converting pvt to HumanDateFormat
		Timestamp timestamp = new Timestamp(l);
		Calendar cal = Calendar.getInstance();
		cal.setTimeInMillis(timestamp.getTime());

		// add 1 month for monthly billing
		cal.setTimeInMillis(timestamp.getTime());
		cal.add(Calendar.MONTH, +1);
		// pvtDateFormat = pvtDateFormat+cal.YEAR;
		timestamp = new Timestamp(cal.getTime().getTime());

		DateFormat forma = new SimpleDateFormat(pvtDateFormat);
		billPvt = forma.format(timestamp);

		return billPvt;
	}

	public static String buildInputMappingFlist(String parent, String child) throws IOException {

		String Filecontents = null;
		String opcTemplate = System.getProperty("user.dir") + File.separator
					+ PropertyUtil.getCommonProperties().getProperty("mapParentandChild");
		// Read Nap file contents and dynamically generate the input file
		Filecontents = Utils.readFile(opcTemplate);
		Filecontents = Filecontents.replace("PARENTACCOUNT", parent);
		Filecontents = Filecontents.replace("CHILDACCOUNT", child);

		return Filecontents;
	}

	/**
	 * Gets the pdf file from BRM.
	 *
	 * @param dedicatedAccountNumber
	 *            the dedicated account number
	 * @param dedicatedBillNumber
	 *            the dedicated bill number
	 * @return
	 */
	public static void getPdfFileFromBRM(String dedicatedAccountNumber, String dedicatedBillNumber) {

		String pinEnviornment = PropertyUtil.getCommonProperties().getProperty(BRMConstants.PIN_ENVIRONMENT_USER);

		String pdfFromLocation = PropertyUtil.getCommonProperties().getProperty(BRMConstants.PDF_FROM_LOCATION).replace(BRMConstants.REPLACE_ENV_STRING,
				pinEnviornment);

		String pdfToLocation = Utils.flistFolderPath();

		String pdf_finalfromlocation = pdfFromLocation + dedicatedAccountNumber + "_" + dedicatedBillNumber + BRMConstants.PDF_FILE_EXTN;

		Utils.scpFileTransferget(pdf_finalfromlocation, pdfToLocation);
	}

	/**
	 * This method used to execute commands in BRM instance.
	 *
	 * @param command
	 *            the command
	 */
	public static void toTriggerShellCommands(String... command) {
		Session session = null;
		String sudoCommand = null;
		try {
			Utils.APP_LOGS.info("Entry: toTriggerShellCommands");
			sudoCommand = PropertyUtil.getCommonProperties().getProperty(BRMConstants.SUDO_COMMAND).replace(BRMConstants.REPLACE_ENV_STRING,
					PropertyUtil.getCommonProperties().getProperty(BRMConstants.PIN_ENVIRONMENT_USER));
			session = BRMJSchConnection.getJschSession();
			// session = BRMUtils.getBrmInstance();

			// session.connect();
			Channel channel = session.openChannel(BRMConstants.SHELL_COMMAND);

			// create the IO streams to send input to remote session.
			PipedOutputStream commandIO = new PipedOutputStream();
			InputStream sessionInput = new PipedInputStream(commandIO);
			// this set's the InputStream the remote server will read from.
			channel.setInputStream(sessionInput);

			// this will have the STDOUT from server.
			InputStream sessionOutput = channel.getInputStream();
			channel.connect();
			commandIO.write(sudoCommand.getBytes());
			commandIO.flush();

			for (String cc : command) {
				commandIO.write(cc.getBytes());

			}

			commandIO.write(BRMConstants.EXIT_NEWLINE.getBytes());
			commandIO.write(BRMConstants.EXIT_NEWLINE.getBytes());
			byte[] tmp = new byte[1024];
			int i=0;

			while ((i = sessionOutput.read(tmp, 0, tmp.length)) != -1) {
				// System.out.print(new String(tmp, 0, i));
			}

			commandIO.close();
			sessionInput.close();
			// channel.disconnect();
			// session.disconnect();
			Utils.APP_LOGS.info("Exit :toWriteCommands()");
		} catch (Exception e) {
			Utils.APP_LOGS.error(e);
		}

	}

}
