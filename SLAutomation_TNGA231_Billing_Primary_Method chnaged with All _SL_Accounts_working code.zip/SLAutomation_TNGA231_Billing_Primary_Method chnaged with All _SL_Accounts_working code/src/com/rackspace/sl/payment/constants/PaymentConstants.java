package com.rackspace.sl.payment.constants;

public class PaymentConstants {

	public static final String Payment_Type_URL = "https://$env.system.payment.api.rackspacecloud.com/v1/accounts/$accountNumber/methods";
	public static final String Payment_Type_URL1 = "https://$env.system.payment.api.rackspacecloud.com/v1/accounts/$accountNumber/methods";

	/** The Constant GET_ACCOUNT for PSL. */
	public static final String GET_PSL_CC_ACCOUNT = "https://$env.system.payment.api.rackspacecloud.com/v1/accounts/$accountNumber/methods";

	public static final String GET_SUPPORTED_METHODS = "https://$env.system.payment.api.rackspacecloud.com/v1/supportedMethods";
	public static final String GET_PSL_METHOD_VALIDATION = "https://$env.system.payment.api.rackspacecloud.com/v1/methodValidations";
	public static final String GET_PSL_FINALIZE_METHOD_CREATION = "https://$env.system.payment.api.rackspacecloud.com/v1/finalizeMethodCreation";
	public static final String GET_PSL_SET_DEFAULT_METHOD = "https://$env.system.payment.api.rackspacecloud.com/v1/accounts/$accountNumber/methods/default";
	public static final String GET_PSL_SET_DEFAULT_METHOD_VALIDATE = "https://$env.system.payment.api.rackspacecloud.com/v1/accounts/$accountNumber/methods/default";

	public enum PaymentType {

		ACH,

		CC

	}

	public enum CardTypes {
		VISA,

		MASTERCARD,

		DISCOVER
	}

}
