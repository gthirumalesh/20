
package com.rackspace.sl.payment.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.rackspace.sl.payment.constants.PaymentConstants.CardTypes;

// TODO: Auto-generated Javadoc
/**
 * The Class PaymentCard.
 */
public class PaymentCard {
	
	/** The urn ID. */
	private String urnID;
	
    /**
     * Gets the urn ID.
     *
     * @return the urn ID
     */
    public String getUrnID() {
		return urnID;
	}

	/**
	 * Sets the urn ID.
	 *
	 * @param urnID the new urn ID
	 */
	public void setUrnID(String urnID) {
		this.urnID = urnID;
	}

	/** The card verification number. */
	@SerializedName("cardVerificationNumber")
    @Expose
    private String cardVerificationNumber;
    
    /** The card holder name. */
    @SerializedName("cardHolderName")
    @Expose
    private String cardHolderName;
    
    /** The card number. */
    @SerializedName("cardNumber")
    @Expose
    private String cardNumber;
    
    /** The card type. */
    @SerializedName("cardType")
    @Expose
    private String cardType;
    
    /** The expiration date. */
    @SerializedName("expirationDate")
    @Expose
    private String expirationDate;
   
    /** The payment response. */
    @SerializedName("paymentResponse")
    @Expose
    private PaymentResponse paymentResponse;
    
    /** The method response. */
    @SerializedName("methodResponse")
    @Expose
    private MethodResponse methodResponse;
    
    /** The card types. */
    private CardTypes cardTypes;
   
    /**
     * Gets the card types.
     *
     * @return the card types
     */
    public CardTypes getCardTypes() {
		return cardTypes;
	}

	/**
	 * Sets the card types.
	 *
	 * @param cardTypes the new card types
	 */
	public void setCardTypes(CardTypes cardTypes) {
		this.cardTypes = cardTypes;
	}

	/** The response code. */
	@SerializedName("responseCode")
    @Expose
    private int responseCode;


	/**
	 * Gets the response code.
	 *
	 * @return the response code
	 */
	public int getResponseCode() {
		return responseCode;
	}

	/**
	 * Sets the response code.
	 *
	 * @param responseCode the new response code
	 */
	public void setResponseCode(int responseCode) {
		this.responseCode = responseCode;
	}

	/**
	 * Gets the card verification number.
	 *
	 * @return the card verification number
	 */
	public String getCardVerificationNumber() {
        return cardVerificationNumber;
    }

    /**
     * Sets the card verification number.
     *
     * @param cardVerificationNumber the new card verification number
     */
    public void setCardVerificationNumber(String cardVerificationNumber) {
        this.cardVerificationNumber = cardVerificationNumber;
    }

    /**
     * Gets the card holder name.
     *
     * @return the card holder name
     */
    public String getCardHolderName() {
        return cardHolderName;
    }

    /**
     * Sets the card holder name.
     *
     * @param cardHolderName the new card holder name
     */
    public void setCardHolderName(String cardHolderName) {
        this.cardHolderName = cardHolderName;
    }

    /**
     * Gets the card number.
     *
     * @return the card number
     */
    public String getCardNumber() {
        return cardNumber;
    }

    /**
     * Sets the card number.
     *
     * @param cardNumber the new card number
     */
    public void setCardNumber(String cardNumber) {
        this.cardNumber = cardNumber;
    }

    /**
     * Gets the card type.
     *
     * @return the card type
     */
    public String getCardType() {
        return cardType;
    }

    /**
     * Sets the card type.
     *
     * @param cardType the new card type
     */
    public void setCardType(String cardType) {
        this.cardType = cardType;
    }

    /**
     * Gets the expiration date.
     *
     * @return the expiration date
     */
    public String getExpirationDate() {
        return expirationDate;
    }

    /**
     * Sets the expiration date.
     *
     * @param expirationDate the new expiration date
     */
    public void setExpirationDate(String expirationDate) {
        this.expirationDate = expirationDate;
    }

	/**
	 * Gets the payment response.
	 *
	 * @return the payment response
	 */
	public PaymentResponse getPaymentResponse() {
		return paymentResponse;
	}

	/**
	 * Sets the payment response.
	 *
	 * @param paymentResponse the new payment response
	 */
	public void setPaymentResponse(PaymentResponse paymentResponse) {
		this.paymentResponse = paymentResponse;
	}

	/**
	 * Gets the method response.
	 *
	 * @return the method response
	 */
	public MethodResponse getMethodResponse() {
		return methodResponse;
	}

	/**
	 * Sets the method response.
	 *
	 * @param methodResponse the new method response
	 */
	public void setMethodResponse(MethodResponse methodResponse) {
		this.methodResponse = methodResponse;
	}




}
