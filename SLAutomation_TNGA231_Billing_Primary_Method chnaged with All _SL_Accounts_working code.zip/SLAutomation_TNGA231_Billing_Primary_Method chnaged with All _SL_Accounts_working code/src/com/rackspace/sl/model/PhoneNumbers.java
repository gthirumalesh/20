
package com.rackspace.sl.model;

import java.util.List;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/**
 * The Class PhoneNumbers.
 */
public class PhoneNumbers {

    /** The phone number. */
    @SerializedName("phoneNumber")
    @Expose
    private List<PhoneNumber> phoneNumber = null;

    /**
     * Gets the phone number.
     *
     * @return the phone number
     */
    public List<PhoneNumber> getPhoneNumber() {
        return phoneNumber;
    }

    /**
     * Sets the phone number.
     *
     * @param phoneNumber the new phone number
     */
    public void setPhoneNumber(List<PhoneNumber> phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

}
