
package com.rackspace.sl.rbacprofile.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/**
 * The Class Endpoint.
 */
public class Endpoint {

    /** The tenant id. */
    @SerializedName("tenantId")
    @Expose
    private String tenantId;
    
    /** The public URL. */
    @SerializedName("publicURL")
    @Expose
    private String publicURL;
    
    /** The region. */
    @SerializedName("region")
    @Expose
    private String region;
    
    /** The internal URL. */
    @SerializedName("internalURL")
    @Expose
    private String internalURL;
    
    /** The version id. */
    @SerializedName("versionId")
    @Expose
    private String versionId;
    
    /** The version list. */
    @SerializedName("versionList")
    @Expose
    private Object versionList;
    
    /** The version info. */
    @SerializedName("versionInfo")
    @Expose
    private Object versionInfo;

    /**
     * Gets the tenant id.
     *
     * @return the tenant id
     */
    public String getTenantId() {
        return tenantId;
    }

    /**
     * Sets the tenant id.
     *
     * @param tenantId the new tenant id
     */
    public void setTenantId(String tenantId) {
        this.tenantId = tenantId;
    }

    /**
     * Gets the public URL.
     *
     * @return the public URL
     */
    public String getPublicURL() {
        return publicURL;
    }

    /**
     * Sets the public URL.
     *
     * @param publicURL the new public URL
     */
    public void setPublicURL(String publicURL) {
        this.publicURL = publicURL;
    }

    /**
     * Gets the region.
     *
     * @return the region
     */
    public String getRegion() {
        return region;
    }

    /**
     * Sets the region.
     *
     * @param region the new region
     */
    public void setRegion(String region) {
        this.region = region;
    }

    /**
     * Gets the internal URL.
     *
     * @return the internal URL
     */
    public String getInternalURL() {
        return internalURL;
    }

    /**
     * Sets the internal URL.
     *
     * @param internalURL the new internal URL
     */
    public void setInternalURL(String internalURL) {
        this.internalURL = internalURL;
    }

    /**
     * Gets the version id.
     *
     * @return the version id
     */
    public String getVersionId() {
        return versionId;
    }

    /**
     * Sets the version id.
     *
     * @param versionId the new version id
     */
    public void setVersionId(String versionId) {
        this.versionId = versionId;
    }

    /**
     * Gets the version list.
     *
     * @return the version list
     */
    public Object getVersionList() {
        return versionList;
    }

    /**
     * Sets the version list.
     *
     * @param versionList the new version list
     */
    public void setVersionList(Object versionList) {
        this.versionList = versionList;
    }

    /**
     * Gets the version info.
     *
     * @return the version info
     */
    public Object getVersionInfo() {
        return versionInfo;
    }

    /**
     * Sets the version info.
     *
     * @param versionInfo the new version info
     */
    public void setVersionInfo(Object versionInfo) {
        this.versionInfo = versionInfo;
    }

}
