package com.rackspace.sl.account.dao;

import java.io.IOException;
import java.io.StringWriter;


import org.apache.velocity.Template;
import org.apache.velocity.VelocityContext;
import org.apache.velocity.app.VelocityEngine;

import com.portal.pcm.EBufException;
import com.portal.pcm.FList;
import com.rackspace.brm.account.constants.AccountConstants;
import com.rackspace.brm.account.model.Account;
import com.rackspace.brm.common.PropertyUtil;
import com.rackspace.brm.common.Utils;
import com.rackspace.brm.constants.BRMConstants;
import com.rackspace.brm.jobs.OpcodeExecutor;
import com.rackspace.sl.connection.RestAPIConnection;
import com.rackspace.sl.constants.SLConstants;
import com.rackspace.sl.model.AcountParser;
import com.rackspace.sl.rbacprofile.model.RBACProfile;

import io.restassured.response.Response;

/**
 * The Class CloudAccountDAO.
 * 
 */
public class AccountDAO {
	/**
	 * The cloudAccount reference of the CloudAccountOld class object
	 */
	protected Account cloudAccount = null;

	/**
	 * Instantiates a new cloud account DAO.
	 */
	public AccountDAO() {
	}

	/**
	 * Instantiates a new cloud account DAO.
	 *
	 * @param cloudAccount
	 *            the cloud account
	 */
	public AccountDAO(Account account) {
		this.cloudAccount = cloudAccount;
	}

	/**
	 * Creates the account.
	 *
	 * @return the f list
	 */
	public FList createAccount() {
		FList opFlist = OpcodeExecutor.executeOpcode(this.buildInputFlist(), BRMConstants.CUSTOMER_CUST_COMMIT_OPCODE);
		return opFlist;
	}

	
	
	/**
	 * Creates the customer account in BRM.
	 *
	 * @param ipAccount the ip account
	 * @param myRBACprofile the my RBA cprofile
	 * @return the account
	 * @throws IOException Signals that an I/O exception has occurred.
	 * @throws EBufException the e buf exception
	 * @throws Exception the exception
	 */
	public Account createCustomerAccount(Account ipAccount, RBACProfile myRBACprofile) throws IOException, EBufException, Exception {
		
		Account opAccount = new Account();
		
		String dedicatedJson = this.prepareCustJsonString(ipAccount);
		
		Utils.APP_LOGS.info(dedicatedJson);
		String uri = SLConstants.CREATE_SL_ACCOUNT_URI.replace("$env",
				PropertyUtil.getBslProperties().getProperty(SLConstants.ENVIORNMENT));
		System.out.println("uri"+uri);
		Response response = RestAPIConnection.executeGetRestAPIConnectionPostWithToken(uri, SLConstants.ACCEPT_APPLICATION_JSON, SLConstants.CONTENT_TYPE_APPLICATION_JSON, myRBACprofile.getToken(), dedicatedJson);
		
		System.out.println("response in cloudAccountdao cloud  " + response.getBody().asString());
		
		opAccount = AcountParser.parseCreateAccountJson(response, ipAccount);
		
		return opAccount;
	}
	
	/**
	 * Prepare cust json string.
	 *
	 * @param account the account
	 * @return the string
	 * @throws Exception the exception
	 */
	public String prepareCustJsonString1(Account account) throws Exception {
		String opcTemplate = SLConstants.DEDICATED_ACCT_CREATE_JSON_FILE_PATH;
		VelocityEngine velocityEngine = new VelocityEngine();
		StringWriter writer = null;
		try {
			velocityEngine.init();

			/* next, get the Template */
			Template template = velocityEngine.getTemplate(opcTemplate);
			/* create a context and add data */
			VelocityContext velocityContext = new VelocityContext();
			velocityContext.put("SLALIASID", account.getTenantId());
			velocityContext.put("SLEXTERNALSYSTEMID", account.getAccountProfile().getCoreAccountNumber());
			velocityContext.put("SLCURRENCY", account.getCurrency());
			velocityContext.put("SLCONTRACTENTITY", account.getAccountProfile().getContractingEntity());
			velocityContext.put("SLNOTIFICATIONOPTION", account.getAccountProfile().getOptinFlag());
			
			if (account.getAccountType().equals(AccountConstants.AccountType.DEDICATED)) {
				velocityContext.put("SLLINEOFBUSINESS", AccountConstants.AccountType.DEDICATED);
			}else if (account.getAccountType().equals(AccountConstants.AccountType.UK_CLOUD)){
				velocityContext.put("SLLINEOFBUSINESS", AccountConstants.AccountType.UK_CLOUD);
			}else if (account.getAccountType().equals(AccountConstants.AccountType.US_CLOUD)){
				velocityContext.put("SLLINEOFBUSINESS", AccountConstants.AccountType.US_CLOUD);
			}
			velocityContext.put("SLINVOICEDELIVERYMETHOD", account.getAccountProfile().getPaperlessInvoiceFlag());
			velocityContext.put("SLSIGNUPDATE", account.getStartDate());
			velocityContext.put("SLPAYMENTTYPE", account.getAccBillInfoList().get(0).getPayType());
			velocityContext.put("SLPAYMENTTERMS", account.getAccountProfile().getPaymentTerm());
			velocityContext.put("SLTAXID", account.getAccountProfile().getVatNumber());
			
			/* now render the template into a StringWriter */
			writer = new StringWriter();
			template.merge(velocityContext, writer);
		
		} catch (Exception ex) {
			throw new Exception("Error occured while preparing JSON string using velocity template builder", ex);
		}
		// CREATING CUST COMMIT NAP FILE IN LOCAL DIRECTORY FOR REFERENCE
		//Utils.createFile(writer.toString(), "FList_" + "_RAX_OP_CUST_COMMIT_CUSTOMER.in." + account.getTenantId());
		Utils.APP_LOGS.info("DedicatedAccountJSON:"+writer.toString());
		return writer.toString();
	}

	/**
	 * Prepare cust json string.
	 *
	 * @param account the account
	 * @return the string
	 * @throws Exception the exception
	 */
	public String prepareCustJsonString(Account account) throws Exception {
		
		Utils.APP_LOGS.info(account.getAccountType());
		String opcTemplate = null;
		switch(account.getAccountType()){
		case DEDICATED:
			opcTemplate = SLConstants.DEDICATED_ACCT_CREATE_JSON_FILE_PATH;
			break;

		case US_CLOUD:
			opcTemplate = SLConstants.US_CLOUD_ACCT_CREATE_JSON_FILE_PATH;
			break;

		case UK_CLOUD:
			opcTemplate = SLConstants.UK_CLOUD_ACCT_CREATE_JSON_FILE_PATH;
			break;

		default:
			opcTemplate = null;
			break;
		}
		
		VelocityEngine velocityEngine = new VelocityEngine();
		StringWriter writer = null;
		try {
			velocityEngine.init();

			/* next, get the Template */
			Template template = velocityEngine.getTemplate(opcTemplate);
			/* create a context and add data */
			VelocityContext velocityContext = new VelocityContext();
			
			
			
			velocityContext.put("SLACCOUNTNUMBER", account.getAccountNumber());
		    velocityContext.put("SLALIASID", account.getTenantId());
			velocityContext.put("SLEXTERNALSYSTEMID", account.getAccountProfile().getCoreAccountNumber());
			velocityContext.put("SLCURRENCY", account.getCurrency());
			velocityContext.put("SLCONTRACTENTITY", account.getAccountProfile().getContractingEntity());
			velocityContext.put("SLNOTIFICATIONOPTION", account.getAccountProfile().getOptinFlag());
			
			
			if (account.getAccountType().equals(AccountConstants.AccountType.DEDICATED)) {
				velocityContext.put("SLLINEOFBUSINESS", AccountConstants.AccountType.DEDICATED);
			}else if (account.getAccountType().equals(AccountConstants.AccountType.UK_CLOUD)){
				velocityContext.put("SLLINEOFBUSINESS", AccountConstants.AccountType.UK_CLOUD);
			}else if (account.getAccountType().equals(AccountConstants.AccountType.US_CLOUD)){
				velocityContext.put("SLLINEOFBUSINESS", AccountConstants.AccountType.US_CLOUD);
			}
			
			velocityContext.put("SLINVOICEDELIVERYMETHOD", account.getAccountProfile().getPaperlessInvoiceFlag());
			velocityContext.put("SLSIGNUPDATE", account.getStartDate());
			velocityContext.put("SLPAYMENTTYPE", account.getAccBillInfoList().get(0).getPayType());
			velocityContext.put("SLPAYMENTTERMS", account.getAccountProfile().getPaymentTerm());
			velocityContext.put("SLTAXID", account.getAccountProfile().getVatNumber());
			
			
			/* now render the template into a StringWriter */
			writer = new StringWriter();
			template.merge(velocityContext, writer);
		
		} catch (Exception ex) {
			throw new Exception("Error occured while preparing JSON string using velocity template builder", ex);
		}
		// CREATING CUST COMMIT NAP FILE IN LOCAL DIRECTORY FOR REFERENCE
		Utils.createFile(writer.toString(), "FList_" + "_RAX_OP_CUST_COMMIT_CUSTOMER.in." + account.getTenantId());
		Utils.APP_LOGS.info("JSONFile:"+writer.toString());
		return writer.toString();
	}
     
	/**
	 * Update account.
	 *
	 * @return the FList
	 */
	
	public FList updateAccount() {
		return null;
	}

	/**
	 * This method to build input FList by using the value from Cloud Account
	 * value object and opcode template file.
	 *
	 * @return the inputFlist
	 */
	private FList buildInputFlist() {
		//String opcTemplate = BRMConstants.CLOUD_ACCT_CREATE_OPC_FILE_PATH;
		FList inputFlist = null;
		return inputFlist;
	}

}
