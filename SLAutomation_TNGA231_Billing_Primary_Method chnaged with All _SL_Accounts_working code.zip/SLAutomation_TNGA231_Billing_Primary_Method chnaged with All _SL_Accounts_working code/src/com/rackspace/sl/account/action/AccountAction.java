package com.rackspace.sl.account.action;

import com.rackspace.brm.account.model.Account;
import com.rackspace.sl.account.dao.AccountDAO;
import com.rackspace.sl.account.dao.DedicatedAccountDAO;
import com.rackspace.sl.rbacprofile.model.RBACProfile;

/**
 * The Class AccountAction is for business logic account action methods.
 */
public class AccountAction {

	/**
	 * Instantiates a new account action.
	 */

	/**
	 * Default constructor to instantiate an object
	 */
	public AccountAction() {

	}

	/**
	 * Creates the account.
	 *
	 * @param ipAccount the ip account
	 * @param myRBACprofile the my RBA cprofile
	 * @return the account
	 * @throws Exception the exception
	 */
	public Account createAccount(Account ipAccount, RBACProfile myRBACprofile) throws Exception {
		Account opAccount = null;
		AccountDAO accountdao= new AccountDAO();
		switch (ipAccount.getAccountType()) {

		case DEDICATED:
			opAccount=accountdao.createCustomerAccount(ipAccount, myRBACprofile);
			break;
		case US_CLOUD:
			opAccount=accountdao.createCustomerAccount(ipAccount, myRBACprofile);
			break;
		case UK_CLOUD:
			opAccount=accountdao.createCustomerAccount(ipAccount, myRBACprofile);
			break;
		}
		return opAccount;
	}

	/**
	 * Gets the SL account.
	 *
	 * @param ipAccount
	 *            the ip account
	 * @param myRBACprofile
	 *            the my RBA cprofile
	 * @return the SL account
	 * @throws Exception
	 *             the exception
	 */
	public int validateBSLAccount(Account opAccount, RBACProfile myRBACprofile) throws Exception {
		DedicatedAccountDAO dedicatedAccountDAO = new DedicatedAccountDAO();

		String accountNumber = opAccount.getAccountNumber();
		System.out.println("accountNumber in AccountAction ========== : " + accountNumber);

		int response = dedicatedAccountDAO.getCustomerAccountInSL(opAccount, myRBACprofile);
		System.out.println("AccountAction ==Account Number status code ==" + response);
		return response;
	}
	
	/**
	 * Validate SL account.
	 *
	 * @param ipAccount the ip account
	 * @param myRBACprofile the my RBA cprofile
	 * @return the int
	 * @throws Exception the exception
	 */
	public int validateSLAccount(Account ipAccount, RBACProfile myRBACprofile) throws Exception {
 		
		DedicatedAccountDAO dedicatedAccountDAO = new DedicatedAccountDAO();
		
		String acNo = ipAccount.getAccountNumber();
		System.out.println("acNo in Account Action "+acNo);
		
		int response = dedicatedAccountDAO.getCustomerAccountInSL(ipAccount, myRBACprofile);
		
		System.out.println(" reponseCode for getAccount is "+ response);
	
		return response;
}

	
}
