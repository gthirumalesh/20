package com.rackspace.sl.event.constants;

// TODO: Auto-generated Javadoc
/**
 * The Class TemplateConstants.
 */
public class EventConstants {

	/** The Constant BSL_SYSTEM_ROLE_URL. */
	public static final String GET_TEMPLATE_BY_ID = "https://$env.bazooka.api.rackspacecloud.com/v1/templates/";
	

	/** The Constant GET_NOTIFICATION_URL. */
	public static final String GET_NOTIFICATION_URL = "https://$env.bazooka.api.rackspacecloud.com/v1/templates/$templateID/notifications/$notificationID";

	/**
	 * The Enum EventType.
	 */
	public enum EventType {

		/** The get notification. */
		GET_NOTIFICATION,
		/** The get template id. */
		GET_TEMPLATE_ID,
		/** The post notification. */
		POST_NOTIFICATION

	}

	/**
	 * The Enum TemplateIDType.
	 */
	public enum TemplateType {

		/** The billing primary method changed. */
		BILLING_PRIMARY_METHOD_CHANGED,
		
		PAYMENT_ADDED_ACH,BILLING_PAYMENT_SUCCESS_CC,

	}

	/**
	 * The Enum NotificationStatus.
	 */
	public enum NotificationStatus {

		/** The pending. */
		PENDING_STATUS("PENDING"),

		/** The delivered. */
		DELIVERED_STATUS("DELIVERED");

		/**
		 * The contracting entity variable represents the contracting entity.
		 */
		private String notificationStatus = null;

		private NotificationStatus(String notificationStatus) {
			this.notificationStatus = notificationStatus;
		}

		public String getNotificationStatus() {
			return this.notificationStatus;
		}

	}

}
