package com.rackspace.zproject.zlombok;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;


public class GetterSetterSubClass {
	@Getter
	@Setter
	private int i;
	
	@Getter
	@Setter
	private String firstname; 
	
}
