package com.rackspace.brm.usage.builder;

import com.rackspace.brm.common.PropertyUtil;
import com.rackspace.brm.common.Utils;
import com.rackspace.brm.usage.constants.UsageConstants;
import com.rackspace.brm.usage.model.DedicatedUsage;

public class UsageBuilder {

	public UsageBuilder() {
		// TODO Auto-generated constructor stub
	}

	public DedicatedUsage buildDedicatedUsage(UsageConstants.UsageType usageType,
			UsageConstants.DedicatedUsageLinesType dedicatedUsageLinesType,
			String batchID, String fromDate, String endDate, String tenantId,
			String recordId, String monthYear, double usageAmount, 
			String currency) {
		
		DedicatedUsage dedicatedUsage = new DedicatedUsage();
		dedicatedUsage.setUsageType(usageType);
		dedicatedUsage.setDedicatedUsageLinesType(dedicatedUsageLinesType);
		dedicatedUsage.setBatchId(batchID);
		dedicatedUsage.setEndDate(endDate);
		dedicatedUsage.setFromDate(fromDate);
		dedicatedUsage.setTenantId(tenantId);
		dedicatedUsage.setRecordId(recordId);
		dedicatedUsage.setMonthYear(monthYear);
		dedicatedUsage.setAmount(String.valueOf(usageAmount));
		dedicatedUsage.setCurrency(currency);
		return dedicatedUsage;
	}

}
