package com.rackspace.brm.purchaseorder.dao;

import java.io.IOException;

import com.portal.pcm.EBufException;
import com.portal.pcm.FList;
import com.rackspace.brm.constants.BRMConstants;
import com.rackspace.brm.jobs.OpcodeExecutor;
import com.rackspace.brm.purchaseorder.model.DedicatedPurchaseOrder;

/**
 * The Class DedicatedPurchaseOrderDAO.
 */
public class DedicatedPurchaseOrderDAO {

	/** The dedicatedPurchaseOrder reference of the DedicatedPurchaseOrder */
	private DedicatedPurchaseOrder dedicatedPurchaseOrder = null;

	/**
	 * Instantiates a new dedicated purchase order DAO.
	 */
	public DedicatedPurchaseOrderDAO() {
	}

	/**
	 * Instantiates a new dedicatedPurchaseOrderDAO.
	 *
	 * @param dedicatedPurchaseOrder
	 *            reference of the DedicatedPurchaseOrder
	 */
	public DedicatedPurchaseOrderDAO(DedicatedPurchaseOrder dedicatedPurchaseOrder) {
		this.dedicatedPurchaseOrder = dedicatedPurchaseOrder;
	}

	/**
	 * Creates the purchase order.
	 *
	 * @param inputFList
	 *            used to store string type FList content
	 * @return the outputFList
	 * @throws IOException
	 *             Signals that an I/O exception has occurred.
	 * @throws EBufException
	 */
	public FList createPurchaseOrder(String inputFList) throws IOException, EBufException {

		FList outputFList = OpcodeExecutor.executeOpcode(inputFList, BRMConstants.DEDICATED_PO_OPCODE);
		return outputFList;
	}
}
