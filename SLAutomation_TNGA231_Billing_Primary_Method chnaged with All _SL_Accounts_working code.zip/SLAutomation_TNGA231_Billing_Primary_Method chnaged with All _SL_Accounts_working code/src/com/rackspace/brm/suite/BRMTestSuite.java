package com.rackspace.brm.suite;

import java.io.File;
import java.io.IOException;

import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Listeners;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.google.gson.JsonObject;
import com.rackspace.brm.account.action.AccountAction;
import com.rackspace.brm.account.builder.AccountBuilder;
import com.rackspace.brm.account.constants.AccountConstants.AccountType;
import com.rackspace.brm.account.model.Account;
import com.rackspace.brm.account.model.AccountInvoice;
import com.rackspace.brm.common.BRMUtils;
import com.rackspace.brm.common.Utils;
import com.rackspace.brm.common.parser.InvoicePdfParser;
import com.rackspace.brm.common.validation.AttributeValidator;
import com.rackspace.brm.jobs.BRMJobExecutor;
import com.rackspace.brm.usage.action.UsageAction;
import com.rackspace.brm.usage.builder.UsageBuilder;
import com.rackspace.brm.usage.constants.UsageConstants;
import com.rackspace.brm.usage.constants.UsageConstants.DedicatedUsageLinesType;
import com.rackspace.brm.usage.constants.UsageConstants.UsageType;
import com.rackspace.brm.usage.model.DedicatedUsage;
import com.rackspace.brm.validation.BillValidation;
import com.rackspace.brm.validation.PdfValidation;
import com.rackspace.brm.validation.UsageValidation;

/**
 * The Class Account_PO_Billing is the main class driving the automation tests.
 *
 */
//@Listeners({ org.uncommons.reportng.HTMLReporter.class, org.uncommons.reportng.JUnitXMLReporter.class })
public class BRMTestSuite {

	/**
	 * The json used to store the json values.
	 */
	public static String json;

	/**
	 * The jsonOutput used to store the json object.
	 */
	public static JsonObject jsonOutput;

	/**
	 * Clear logs before and after each tests and folder structure will be
	 * created
	 * 
	 * @throws IOException
	 *             Input output exception
	 * 
	 */
	@BeforeTest(alwaysRun = true)
	public static void envCleanup() throws IOException {

		Utils.createAccountsPOBillingDirectory();
		Utils.createTestCaseFolder();
		Utils.createFlistFolder();
		Utils.createPinLogsFolder();
		Utils.createJSonFolder();
		Utils.createHTMLFolder();
	}

	/**
	 * This method is used for executing the Account_PO_Billing TS_ACCT_01
	 * scenario
	 *
	 * @param currency
	 *            used for Transactions. like USD, AUD, EUR or GBP.
	 * @param paymentType
	 *            used for mode of Payment like Credit Card, Direct debit or
	 *            Invoice.
	 * @param optionFlag
	 *            used for notifications
	 * @param contractingEntity
	 *            used
	 * @param paperLessInvoice
	 *            - used for invoice to be delivered as Paper or mail.
	 * @param supportTeam
	 *            used for profiles
	 * @param payType
	 *            used for Payment type like Credit Card, Direct debit or
	 *            Invoice.
	 * @param payTerm
	 *            used for Pay Term like like NET_30, NET_0.
	 * @param Out_BillDueAmount
	 *            Bill amount due for the account
	 * @throws Exception
	 *             The Exception
	 * 
	 * 
	 */
	@Test(groups = { "Component", "Regression" })
	@Parameters({ "In_CoreAccountNumber", "In_Currency", "In_PaymentType", "In_OptinFlag", "In_ContractingEntity",
			"In_PaperLessInvoice", "In_SupportTeam", "In_Paytype", "In_Payterm", "In_Pvt", "In_DailyUsageAmount",
			"In_MonthlyUsageAmount", "In_FromDate", "In_EndDate", "In_MonthYear", "In_Polarity", "In_BillingSegment",
			"In_PdfStartDate", "In_PdfEndDate", "In_InvoiceType", "Out_ContractingEntity", "Out_Currency",
			"Out_AccountNumber", "Suitename", "Testname", "Out_NextBillDate", "Out_BillDueAmount",
			"Out_CustomerAcctNumber", "Out_DiscountAmount", "Out_TaxAmount", "AccountAttributeValidationList" })
	public static void TS_ACCT_01_VerifyTheBillingForStandaloneAccountGotCreatedBetween1to5(String coreAccountNumber,
			String currency, String paymentType, String optinFlag, String contractingEntity, String paperlessInvoice,
			String supportTeam, String payType, String payTerm, String inPvt, double dailyUsageAmount,
			double monthlyUsageAmount, String fromDate, String endDate, String monthYear, String polarity,
			String billingSegment, String pdfStartDate, String pdfEndDate, String invoiceType,
			String outContractingEntity, String outCurrency, String outAccountNumber, String suiteName,
			String testMethodName, String outNextBillDate, String outBillDueAmount, String outCustomerAcctNumber,
			double outDiscountAmount, double outTaxAmount, String acctAttributeValidationList) throws Exception {
		
		Reporter.log("Step 1: Dedicated standalone account created successfully: ");
		Reporter.log("Step 2: Dedicated standalone account created successfully: ");
		Reporter.log("Step 3: Dedicated standalone account created successfully: ");
		

		/*Utils.APP_LOGS.info("Setting virtual time before kick start my first test case");
		// set pvt in BRM
		if (!BRMUtils.setPVT(BRMUtils.getPinVirtualTimeCommand(inPvt))) {
			Utils.APP_LOGS.error("Error is occured while setting virtual time");
			Assert.fail();
		}

		// Step 1: Create Dedicated account
		AccountBuilder accountBuilder = new AccountBuilder(AccountType.DEDICATED, coreAccountNumber,
				Utils.generateTenantId(), currency, payType, optinFlag, contractingEntity, paperlessInvoice,
				supportTeam, payTerm, "", "0", paperlessInvoice, "0",
				Utils.converToEpochTime(Utils.getPreviousMonthPvtDate(inPvt)),
				Utils.converToEpochTime(Utils.getPreviousMonthPvtDate(inPvt)), paymentType);
		Account ipAccount = accountBuilder.getAccount();
		// Create AccountAction object
		AccountAction accountAction = new AccountAction();
		// Invoke create account
		Account opAccount = accountAction.createAccount(ipAccount);

		if (opAccount.getAccountNumber() != null) {

			Assert.assertTrue(AttributeValidator.getAttributeValidator().validateAttributes(acctAttributeValidationList,
					ipAccount, opAccount));
			Utils.APP_LOGS.info("Dedicated Account created: " + opAccount.getAccountNumber());
			Reporter.log("Step 1: Dedicated standalone account created successfully: " + opAccount.getAccountNumber());

			// Step 2: Build usage object using UsageBuilder
			
			UsageBuilder usageBuilder = new UsageBuilder();
			DedicatedUsage dailydedicatedUsage = usageBuilder.buildDedicatedUsage(UsageType.DEDICATED,
					DedicatedUsageLinesType.DAILY,
					Utils.generateRandomID(),fromDate, endDate,ipAccount.getTenantId(),
					Utils.generateRandomID(),monthYear,dailyUsageAmount,currency);
			UsageAction usageAction = new UsageAction();
			usageAction.createUsage(dailydedicatedUsage);
			
			DedicatedUsage monthlydedicatedUsage = usageBuilder.buildDedicatedUsage(UsageType.DEDICATED,
					DedicatedUsageLinesType.MONTHLY,
					Utils.generateRandomID(),fromDate, endDate,ipAccount.getTenantId(),
					Utils.generateRandomID(),monthYear,monthlyUsageAmount,currency);
			usageAction.createUsage(monthlydedicatedUsage);
			
			 * DedicatedUsage dedicatedUsage = new
			 * UsageBuilder().buildDedicatedUsage(
			 * Utils.generateRandomID(),fromDate, endDate,
			 * opAccount.getTenantId(), Utils.generateRandomID(), monthYear,
			 * dailyUsageAmount, currency);
			 

			// Validate daily usage
			UsageValidation.validateUsage(opAccount.getAccountNumber(), dailyUsageAmount,
					UsageConstants.DAILY_USAGE_QUERY);

			// Validate monthly usage
			UsageValidation.validateUsage(opAccount.getAccountNumber(), monthlyUsageAmount,
					UsageConstants.MONTHLY_USAGE_QUERY);

			// Generate bill
			String dedicatedBillNumber = BRMJobExecutor.executeDedicatedBilling(opAccount.getAccountNumber());

			// Next billing Date validation
			BillValidation.validateNextBillDate(opAccount.getAccountNumber(), outNextBillDate);

			// Post billing due amount validation
			// BillValidation.validatePostBillDueAmount(account.getAccountPoid(),
			// outBillDueAmount);

			Utils.APP_LOGS.info("Bill Generated for Dedicated Account: " + opAccount.getAccountNumber()
					+ " Bill Number " + dedicatedBillNumber);
			Reporter.log("Step 3: Bill Generated for Dedicated Account " + opAccount.getAccountNumber()
					+ " Bill Number " + dedicatedBillNumber);

			// Trigger Invoice
			BRMJobExecutor.executePinInvAccts(payType);
			// invoice object validation
			// InvoiceValidation.validateInvoiceObject(dedicatedBillNumber);

			Utils.APP_LOGS.info("Invoice Generated for Dedicated Account: " + opAccount.getAccountNumber());
			Reporter.log("Step 4: Invoice Generated for Dedicated Account " + opAccount.getAccountNumber());

			// Pdf generation
			BRMJobExecutor.executeInvoicePDF(invoiceType, billingSegment, pdfStartDate, pdfEndDate);

			// Validate pdf generation
			PdfValidation.validatePdfStatus(dedicatedBillNumber);

			// Extract pdf file from BRM server to Local workspace
			BRMUtils.getPdfFileFromBRM(opAccount.getAccountNumber(), dedicatedBillNumber);

			String pdfFileLocation = Utils.flistFolderPath();
			String pdfFileName = pdfFileLocation + File.separator + opAccount.getAccountNumber() + "_"
					+ dedicatedBillNumber + ".pdf";
			Utils.APP_LOGS.info("Pdf Generated for Dedicated Account: " + pdfFileName);
			// Reporter.log("Step 4: Pdf Generated for Dedicated Account " +
			// dedicatedAccount.getAccountNumber());
			InvoicePdfParser pdfParser = new InvoicePdfParser();
			AccountInvoice accountInvoice = pdfParser.parseInvoicePDF(pdfFileName);
			PdfValidation.validateInvoice(accountInvoice, opAccount.getAccountNumber(), outCustomerAcctNumber,
					dedicatedBillNumber, "1-Nov-17", opAccount.getCurrency(), outBillDueAmount);

			Utils.APP_LOGS.info("Pdf Validated for Dedicated Account: " + opAccount.getAccountNumber());
			Reporter.log("Step 4: Pdf Validated for Dedicated Account " + opAccount.getAccountNumber());

			// To create JSON object
			Utils.createJsonFile(Utils.addingJsonString("BRMCITJSON", testMethodName, polarity, suiteName).toString(),
					"BRMJsonTestResult");

		} else {

			Utils.APP_LOGS.info("Account is not created");
			Reporter.log("Step 1: Dedicated standalone account is NOT created ");
		}*/
	}

	/*
	 * @Test(groups = { "Component", "Regression" })
	 * 
	 * @Parameters({ "In_Currency", "In_PaymentType", "In_OptionFlag",
	 * "In_ContractingEntity", "In_PaperLessInvoice", "In_SupportTeam",
	 * "In_Paytype", "In_Payterm", "In_Pvt", "In_DailyUsageAmount",
	 * "In_MonthlyUsageAmount", "In_FromDate", "In_EndDate", "In_MonthYear",
	 * "In_Polarity", "In_BillingSegment", "In_PdfStartDate", "In_PdfEndDate",
	 * "In_InvoiceType", "Out_ContractingEntity", "Out_Currency",
	 * "Out_AccountNumber", "Suitename", "Testname", "Out_NextBillDate",
	 * "Out_BillDueAmount", "Out_CustomerAcctNumber" }) public static void
	 * TS_ACCT_01_VerifyTheBillingForStandaloneAccountGotCreatedBetween6to31(
	 * String currency, String paymentType, String optinFlag, String
	 * contractingEntity, String paperlessInvoice, String supportTeam, String
	 * payType, String payTerm, String inPvt, double dailyUsageAmount, double
	 * monthlyUsageAmount, String fromDate, String endDate, String monthYear,
	 * String polarity, String billingSegment, String pdfStartDate, String
	 * pdfEndDate, String invoiceType, String outContractingEntity, String
	 * outCurrency, String outAccountNumber, String suiteName, String
	 * testMethodName, String outNextBillDate, String outBillDueAmount, String
	 * outCustomerAcctNumber) throws Exception {
	 * 
	 * // set pvt in BRM if
	 * (!BRMUtils.setPVT(BRMUtils.getPinVirtualTimeCommand(inPvt))) { throw new
	 * Exception("Error encountered in setting PVT"); }
	 * 
	 * // Step 1: Create Dedicated account Account account =
	 * AccountFactory.createAccount(AccountType.DEDICATED);
	 * 
	 * // Set the input values into account object
	 * account.setCurrency(currency); account.setPaymentType(paymentType);
	 * account.setContractingEntity(contractingEntity);
	 * account.setPaperLessInvoice(paperlessInvoice);
	 * account.setSupportTeam(supportTeam); account.setPayType(payType);
	 * account.setPaymentTerm(payTerm);
	 * 
	 * // Compute start_t and end_t
	 * account.setStartDate(Utils.converToEpochTime(Utils.getPvtDates(inPvt)));
	 * account.setEndDate(Utils.converToEpochTime(Utils.getPvtDates(inPvt)));
	 * 
	 * // Create Account Profile Object; AccountProfile accProfile = new
	 * AccountProfile();
	 * 
	 * // Set the input values into accountprofile object
	 * accProfile.setOptinFlag(optinFlag);
	 * accProfile.setContractingEntity(contractingEntity);
	 * 
	 * // Associate profile to account account.setAccProfile(accProfile);
	 * 
	 * // Create AccountAction object AccountAction accountAction = new
	 * AccountAction(); // Invoke create account
	 * accountAction.createAccount(account); DedicatedAccount dedicatedAccount =
	 * ((DedicatedAccount) (account));
	 * 
	 * if (dedicatedAccount.getAccountNumber() != null) {
	 * 
	 * Utils.APP_LOGS.info("Dedicated Account created: " +
	 * dedicatedAccount.getAccountNumber()); Reporter.log(
	 * "Step 1: Dedicated standalone account created successfully: " +
	 * dedicatedAccount.getAccountNumber());
	 * 
	 * // Step 2: Post Usage for the standalone dedicated account // Set the
	 * input values into UsageAction object UsageAction usageAction = new
	 * UsageAction(UsageType.DEDICATED, Utils.generateRandomID(), fromDate,
	 * endDate);
	 * 
	 * // Post usage Usage usage =
	 * usageAction.createUsage(dedicatedAccount.getTenantId(),
	 * Utils.generateRandomID(), monthYear, dailyUsageAmount,
	 * monthlyUsageAmount, currency);
	 * 
	 * // Validate daily usage
	 * //UsageValidation.validateUsage(account.getAccountNumber(),
	 * dailyUsageAmount);
	 * 
	 * // Validate monthly usage
	 * //UsageValidation.validateUsage(account.getAccountNumber(),
	 * monthlyUsageAmount);
	 * 
	 * UsageValidation.validateUsage(account.getAccountNumber(),
	 * dailyUsageAmount, UsageConstants.DAILY_USAGE_QUERY);
	 * 
	 * //Validate monthly usage
	 * //UsageValidation.validateUsage(account.getAccountNumber(),
	 * monthlyUsageAmount);
	 * UsageValidation.validateUsage(account.getAccountNumber(),
	 * monthlyUsageAmount, UsageConstants.MONTHLY_USAGE_QUERY);
	 * 
	 * 
	 * Utils.APP_LOGS.info("Usage is posted for Dedicated Account: " +
	 * dedicatedAccount.getAccountNumber()); Reporter.log(
	 * "Step 2: Usage is posted for Dedicated Account " +
	 * dedicatedAccount.getAccountNumber());
	 * 
	 * // Generate bill String dedicatedBillNumber =
	 * BRMJobExecutor.executeDedicatedBilling(account.getAccountNumber());
	 * //System.out.println("dedicatedBillNumber " + dedicatedBillNumber); //
	 * Next billing Date validation
	 * BillValidation.validateNextBillDate(account.getAccountNumber(),
	 * outNextBillDate);
	 * 
	 * // Post billing due amount validation //
	 * BillValidation.validatePostBillDueAmount(account.getAccountPoid(), //
	 * outBillDueAmount);
	 * 
	 * Utils.APP_LOGS.info("Bill Generated for Dedicated Account: " +
	 * dedicatedAccount.getAccountNumber() + " Bill Number " +
	 * dedicatedBillNumber); Reporter.log(
	 * "Step 3: Bill Generated for Dedicated Account " +
	 * dedicatedAccount.getAccountNumber() + " Bill Number " +
	 * dedicatedBillNumber);
	 * 
	 * // Trigger Invoice BRMJobExecutor.executePinInvAccts(payType); // invoice
	 * object validation
	 * InvoiceValidation.validateInvoiceObject(dedicatedBillNumber);
	 * 
	 * Utils.APP_LOGS.info("Invoice Generated for Dedicated Account: " +
	 * dedicatedAccount.getAccountNumber()); Reporter.log(
	 * "Step 4: Invoice Generated for Dedicated Account " +
	 * dedicatedAccount.getAccountNumber());
	 * 
	 * // Pdf generation BRMJobExecutor.executeInvoicePDF(invoiceType,
	 * billingSegment, pdfStartDate, pdfEndDate);
	 * 
	 * // Validate pdf generation
	 * PdfValidation.validatePdfStatus(dedicatedBillNumber);
	 * 
	 * // Extract pdf file from BRM server to Local workspace
	 * BRMUtils.getPdfFileFromBRM(dedicatedAccount.getAccountNumber(),
	 * dedicatedBillNumber);
	 * 
	 * // Mapping pdf fields to AccountInvoice Object String pdfFileLocation =
	 * Utils.flistFolderPath(); String pdfFileName = pdfFileLocation +
	 * File.separator + dedicatedAccount.getAccountNumber() + "_" +
	 * dedicatedBillNumber + ".pdf"; Utils.APP_LOGS.info(
	 * "Pdf Generated for Dedicated Account: " +
	 * dedicatedAccount.getAccountNumber()); //Reporter.log(
	 * "Step 4: Pdf Generated for Dedicated Account " +
	 * dedicatedAccount.getAccountNumber()); InvoicePdfParser pdfParser = new
	 * InvoicePdfParser(); AccountInvoice accountInvoice =
	 * pdfParser.parseInvoicePDF(pdfFileName);
	 * PdfValidation.validateInvoice(accountInvoice,dedicatedAccount.
	 * getAccountNumber(),outCustomerAcctNumber, dedicatedBillNumber,
	 * "1-Dec-17", dedicatedAccount.getCurrency(), outBillDueAmount);
	 * 
	 * 
	 * Utils.APP_LOGS.info("Pdf Validated for Dedicated Account: " +
	 * dedicatedAccount.getAccountNumber()); Reporter.log(
	 * "Step 4: Pdf Validated for Dedicated Account " +
	 * dedicatedAccount.getAccountNumber());
	 * 
	 * 
	 * // To create JSON object
	 * Utils.createJsonFile(Utils.addingJsonString("BRMCITJSON", testMethodName,
	 * polarity, suiteName).toString(), "BRMJsonTestResult");
	 * 
	 * } else {
	 * 
	 * Utils.APP_LOGS.info("Account is not created"); Reporter.log(
	 * "Step 1: Dedicated standalone account is NOT created "); } }
	 * 
	 *//**
		 * T S ACC T 46 verify the billing for multiple hierarchical accounts.
		 *
		 * @param currency
		 *            the currency
		 * @param paymentType
		 *            the payment type
		 * @param optinFlag
		 *            the optin flag
		 * @param contractingEntity
		 *            the contracting entity
		 * @param paperlessInvoice
		 *            the paperless invoice
		 * @param supportTeam
		 *            the support team
		 * @param payType
		 *            the pay type
		 * @param payTerm
		 *            the pay term
		 * @param inPvt
		 *            the in pvt
		 * @param dailyUsageAmount
		 *            the daily usage amount
		 * @param monthlyUsageAmount
		 *            the monthly usage amount
		 * @param fromDate
		 *            the from date
		 * @param endDate
		 *            the end date
		 * @param monthYear
		 *            the month year
		 * @param polarity
		 *            the polarity
		 * @param outContractingEntity
		 *            the out contracting entity
		 * @param outCurrency
		 *            the out currency
		 * @param outAccountNumber
		 *            the out account number
		 * @param suiteName
		 *            the suite name
		 * @param testMethodName
		 *            the test method name
		 * @param outNextBillDate
		 *            the out next bill date
		 * @param outBillDueAmount
		 *            the out bill due amount
		 * @param raxInvoiceStartDate
		 *            the rax invoice start date
		 * @param raxInvoiceEndDate
		 *            the rax invoice end date
		 * @throws Exception
		 *             the exception
		 *//*
		 * @Test(groups = { "Component", "Regression" })
		 * 
		 * @Parameters({ "In_Currency", "In_PaymentType", "In_OptionFlag",
		 * "In_ContractingEntity", "In_PaperLessInvoice", "In_SupportTeam",
		 * "In_Paytype", "In_Payterm", "In_Pvt", "In_DailyUsageAmount",
		 * "In_MonthlyUsageAmount", "In_FromDate", "In_EndDate", "In_MonthYear",
		 * "In_Polarity", "Out_ContractingEntity", "Out_Currency",
		 * "Out_AccountNumber", "Suitename", "Testname", "Out_NextBillDate",
		 * "Out_BillDueAmount","In_RaxInvoiceStartDate","In_RaxInvoiceEndDate"
		 * }) public static void
		 * TS_ACCT_46_VerifyTheBillingForMultipleHierarchicalAccounts( String
		 * currency, String paymentType, String optinFlag, String
		 * contractingEntity, String paperlessInvoice, String supportTeam,
		 * String payType, String payTerm, String inPvt, double
		 * dailyUsageAmount, double monthlyUsageAmount, String fromDate, String
		 * endDate, String monthYear, String polarity, String
		 * outContractingEntity, String outCurrency, String outAccountNumber,
		 * String suiteName, String testMethodName, String outNextBillDate,
		 * double outBillDueAmount,String raxInvoiceStartDate,String
		 * raxInvoiceEndDate) throws Exception {
		 * 
		 * // set pvt in BRM if
		 * (!BRMUtils.setPVT(BRMUtils.getPinVirtualTimeCommand(inPvt))) {
		 * 
		 * throw new Exception("Error encountered in setting PVT"); }
		 * 
		 * // Step 1: Create Dedicated account Account account =
		 * AccountFactory.createAccount(AccountType.DEDICATED);
		 * 
		 * // Set the input values into account object
		 * account.setCurrency(currency); account.setPaymentType(paymentType);
		 * account.setContractingEntity(contractingEntity);
		 * account.setPaperLessInvoice(paperlessInvoice);
		 * account.setSupportTeam(supportTeam); account.setPayType(payType);
		 * account.setPaymentTerm(payTerm);
		 * 
		 * // Compute start_t and end_t
		 * account.setStartDate(Utils.converToEpochTime(Utils
		 * .getPreviousMonthPvtDate(inPvt)));
		 * account.setEndDate(Utils.converToEpochTime(Utils
		 * .getPreviousMonthPvtDate(inPvt)));
		 * 
		 * // Create Account Profile Object; AccountProfile accProfile = new
		 * AccountProfile();
		 * 
		 * // Set the input values into accountprofile object
		 * accProfile.setOptinFlag(optinFlag);
		 * accProfile.setContractingEntity(contractingEntity);
		 * 
		 * // Associate profile to account account.setAccProfile(accProfile);
		 * 
		 * // Create AccountAction object AccountAction AccountAction = new
		 * AccountAction(); // Invoke create account
		 * AccountAction.createAccount(account); DedicatedAccount
		 * dedicatedAccount = ((DedicatedAccount) (account)); String
		 * parentDedicatedAccountNumber = account.getAccountNumber(); String
		 * parentTenantId=dedicatedAccount.getTenantId(); String
		 * parentOjectID=dedicatedAccount.getAccountPoid();
		 * 
		 * 
		 * //System.out.println("parentOjectID"+parentOjectID);
		 * Utils.APP_LOGS.info("Dedicated Account created: " +
		 * account.getAccountNumber());
		 * 
		 * // create first child dedicated account
		 * AccountAction.createAccount(account); String firstChildAccountNumber
		 * = account.getAccountNumber(); String
		 * firstChildTenantId=dedicatedAccount.getTenantId();
		 * 
		 * 
		 * 
		 * 
		 * // mapping of two accounts
		 * AccountAction.mappingOfTwoAccounts(parentDedicatedAccountNumber,
		 * account.getAccountNumber()); Utils.APP_LOGS.info(
		 * "Dedicated First ChildAccount created: " +
		 * account.getAccountNumber()); //validate hierarchical account
		 * AccountValidation.validateHierarchicalAccount(
		 * parentDedicatedAccountNumber); // create second child dedicated
		 * account
		 * 
		 * AccountAction.createAccount(account); String secondChildAccountNumber
		 * = account.getAccountNumber(); String
		 * secondChildTenantId=dedicatedAccount.getTenantId();
		 * 
		 * Utils.APP_LOGS.info("Dedicated Second ChildAccount created: " +
		 * account.getAccountNumber());
		 * 
		 * // mapping of two accounts
		 * AccountAction.mappingOfTwoAccounts(parentDedicatedAccountNumber,
		 * account.getAccountNumber());
		 * 
		 * //validate hierarchical account
		 * AccountValidation.validateHierarchicalAccount(
		 * parentDedicatedAccountNumber);
		 * 
		 * if (dedicatedAccount.getAccountNumber() != null) {
		 * 
		 * // Step 2: Post Usage for the hierarchical dedicated accounts
		 * 
		 * // Set the input values into UsageAction object UsageAction
		 * usageAction = new UsageAction(UsageType.DEDICATED,
		 * Utils.generateRandomID(), fromDate, endDate);
		 * 
		 * // Post usage usageAction.createUsage( parentTenantId,
		 * Utils.generateRandomID(), monthYear, dailyUsageAmount,
		 * monthlyUsageAmount, currency);
		 * 
		 * // Post usage for first child usageAction.createUsage(
		 * firstChildTenantId, Utils.generateRandomID(), monthYear,
		 * dailyUsageAmount, monthlyUsageAmount, currency);
		 * 
		 * // Post usage for second child usageAction.createUsage(
		 * secondChildTenantId, Utils.generateRandomID(), monthYear,
		 * dailyUsageAmount, monthlyUsageAmount, currency);
		 * 
		 * 
		 * // Validate daily usage
		 * UsageValidation.validateUsage(parentDedicatedAccountNumber,
		 * dailyUsageAmount, UsageConstants.DAILY_USAGE_QUERY); // Validate
		 * daily usage UsageValidation.validateUsage(firstChildAccountNumber,
		 * dailyUsageAmount, UsageConstants.DAILY_USAGE_QUERY); // Validate
		 * daily usage UsageValidation.validateUsage(secondChildAccountNumber,
		 * dailyUsageAmount, UsageConstants.DAILY_USAGE_QUERY);
		 * 
		 * // Validate monthly usage
		 * UsageValidation.validateUsage(parentDedicatedAccountNumber,
		 * monthlyUsageAmount, UsageConstants.MONTHLY_USAGE_QUERY); // Validate
		 * monthly usage UsageValidation.validateUsage(firstChildAccountNumber,
		 * monthlyUsageAmount, UsageConstants.MONTHLY_USAGE_QUERY); // Validate
		 * monthly usage UsageValidation.validateUsage(secondChildAccountNumber,
		 * monthlyUsageAmount, UsageConstants.MONTHLY_USAGE_QUERY);
		 * 
		 * 
		 * Utils.APP_LOGS.info("Usage is posted for Hierarchical Accounts:"
		 * +parentDedicatedAccountNumber); Reporter.log(
		 * "Step 2: Usage is posted for Dedicated Account "
		 * +parentDedicatedAccountNumber);
		 * 
		 * // Generate bill String dedicatedBillNumber = BRMJobExecutor
		 * .executeDedicatedBilling(parentDedicatedAccountNumber);
		 * 
		 * // Next billing Date validation
		 * BillValidation.validateNextBillDate(parentDedicatedAccountNumber,
		 * outNextBillDate);
		 * 
		 * // Post billing due amount validation
		 * BillValidation.validatePostBillDueAmount(parentOjectID,
		 * outBillDueAmount);
		 * 
		 * Reporter.log("Step 3: Bill Generated for Dedicated Account " +
		 * parentDedicatedAccountNumber + " Bill Number " +
		 * dedicatedBillNumber);
		 * 
		 * //validate firstChildbillNo String
		 * firstChildStatement=BillValidation.validateChildBilling(BillConstants
		 * .HIEARCHICAL_CHILD_ACCOUNT_BILLQUERY, firstChildAccountNumber);
		 * 
		 * Utils.APP_LOGS.info("Bill Generated for Dedicated Account: " +
		 * firstChildAccountNumber + " Statement Number " +
		 * firstChildStatement);
		 * 
		 * //validate secondChildbillNo String
		 * secondChildStatement=BillValidation.validateChildBilling(
		 * BillConstants.HIEARCHICAL_CHILD_ACCOUNT_BILLQUERY,
		 * secondChildAccountNumber);
		 * 
		 * 
		 * Utils.APP_LOGS.info("Bill Generated for Dedicated Account: " +
		 * secondChildAccountNumber + " Statement Number " +
		 * secondChildStatement);
		 * 
		 * 
		 * // Trigger Invoice
		 * 
		 * BRMJobExecutor.executeRaxInvAccts(BRMConstants.INVOICE_TYPE_DEFAULT,
		 * raxInvoiceStartDate, raxInvoiceEndDate);
		 * BRMJobExecutor.executeRaxInvAccts(BRMConstants.
		 * INVOICE_TYPE_STATEMENT, raxInvoiceStartDate, raxInvoiceEndDate);
		 * 
		 * // hierarchical account invoice object validation
		 * InvoiceValidation.validateHierarchicalAccountInvoiceObject(
		 * BRMConstants.RAX_INVOICE_QUERY,dedicatedBillNumber);
		 * 
		 * Utils.APP_LOGS.info("Invoice Generated for Dedicated Account: " +
		 * parentDedicatedAccountNumber); Reporter.log(
		 * "Step 4: Invoice Generated for Dedicated Account " +
		 * parentDedicatedAccountNumber);
		 * 
		 * // To create JSON object Utils.createJsonFile(
		 * Utils.addingJsonString("BRMCITJSON", testMethodName, polarity,
		 * suiteName).toString(), "BRMJsonTestResult");
		 * 
		 * } else {
		 * 
		 * Utils.APP_LOGS.info("Account is not created"); Reporter.log(
		 * "Step 1: Dedicated standalone account is NOT created "); }
		 * 
		 * 
		 * }
		 * 
		 * 
		 * 
		 * 
		 * @Test(groups = { "Component", "Regression" })
		 * 
		 * @Parameters({ "In_Currency", "In_PaymentType", "In_OptionFlag",
		 * "In_ContractingEntity", "In_PaperLessInvoice", "In_SupportTeam",
		 * "In_Paytype", "In_Payterm", "In_Pvt", "In_DailyUsageAmount",
		 * "In_MonthlyUsageAmount", "In_FromDate", "In_EndDate", "In_MonthYear",
		 * "In_Polarity", "Out_ContractingEntity", "Out_Currency",
		 * "Out_AccountNumber", "Suitename", "Testname", "Out_NextBillDate",
		 * "Out_BillDueAmount","In_RaxInvoiceStartDate","In_RaxInvoiceEndDate"
		 * }) public static void
		 * TS_ACCT_45_VerifyTheBillingForHierarchicalAccounts( String currency,
		 * String paymentType, String optinFlag, String contractingEntity,
		 * String paperlessInvoice, String supportTeam, String payType, String
		 * payTerm, String inPvt, double dailyUsageAmount, double
		 * monthlyUsageAmount, String fromDate, String endDate, String
		 * monthYear, String polarity, String outContractingEntity, String
		 * outCurrency, String outAccountNumber, String suiteName, String
		 * testMethodName, String outNextBillDate, double
		 * outBillDueAmount,String raxInvoiceStartDate,String raxInvoiceEndDate)
		 * throws Exception {
		 * 
		 * // set pvt in BRM if
		 * (!BRMUtils.setPVT(BRMUtils.getPinVirtualTimeCommand(inPvt))) {
		 * 
		 * throw new Exception("Error encountered in setting PVT"); }
		 * 
		 * // Step 1: Create Dedicated account Account account =
		 * AccountFactory.createAccount(AccountType.DEDICATED);
		 * 
		 * // Set the input values into account object
		 * account.setCurrency(currency); account.setPaymentType(paymentType);
		 * account.setContractingEntity(contractingEntity);
		 * account.setPaperLessInvoice(paperlessInvoice);
		 * account.setSupportTeam(supportTeam); account.setPayType(payType);
		 * account.setPaymentTerm(payTerm);
		 * 
		 * // Compute start_t and end_t
		 * account.setStartDate(Utils.converToEpochTime(Utils
		 * .getPreviousMonthPvtDate(inPvt)));
		 * account.setEndDate(Utils.converToEpochTime(Utils
		 * .getPreviousMonthPvtDate(inPvt)));
		 * 
		 * // Create Account Profile Object; AccountProfile accProfile = new
		 * AccountProfile();
		 * 
		 * // Set the input values into accountprofile object
		 * accProfile.setOptinFlag(optinFlag);
		 * accProfile.setContractingEntity(contractingEntity);
		 * 
		 * // Associate profile to account account.setAccProfile(accProfile);
		 * 
		 * // Create AccountAction object AccountAction AccountAction = new
		 * AccountAction(); // Invoke create account
		 * AccountAction.createAccount(account); DedicatedAccount
		 * dedicatedAccount = ((DedicatedAccount) (account));
		 * 
		 * String parentDedicatedAccountNumber =
		 * dedicatedAccount.getAccountNumber();
		 * //System.out.println("parentDedicatedAccountNumber"+
		 * parentDedicatedAccountNumber); String
		 * parentTenantId=dedicatedAccount.getTenantId(); String
		 * parentOjectID=dedicatedAccount.getAccountPoid();
		 * 
		 * //System.out.println("parentTenantId"+parentTenantId);
		 * 
		 * Utils.APP_LOGS.info("Dedicated Account created: " +
		 * account.getAccountNumber());
		 * 
		 * // create first child dedicated account
		 * AccountAction.createAccount(account); String firstChildAccountNumber
		 * = account.getAccountNumber(); String
		 * firstChildTenantId=dedicatedAccount.getTenantId();
		 * //System.out.println("firstChildTenantId"+firstChildTenantId);
		 * 
		 * // mapping of two accounts
		 * AccountAction.mappingOfTwoAccounts(parentDedicatedAccountNumber,
		 * firstChildAccountNumber); Utils.APP_LOGS.info(
		 * "Dedicated First ChildAccount created: " +
		 * account.getAccountNumber());
		 * 
		 * //validate hierarchical account
		 * AccountValidation.validateHierarchicalAccount(
		 * parentDedicatedAccountNumber);
		 * 
		 * //validate hierarchical account
		 * AccountValidation.validateHierarchicalAccount(
		 * parentDedicatedAccountNumber);
		 * 
		 * if (dedicatedAccount.getAccountNumber() != null) {
		 * 
		 * // Step 2: Post Usage for the hierarchical dedicated accounts // Set
		 * the input values into UsageAction object UsageAction usageAction =
		 * new UsageAction(UsageType.DEDICATED, Utils.generateRandomID(),
		 * fromDate, endDate);
		 * 
		 * // Post usage usageAction.createUsage( parentTenantId,
		 * Utils.generateRandomID(), monthYear, dailyUsageAmount,
		 * monthlyUsageAmount, currency);
		 * 
		 * // Post usage for first child usageAction.createUsage(
		 * firstChildTenantId, Utils.generateRandomID(), monthYear,
		 * dailyUsageAmount, monthlyUsageAmount, currency);
		 * 
		 * // Validate daily usage
		 * UsageValidation.validateUsage(parentDedicatedAccountNumber,
		 * dailyUsageAmount, UsageConstants.DAILY_USAGE_QUERY); // Validate
		 * daily usage UsageValidation.validateUsage(firstChildAccountNumber,
		 * dailyUsageAmount, UsageConstants.DAILY_USAGE_QUERY);
		 * 
		 * // Validate monthly usage
		 * UsageValidation.validateUsage(parentDedicatedAccountNumber,
		 * monthlyUsageAmount, UsageConstants.MONTHLY_USAGE_QUERY); // Validate
		 * monthly usage UsageValidation.validateUsage(firstChildAccountNumber,
		 * monthlyUsageAmount, UsageConstants.MONTHLY_USAGE_QUERY);
		 * 
		 * 
		 * Utils.APP_LOGS.info("Usage is posted for Hierarchical Accounts:"
		 * +parentDedicatedAccountNumber); Reporter.log(
		 * "Step 2: Usage is posted for Dedicated Account "
		 * +parentDedicatedAccountNumber);
		 * 
		 * // Generate bill String dedicatedBillNumber = BRMJobExecutor
		 * .executeDedicatedBilling(parentDedicatedAccountNumber);
		 * 
		 * // Next billing Date validation
		 * BillValidation.validateNextBillDate(parentDedicatedAccountNumber,
		 * outNextBillDate);
		 * 
		 * // Post billing due amount validation
		 * BillValidation.validatePostBillDueAmount(parentOjectID,
		 * outBillDueAmount);
		 * 
		 * 
		 * Reporter.log("Step 3: Bill Generated for Dedicated Account " +
		 * parentDedicatedAccountNumber + " Bill Number " +
		 * dedicatedBillNumber);
		 * 
		 * //validate firstChildbillNo String
		 * firstChildStatement=BillValidation.validateChildBilling(BillConstants
		 * .HIEARCHICAL_CHILD_ACCOUNT_BILLQUERY, firstChildAccountNumber);
		 * 
		 * Utils.APP_LOGS.info("Bill Generated for Dedicated Account: " +
		 * firstChildAccountNumber + " Statement Number " +
		 * firstChildStatement);
		 * 
		 * // Trigger Invoice
		 * 
		 * BRMJobExecutor.executeRaxInvAccts(BRMConstants.INVOICE_TYPE_DEFAULT,
		 * raxInvoiceStartDate, raxInvoiceEndDate);
		 * BRMJobExecutor.executeRaxInvAccts(BRMConstants.
		 * INVOICE_TYPE_STATEMENT, raxInvoiceStartDate, raxInvoiceEndDate);
		 * 
		 * // hierarchical account invoice object validation
		 * InvoiceValidation.validateHierarchicalAccountInvoiceObject(
		 * BRMConstants.RAX_INVOICE_QUERY,dedicatedBillNumber);
		 * 
		 * Utils.APP_LOGS.info("Invoice Generated for Dedicated Account: " +
		 * parentDedicatedAccountNumber); Reporter.log(
		 * "Step 4: Invoice Generated for Dedicated Account " +
		 * parentDedicatedAccountNumber);
		 * 
		 * // To create JSON object Utils.createJsonFile(
		 * Utils.addingJsonString("BRMCITJSON", testMethodName, polarity,
		 * suiteName).toString(), "BRMJsonTestResult");
		 * 
		 * } else {
		 * 
		 * Utils.APP_LOGS.info("Account is not created"); Reporter.log(
		 * "Step 1: Dedicated standalone account is NOT created "); }
		 * 
		 * 
		 * }
		 */

	/**
	 * To retrieve Test CM log and DM logFiles.
	 * 
	 * @throws IOException
	 *             Signals that an I/O exception has occurred.
	 * 
	 */
	@AfterTest(alwaysRun = true)
	public static void retrieveTestLogFiles() throws IOException {

		// BRMUtils.getCMLogs();
		// BRMUtils.getDMLogs();
	}

}
