package com.rackspace.sl.payment.met;

import io.restassured.RestAssured;
import io.restassured.http.Method;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class RestAPICallForGetTemplateByID {
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		executeGetRestAPIConnectionPostWithToken();

	}

	private static synchronized void executeGetRestAPIConnectionPostWithToken() {
		// TODO Auto-generated method stub
		
		String token="AADPK1Mum_e6ruQZYyzmtWU2Py13uPEtxSLy-mo4i4OzE15PXZ9-JqZK7OFiOUMOrjCG-UqRRzLoEIgTmWu--y9okD0GqnZRkIfBIvq-I7m_b3SbStqsBont";
		
		RestAssured.baseURI = "https://cit3.bazooka.api.rackspacecloud.com/v1/templates/BILLING_PRIMARY_METHOD_CHANGED";

		RestAssured.useRelaxedHTTPSValidation();

		RequestSpecification httpRequest = RestAssured.given().header("X-Auth-Token", token)
				.accept("application/json").contentType("application/json").body("");
		
		Response response = httpRequest.request(Method.GET);

		String responseBody = response.getBody().asString();

		System.out.println("Response Body of Template =>  " + responseBody);
		
		int repsonsecode = response.getStatusCode();
		
		System.out.println("repsonsecode is "+ repsonsecode);

		
		
	}

}
