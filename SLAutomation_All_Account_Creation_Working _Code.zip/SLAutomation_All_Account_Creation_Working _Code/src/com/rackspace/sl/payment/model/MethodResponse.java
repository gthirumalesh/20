
package com.rackspace.sl.payment.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

// TODO: Auto-generated Javadoc
/**
 * The Class MethodResponse.
 */
public class MethodResponse {

	/** The payment card respone. */
	@SerializedName("paymentCardRespone")
	@Expose
	private PaymentCardRespone paymentCardRespone;
	
	/** The id. */
	@SerializedName("id")
	@Expose
	private String id;
	
	/** The creation date. */
	@SerializedName("creationDate")
	@Expose
	private String creationDate;
	
	/** The is default. */
	@SerializedName("isDefault")
	@Expose
	private Boolean isDefault;
	
	/** The status. */
	@SerializedName("status")
	@Expose
	private String status;
	
	/** The ran. */
	@SerializedName("ran")
	@Expose
	private String ran;
	
	/**
	 * Gets the payment card respone.
	 *
	 * @return the payment card respone
	 */
	public PaymentCardRespone getPaymentCardRespone() {
		return paymentCardRespone;
	}
	
	/**
	 * Sets the payment card respone.
	 *
	 * @param paymentCardRespone the new payment card respone
	 */
	public void setPaymentCardRespone(PaymentCardRespone paymentCardRespone) {
		this.paymentCardRespone = paymentCardRespone;
	}
	
	/**
	 * Gets the id.
	 *
	 * @return the id
	 */
	public String getId() {
		return id;
	}
	
	/**
	 * Sets the id.
	 *
	 * @param id the new id
	 */
	public void setId(String id) {
		this.id = id;
	}
	
	/**
	 * Gets the creation date.
	 *
	 * @return the creation date
	 */
	public String getCreationDate() {
		return creationDate;
	}
	
	/**
	 * Sets the creation date.
	 *
	 * @param creationDate the new creation date
	 */
	public void setCreationDate(String creationDate) {
		this.creationDate = creationDate;
	}
	
	/**
	 * Gets the checks if is default.
	 *
	 * @return the checks if is default
	 */
	public Boolean getIsDefault() {
		return isDefault;
	}
	
	/**
	 * Sets the checks if is default.
	 *
	 * @param isDefault the new checks if is default
	 */
	public void setIsDefault(Boolean isDefault) {
		this.isDefault = isDefault;
	}
	
	/**
	 * Gets the status.
	 *
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}
	
	/**
	 * Sets the status.
	 *
	 * @param status the new status
	 */
	public void setStatus(String status) {
		this.status = status;
	}
	
	/**
	 * Gets the ran.
	 *
	 * @return the ran
	 */
	public String getRan() {
		return ran;
	}
	
	/**
	 * Sets the ran.
	 *
	 * @param ran the new ran
	 */
	public void setRan(String ran) {
		this.ran = ran;
	}

	

}
