
package com.rackspace.sl.rbacprofile.model;

import java.util.List;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/**
 * The Class Token.
 */
public class Token {

    /** The expires. */
    @SerializedName("expires")
    @Expose
    private String expires;
    
    /** The r AXAUTH issued. */
    @SerializedName("RAX-AUTH:issued")
    @Expose
    private String rAXAUTHIssued;
    
    /** The r AXAUTH authenticated by. */
    @SerializedName("RAX-AUTH:authenticatedBy")
    @Expose
    private List<String> rAXAUTHAuthenticatedBy = null;
    
    /** The id. */
    @SerializedName("id")
    @Expose
    private String id;
    
    /** The tenant. */
    @SerializedName("tenant")
    @Expose
    private Tenant tenant;

    /**
     * Gets the expires.
     *
     * @return the expires
     */
    public String getExpires() {
        return expires;
    }

    /**
     * Sets the expires.
     *
     * @param expires the new expires
     */
    public void setExpires(String expires) {
        this.expires = expires;
    }

    /**
     * Gets the RAXAUTH issued.
     *
     * @return the RAXAUTH issued
     */
    public String getRAXAUTHIssued() {
        return rAXAUTHIssued;
    }

    /**
     * Sets the RAXAUTH issued.
     *
     * @param rAXAUTHIssued the new RAXAUTH issued
     */
    public void setRAXAUTHIssued(String rAXAUTHIssued) {
        this.rAXAUTHIssued = rAXAUTHIssued;
    }

    /**
     * Gets the RAXAUTH authenticated by.
     *
     * @return the RAXAUTH authenticated by
     */
    public List<String> getRAXAUTHAuthenticatedBy() {
        return rAXAUTHAuthenticatedBy;
    }

    /**
     * Sets the RAXAUTH authenticated by.
     *
     * @param rAXAUTHAuthenticatedBy the new RAXAUTH authenticated by
     */
    public void setRAXAUTHAuthenticatedBy(List<String> rAXAUTHAuthenticatedBy) {
        this.rAXAUTHAuthenticatedBy = rAXAUTHAuthenticatedBy;
    }

    /**
     * Gets the id.
     *
     * @return the id
     */
    public String getId() {
        return id;
    }

    /**
     * Sets the id.
     *
     * @param id the new id
     */
    public void setId(String id) {
        this.id = id;
    }

    /**
     * Gets the tenant.
     *
     * @return the tenant
     */
    public Tenant getTenant() {
        return tenant;
    }

    /**
     * Sets the tenant.
     *
     * @param tenant the new tenant
     */
    public void setTenant(Tenant tenant) {
        this.tenant = tenant;
    }

}
