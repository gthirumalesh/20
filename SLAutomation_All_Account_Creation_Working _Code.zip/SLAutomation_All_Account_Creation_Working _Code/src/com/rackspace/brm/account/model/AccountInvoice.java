package com.rackspace.brm.account.model;

import java.util.ArrayList;
import java.util.HashMap;

public class AccountInvoice {

	protected String invoiceObj = null;
	protected String accountNumber = null;
	protected String customerNumber = null;
	protected String currency = null;
	protected String invoiceNumber = null;
	protected String invoiceDate = null;

	protected String sellerOfRecords = null;
	protected String rackspaceLogoAddress = null;
	protected String paymentTerm = null;
	/**
	 * The below variable is used to store "Make Payment to payable" with
	 * respect to type of payment
	 */

	protected String[] paymentInstruction = null;
	protected String paymentPayableInfo = null;
	protected String invoiceAmountDue = null;

	protected String totalGross = null;
	protected String totalDiscount = null;
	protected String totalNetCharge = null;
	protected String totalTaxAmount = null;
	protected String totalCharges = null;

	protected ArrayList<AccountNameInfo> accountNameInfoList = null;
	protected ArrayList<InvoiceServiceSummary> serviceSummaryList = null;
	protected ArrayList<InvoiceServiceSummary> otherServicesSummaryList = null;
	protected ArrayList<InvoiceDiscountPromotionSummary> discountPromotionSummary = null;

	protected HashMap<String, Double> taxSummaryMap = null;
	protected HashMap<String, Double> currencyConversionMap = null;

	public String getInvoiceObj() {
		return invoiceObj;
	}

	public void setInvoiceObj(String invoiceObj) {
		this.invoiceObj = invoiceObj;
	}

	public String getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getCustomerNumber() {
		return customerNumber;
	}

	public void setCustomerNumber(String customerNumber) {
		this.customerNumber = customerNumber;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public String getInvoiceNumber() {
		return invoiceNumber;
	}

	public void setInvoiceNumber(String invoiceNumber) {
		this.invoiceNumber = invoiceNumber;
	}

	public String getInvoiceDate() {
		return invoiceDate;
	}

	public void setInvoiceDate(String invoiceDate) {
		this.invoiceDate = invoiceDate;
	}

	public String getSellerOfRecords() {
		return sellerOfRecords;
	}

	public void setSellerOfRecords(String sellerOfRecords) {
		this.sellerOfRecords = sellerOfRecords;
	}

	public String getRackspaceLogoAddress() {
		return rackspaceLogoAddress;
	}

	public void setRackspaceLogoAddress(String rackspaceLogoAddress) {
		this.rackspaceLogoAddress = rackspaceLogoAddress;
	}

	public String getPaymentTerm() {
		return paymentTerm;
	}

	public void setPaymentTerm(String paymentTerm) {
		this.paymentTerm = paymentTerm;
	}

	public String[] getPaymentInstruction() {
		return paymentInstruction;
	}

	public void setPaymentInstruction(String[] paymentInstruction) {
		this.paymentInstruction = paymentInstruction;
	}

	public String getPaymentPayableInfo() {
		return paymentPayableInfo;
	}

	public void setPaymentPayableInfo(String paymentPayableInfo) {
		this.paymentPayableInfo = paymentPayableInfo;
	}

	public String getInvoiceAmountDue() {
		return invoiceAmountDue;
	}

	public void setInvoiceAmountDue(String invoiceAmountDue) {
		this.invoiceAmountDue = invoiceAmountDue;
	}

	public String getTotalGross() {
		return totalGross;
	}

	public void setTotalGross(String totalGross) {
		this.totalGross = totalGross;
	}

	public String getTotalDiscount() {
		return totalDiscount;
	}

	public void setTotalDiscount(String totalDiscount) {
		this.totalDiscount = totalDiscount;
	}

	public String getTotalNetCharge() {
		return totalNetCharge;
	}

	public void setTotalNetCharge(String totalNetCharge) {
		this.totalNetCharge = totalNetCharge;
	}

	public String getTotalTaxAmount() {
		return totalTaxAmount;
	}

	public void setTotalTaxAmount(String totalTaxAmount) {
		this.totalTaxAmount = totalTaxAmount;
	}

	public String getTotalCharges() {
		return totalCharges;
	}

	public void setTotalCharges(String totalCharges) {
		this.totalCharges = totalCharges;
	}

	public ArrayList<AccountNameInfo> getAccountNameinfoList() {
		return accountNameInfoList;
	}

	public void setAccountNameinfoList(ArrayList<AccountNameInfo> accountNameinfoList) {
		this.accountNameInfoList = accountNameinfoList;
	}

	public ArrayList<InvoiceServiceSummary> getServiceSummaryList() {
		return serviceSummaryList;
	}

	public void setServiceSummaryList(ArrayList<InvoiceServiceSummary> serviceSummaryList) {
		this.serviceSummaryList = serviceSummaryList;
	}

	public ArrayList<InvoiceServiceSummary> getOtherServicesSummaryList() {
		return otherServicesSummaryList;
	}

	public void setOtherServicesSummaryList(ArrayList<InvoiceServiceSummary> otherServicesSummaryList) {
		this.otherServicesSummaryList = otherServicesSummaryList;
	}

	public ArrayList<InvoiceDiscountPromotionSummary> getDiscountPromotionSummary() {
		return discountPromotionSummary;
	}

	public void setDiscountPromotionSummary(ArrayList<InvoiceDiscountPromotionSummary> discountPromotionSummary) {
		this.discountPromotionSummary = discountPromotionSummary;
	}

	public HashMap<String, Double> getTaxSummaryMap() {
		return taxSummaryMap;
	}

	public void setTaxSummaryMap(HashMap<String, Double> taxSummaryMap) {
		this.taxSummaryMap = taxSummaryMap;
	}

	public HashMap<String, Double> getCurrencyConversionMap() {
		return currencyConversionMap;
	}

	public void setCurrencyConversionMap(HashMap<String, Double> currencyConversionMap) {
		this.currencyConversionMap = currencyConversionMap;
	}

}
