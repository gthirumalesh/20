package com.rackspace.brm.common.parser;

import java.util.Enumeration;

import com.portal.pcm.EBufException;
import com.portal.pcm.FList;
import com.portal.pcm.SparseArray;
import com.portal.pcm.fields.FldAccountNo;
import com.portal.pcm.fields.FldAccountObj;
import com.portal.pcm.fields.FldAcctinfo;
import com.portal.pcm.fields.FldActgFutureDom;
import com.portal.pcm.fields.FldBillinfo;
import com.portal.pcm.fields.FldCurrency;
import com.portal.pcm.fields.FldGlSegment;
import com.portal.pcm.fields.FldPoid;
import com.rackspace.brm.account.model.Account;
import com.rackspace.brm.account.model.AccountBillInfo;
import com.rackspace.brm.account.model.AccountPayInfo;
import com.rackspace.sl.event.model.Event;
import com.rax.brm.customfields.RaxFldTenantId;

public class FListParser {

	public FListParser() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * This method is used to set the account attributes which is being
	 * retrieved from BRM upon account creation. For example, the method is used
	 * to set account poid, bill info poid, accounting future DOM etc.
	 * 
	 * @param opFlist
	 *            output flist returned by BRM upon opcode execution
	 * @param accountModel
	 *            account model object to hold account attributes
	 * @throws Exception
	 *             upon any failure while retrieving attributes from flist
	 */
	public static Account parseCustCommitOutputFlist(FList opFlist) throws EBufException {

		Account account = new Account();

		String accountNumber = opFlist.get(FldAccountNo.getInst());
		account.setAccountNumber(accountNumber);
		account.setAccountObj(opFlist.get(FldAccountObj.getInst()).toString());
		account.setTenantId(opFlist.get(RaxFldTenantId.getInst()).toString());
		
		SparseArray accountInfoArray = opFlist.get(FldAcctinfo.getInst());
		Enumeration<FList> enumResultsAcctInfo = accountInfoArray.getValueEnumerator();
		if (enumResultsAcctInfo.hasMoreElements()) {
			FList f = (FList) enumResultsAcctInfo.nextElement();
			account.setCurrency(f.get(FldCurrency.getInst()).toString());
			account.setGlSegment(f.get(FldGlSegment.getInst()).toString());
		}

		AccountBillInfo accountBillInfo = new AccountBillInfo();
		SparseArray billInfoArray = opFlist.get(FldBillinfo.getInst());
		Enumeration<FList> enumResultsBillInfo = billInfoArray.getValueEnumerator();
		if (enumResultsBillInfo.hasMoreElements()) {
			FList f = (FList) enumResultsBillInfo.nextElement();
			accountBillInfo.setBillinfoObj(f.get(FldPoid.getInst()).toString());
			accountBillInfo.setActgFutureDom(f.get(FldActgFutureDom.getInst()).toString());
		}
		return account;
	}
	
	public static Account parseGenPayLoadOutputFlist(FList opFlist) throws EBufException {
		Account account = new Account();
		
		String payment = opFlist.get(FldPoid.getInst()).getType();
		System.out.println("payment type:::" + payment);
		
		AccountPayInfo accountPayinfo = new AccountPayInfo();
		accountPayinfo.setPaymentType(payment);
		account.getPayinfoList().add(accountPayinfo);
		
		System.out.println("payment in Flist Prser " + payment);
		System.out.println("payment in Flist Prser****** " + account.getPayinfoList().add(accountPayinfo));
		
		
		//0 PIN_FLD_POID           POID [0] 0.0.0.1 /event/rackspace/notify/payment/method/primary/ach -1 0
		
		return account;
		
	}

	
}
