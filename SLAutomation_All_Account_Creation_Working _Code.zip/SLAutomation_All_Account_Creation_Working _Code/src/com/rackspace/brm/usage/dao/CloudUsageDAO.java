package com.rackspace.brm.usage.dao;

import java.io.IOException;
import java.util.Date;

import com.rackspace.brm.usage.constants.UsageConstants.UsageType;
import com.rackspace.brm.usage.model.DedicatedUsage;
import com.rackspace.brm.usage.model.Usage;

// TODO: Auto-generated Javadoc
/**
 * The Class CloudUsageDAO.
 */
public class CloudUsageDAO extends Usage {

	/**
	 * Instantiates a new cloud usage DAO.
	 *
	 * @param usageType the usage type
	 */
	public CloudUsageDAO(UsageType usageType) {
		super(usageType);
		// TODO Auto-generated constructor stub
	}

	/**
	 * This method will read the usage model from Dedicated Usage class and
	 * prepare dedicated EBS usage file to be processed.
	 *
	 * @param batchId the batch id
	 * @param fromDate the from date
	 * @param endDate the end date
	 * @param billingType the billing type
	 * @param dedicatedUsage the dedicated usage
	 * @throws IOException Signals that an I/O exception has occurred.
	 */
	public static void generateCloudUsage(String batchId, String fromDate, String endDate, String billingType,
			DedicatedUsage dedicatedUsage) throws IOException {
		String templateFile = null;
		String fileName = "" + new Date(); // Timestamp should be appended to
											// keep

	}
}
