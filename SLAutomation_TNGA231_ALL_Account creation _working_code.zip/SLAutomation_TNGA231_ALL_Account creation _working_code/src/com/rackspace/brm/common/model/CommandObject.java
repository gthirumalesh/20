package com.rackspace.brm.common.model;

public class CommandObject {

	private String type = null;
	private String command = null;
	private String optionalParameters = null;
	private String stdOut = null;
	private String stdErr = null;

	public CommandObject() {
		// TODO Auto-generated constructor stub
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getCommand() {
		return command;
	}

	public void setCommand(String command) {
		this.command = command;
	}

	public String getOptionalParameters() {
		return optionalParameters;
	}

	public void setOptionalParameters(String optionalParameters) {
		this.optionalParameters = optionalParameters;
	}

	public String getStdOut() {
		return stdOut;
	}

	public void setStdOut(String stdOut) {
		this.stdOut = stdOut;
	}

	public String getStdErr() {
		return stdErr;
	}

	public void setStdErr(String stdErr) {
		this.stdErr = stdErr;
	}

}
