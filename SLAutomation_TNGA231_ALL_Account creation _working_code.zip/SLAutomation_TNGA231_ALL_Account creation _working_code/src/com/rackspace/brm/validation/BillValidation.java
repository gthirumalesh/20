package com.rackspace.brm.validation;

import org.apache.log4j.Logger;
import org.testng.Assert;

import com.rackspace.brm.common.Utils;

/**
 * The Class BillValidation.
 */
public class BillValidation {

	/**
	 * Validate next bill date.
	 *
	 * @param accountNumber
	 *            the account number
	 * @param outNextBillDate
	 *            the out billing value
	 * @return the string
	 * 
	 * @throws Exception
	 *             the exception
	 */
	public static String validateNextBillDate(String accountNumber, String outNextBillDate) throws Exception {

		Utils.APP_LOGS.info("Enter:validateNextBillDate()");
		String getNextBillDate = null;

		try {
			getNextBillDate = Utils.getPvtForBilling(accountNumber, "MMddyyyy", 0, "", "");

			if (!outNextBillDate.isEmpty()) {
				Assert.assertEquals(getNextBillDate, outNextBillDate);
			} else {
				Utils.APP_LOGS.error("Next bill date is null");
				Assert.fail("Out Billing next date is null ");
			}
		} catch (Exception e) {
			Utils.APP_LOGS.error("NextBillDate can not be validate in validateNextBillDate()" + e);
		}
		Utils.APP_LOGS.info("Exit:validateNextBillDate()");
		return getNextBillDate;
	}

	/**
	 * Validate post billing due.
	 *
	 * @param accountObjID
	 *            the account obj ID
	 * @param outBillDueAmount
	 *            the out bill due amount
	 * @return the string
	 * @throws Exception
	 *             the exception
	 */
	public static String validatePostBillDueAmount(String accountObjID, Double outBillDueAmount) throws Exception {

		Utils.APP_LOGS.info("Enter: validatePostBillDueAmount()");

		String postBillDueAmount = null;
		try {
			postBillDueAmount = Utils.retrieveDetailsFromDB("dueAmountQuery", accountObjID);

			if (!String.valueOf(outBillDueAmount).isEmpty()) {
				Assert.assertEquals(postBillDueAmount, String.valueOf(outBillDueAmount));
			} else {
				Utils.APP_LOGS.error("Post bill due amount is null");
				Assert.fail("Post bill due amount is null");
			}
		} catch (Exception e) {
			Utils.APP_LOGS.error("Billing due amount not validated" + e);
		}
		Utils.APP_LOGS.info("Exit: validatePostBillDueAmount()");
		return postBillDueAmount;
	}

	/**
	 * Validate billing.
	 *
	 * @param accountNumber
	 *            the account number
	 * @throws Exception
	 *             the exception
	 */
	public static void validateBilling(String accountNumber) throws Exception {

		try {
			Utils.APP_LOGS.info("Enter:UsageValidation()");
			String actualUsageAmount = Utils.retrieveDetailsFromDB("usageQuery", accountNumber);
		} catch (Exception e) {
			e.printStackTrace();
		}
		Utils.APP_LOGS.info("Exit:UsageValidation()");
	}

	/**
	 * Validate child billing.
	 *
	 * @param query
	 *            the query
	 * @param accountNumber
	 *            the account number
	 * @throws Exception
	 *             the exception
	 */
	public static String validateChildBilling(String query, String accountNumber) throws Exception {
		String childStatement = null;
		try {
			Utils.APP_LOGS.info("Enter:UsageValidation()");
			childStatement = Utils.retrieveDetailsFromDB(query, accountNumber);
		} catch (Exception e) {
			e.printStackTrace();
		}
		Utils.APP_LOGS.info("Exit:UsageValidation()");
		return childStatement;
	}
}
