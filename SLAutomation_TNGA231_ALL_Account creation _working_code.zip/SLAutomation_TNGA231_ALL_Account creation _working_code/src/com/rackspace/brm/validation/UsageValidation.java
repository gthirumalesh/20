package com.rackspace.brm.validation;

import org.testng.Assert;

import com.rackspace.brm.common.Utils;

public class UsageValidation {

	public static void validateUsage(String accountNumber, double expected, String query) throws Exception {

		String actualUsageAmount = null;

		try {
			Utils.APP_LOGS.info("Enter:UsageValidation()");
			String expectedAmount = Double.toString(expected);

			actualUsageAmount = Utils.retrieveDetailsFromDB(query, accountNumber);
			Double usageAmountCovert = Double.parseDouble(actualUsageAmount);
			usageAmountCovert = (double) Math.round(usageAmountCovert);
			// System.out.println("usage Value: "+query+usageAmountCovert);
			actualUsageAmount = usageAmountCovert.toString();
			Assert.assertEquals(actualUsageAmount, expectedAmount);

		} catch (Exception e) {
			Utils.APP_LOGS.error("Usage can not be validate" + e);
		}
		Utils.APP_LOGS.info("Exit:UsageValidation()");
	}
}
