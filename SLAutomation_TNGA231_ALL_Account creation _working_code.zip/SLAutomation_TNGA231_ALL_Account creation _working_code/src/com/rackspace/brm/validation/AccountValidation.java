package com.rackspace.brm.validation;

import java.util.Enumeration;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.testng.Assert;

import com.portal.pcm.FList;
import com.portal.pcm.Poid;
import com.portal.pcm.PortalContext;
import com.portal.pcm.SparseArray;
import com.portal.pcm.fields.FldAccountObj;
import com.portal.pcm.fields.FldArgs;
import com.portal.pcm.fields.FldFlags;
import com.portal.pcm.fields.FldLogin;
import com.portal.pcm.fields.FldPoid;
import com.portal.pcm.fields.FldResults;
import com.portal.pcm.fields.FldTemplate;
import com.rackspace.brm.account.model.Account;
import com.rackspace.brm.common.Utils;
import com.rackspace.brm.connection.BRMPortalConnection;

public class AccountValidation {

	/**
	 * The portalContext used to store the portal context value.
	 */
	static PortalContext portalContext = null;

	/**
	 * Account validation.
	 *
	 * @param tenantID
	 *            the tenant ID
	 * @return the string
	 * @throws Exception
	 *             the exception
	 */
	public static String accountValidation(String tenantID) throws Exception {
		Utils.APP_LOGS.info("Enter:accountValidation()");

		String AccountFromtenantId = null;
		portalContext = BRMPortalConnection.getBRMPortalConnection();

		String acctObj = "";
		String strTemplate = "select X from /service where F1 like V1 ";
		FList inputFlist = new FList();

		long db = portalContext.getCurrentDB();

		Poid s_poid = new Poid(db, 0, "/search", 0);
		inputFlist.set(FldPoid.getInst(), s_poid);

		inputFlist.set(FldFlags.getInst(), 0);

		inputFlist.set(FldTemplate.getInst(), strTemplate);

		FList args = new FList();

		args.set(FldLogin.getInst(), tenantID);

		inputFlist.set(FldLogin.getInst(), tenantID);

		inputFlist.setElement(FldArgs.getInst(), 1, args);

		FList results = new FList();

		inputFlist.setElement(FldResults.getInst(), 1, results);

		FList outputFlist = portalContext.opcode(7, 0, inputFlist);

		if (outputFlist.hasField(FldResults.getInst())) {
			SparseArray resArray = outputFlist.get(FldResults.getInst());
			Enumeration enumResults = resArray.getValueEnumerator();
			while (enumResults.hasMoreElements()) {
				FList f = (FList) enumResults.nextElement();
				acctObj = f.get(FldAccountObj.getInst()).toString();

			}
		}

		String pattern = "(.*?)account\\s*(\\d+)\\s+(\\d+)";
		Pattern r = Pattern.compile(pattern);

		if (acctObj.contains("account")) {
			Matcher m = r.matcher(acctObj);

			if (m.find()) {
				AccountFromtenantId = m.group(2);
			}

		}

		Assert.assertNotNull(AccountFromtenantId);
		return AccountFromtenantId;
	}

	/**
	 * Validate account fields based on input xml values.
	 *
	 * @param opcode
	 *            the opcode
	 * @param args
	 *            the args
	 * @param argInputFields
	 *            the arg input fields
	 * @throws Exception
	 *             the exception
	 */
	public static void validateAccount(Account account) throws Exception {
		// To implement validation logic for required parameters by passing poid
		// value
		// The code snippet is removed since the validation logic is changed
		// from output flist to opcode call on demand
	}

	/**
	 * Validate hierarchical account.
	 *
	 * @param accountNumber
	 *            the account number
	 * @throws Exception
	 *             the exception
	 */
	public static void validateHierarchicalAccount(String accountNumber) throws Exception {

		try {
			Utils.APP_LOGS.info("Enter:validateHierarchicalAccount()");

			String invoiceObjectID = Utils.retrieveDetailsFromDB("hierarchicalQuery", accountNumber);

			if (invoiceObjectID != null) {
				// System.out.println("invoiceObjectID:"+invoiceObjectID);
				Assert.assertEquals("/group/billing", invoiceObjectID);
			} else {
				Assert.fail("Account not consolidated");
			}

		} catch (Exception e) {
			Utils.APP_LOGS.error("Account not consolidated" + e);
		}
		Utils.APP_LOGS.info("Exit:validateHierarchicalAccount()");

	}
	
	
	/**
	 * Validate payment method.
	 *
	 * @param eventAccount the event account
	 */
	public static void ValidatePaymentMethod(Account eventAccount) {
		
		Assert.assertNotNull(eventAccount.getPayinfoList().get(0).getPaymentType());
		 
	}

}
