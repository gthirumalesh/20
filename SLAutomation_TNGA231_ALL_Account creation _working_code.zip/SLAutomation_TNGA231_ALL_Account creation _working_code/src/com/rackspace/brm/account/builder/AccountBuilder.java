package com.rackspace.brm.account.builder;

import com.rackspace.brm.account.constants.AccountConstants.AccountType;
import com.rackspace.brm.account.constants.AccountConstants.BillingSegment;
import com.rackspace.brm.account.constants.AccountConstants.GLSegment;
import com.rackspace.brm.account.model.Account;
import com.rackspace.brm.account.model.AccountBillInfo;
import com.rackspace.brm.account.model.AccountNameInfo;
import com.rackspace.brm.account.model.AccountPayInfo;
import com.rackspace.brm.account.model.AccountProfile;
import com.rackspace.brm.constants.BRMConstants;
import com.rackspace.sl.constants.AccountConstants;


/**
 * The Class AccountBuilder.
 */
public class AccountBuilder {

	/** The account. */
	private Account account = null;

	/**
	 * Instantiates a new account builder.
	 *
	 * @param accountType the account type
	 * @param coreAcctNumber the core acct number
	 * @param tenantId the tenant id
	 * @param currency the currency
	 * @param payType the pay type
	 * @param optinFlag the optin flag
	 * @param contractingEntity the contracting entity
	 * @param paperlessInvoice the paperless invoice
	 * @param supportTeam the support team
	 * @param paymentTerm the payment term
	 * @param vatNumber the vat number
	 * @param paperlessMemo the paperless memo
	 * @param paperlessInvoiceFlag the paperless invoice flag
	 * @param emailInvOptinFlag the email inv optin flag
	 * @param startDate the start date
	 * @param endDate the end date
	 * @param paymentType the payment type
	 */
	public AccountBuilder(AccountType accountType, String coreAcctNumber, String tenantId, String currency,
			String payType, String optinFlag, String contractingEntity, String paperlessInvoice, String supportTeam,
			String paymentTerm, String vatNumber, String paperlessMemo, String paperlessInvoiceFlag,
			String emailInvOptinFlag, String startDate, String endDate, String paymentType) {

		account = new Account();
		account.setTenantId(tenantId);
		account.setCurrency(currency);
		account.setStartDate(startDate);
		account.setEndDate(endDate);
		account.setAccountType(accountType);
		this.setGLSegment(accountType);
		this.setCloudAccountNumber(account);
		this.buildAccountProfile(coreAcctNumber, optinFlag, contractingEntity, supportTeam, vatNumber, paperlessMemo,
				paperlessInvoiceFlag, emailInvOptinFlag, paymentTerm);
		this.buildBillInfo(accountType, payType);
		this.buildPayinfo(payType, paymentType);
		this.buildAccountNameInfo(BRMConstants.CONTACT_TYPE_PRIMARY, BRMConstants.DEFAULT_ACCOUNT_NAMEINFO[0],
				BRMConstants.DEFAULT_ACCOUNT_NAMEINFO[1], BRMConstants.DEFAULT_ACCOUNT_NAMEINFO[2],
				BRMConstants.DEFAULT_ACCOUNT_NAMEINFO[3]);
		this.buildAccountNameInfo(BRMConstants.CONTACT_TYPE_BILLING, BRMConstants.DEFAULT_ACCOUNT_NAMEINFO[0],
				BRMConstants.DEFAULT_ACCOUNT_NAMEINFO[1], BRMConstants.DEFAULT_ACCOUNT_NAMEINFO[2],
				BRMConstants.DEFAULT_ACCOUNT_NAMEINFO[3]);
	}
	

	
	private void setCloudAccountNumber(Account account) {
        String cloudAccountNumber = null;
        switch (account.getAccountType()) {
        case US_CLOUD:
               cloudAccountNumber = AccountConstants.US_CLOUD_ACCOUNT_PREFIX + account.getTenantId();
               account.setAccountNumber(cloudAccountNumber);
               break;
       case UK_CLOUD:
               cloudAccountNumber = AccountConstants.UK_CLOUD_ACCOUNT_PREFIX + account.getTenantId();
               account.setAccountNumber(cloudAccountNumber);
               break;
       case DEDICATED: //DO NOTHING, ACCOUNT NUMBER WILL BE CREATED SYSTEMATICALLY
               cloudAccountNumber = AccountConstants.DEDICATED_ACCOUNT_PREFIX + account.getTenantId();
               account.setAccountNumber(cloudAccountNumber);
               break;
        default:
               cloudAccountNumber = AccountConstants.US_CLOUD_ACCOUNT_PREFIX + account.getTenantId();
               break;
        }
 }


	/**
	 * Sets the billing segment.
	 *
	 * @param accountType the account type
	 * @param accountBillInfo the account bill info
	 */
	private void setBillingSegment(AccountType accountType, AccountBillInfo accountBillInfo) {
		switch (accountType) {
		case DEDICATED:
			accountBillInfo.setBillingSegment(BillingSegment.DEDICATED.getBillingSegment());
			break;
		case US_CLOUD:       
			accountBillInfo.setBillingSegment(BillingSegment.US_CLOUD.getBillingSegment());
			break;
		case UK_CLOUD:
			accountBillInfo.setBillingSegment(BillingSegment.UK_CLOUD.getBillingSegment());
			break;
		default:
			accountBillInfo.setBillingSegment(BillingSegment.US_CLOUD.getBillingSegment());
			break;
		}
	}

	/**
	 * Sets the GL segment.
	 *
	 * @param accountType the new GL segment
	 */
	private void setGLSegment(AccountType accountType) {
		switch (accountType) {
		case DEDICATED:
			account.setGlSegment(GLSegment.DEDICATED.getGLSegment());
			break;
		case US_CLOUD:
			account.setGlSegment(GLSegment.US_CLOUD.getGLSegment());
			break;
		case UK_CLOUD:
			account.setGlSegment(GLSegment.UK_CLOUD.getGLSegment());
			break;
		default:
			account.setGlSegment(GLSegment.US_CLOUD.getGLSegment());
			break;
		}
	}

	/**
	 * Builds the account profile.
	 *
	 * @param coreAcctNumber the core acct number
	 * @param optinFlag the optin flag
	 * @param contractingEntity the contracting entity
	 * @param supportTeam the support team
	 * @param vatNumber the vat number
	 * @param paperlessMemo the paperless memo
	 * @param paperlessInvoiceFlag the paperless invoice flag
	 * @param emailInvOptinFlag the email inv optin flag
	 * @param paymentTerm the payment term
	 */
	private void buildAccountProfile(String coreAcctNumber, String optinFlag, String contractingEntity,
			String supportTeam, String vatNumber, String paperlessMemo, String paperlessInvoiceFlag,
			String emailInvOptinFlag, String paymentTerm) {

		AccountProfile accountProfile = new AccountProfile();
		accountProfile.setCoreAccountNumber(coreAcctNumber);
		accountProfile.setOptinFlag(optinFlag);
		accountProfile.setContractingEntity(contractingEntity);
		accountProfile.setSupportTeam(supportTeam);
		accountProfile.setVatNumber(vatNumber);
		accountProfile.setPaperlessMemoFlag(paperlessMemo);
		accountProfile.setPaperlessInvoiceFlag(paperlessInvoiceFlag);
		accountProfile.setEmailInvoiceOptinFlag(emailInvOptinFlag);
		accountProfile.setPaymentTerm(paymentTerm);
		account.setAccountProfile(accountProfile);
	}

	/**
	 * Builds the bill info.
	 *
	 * @param accountType the account type
	 * @param payType the pay type
	 */
	private void buildBillInfo(AccountType accountType, String payType) {
		AccountBillInfo billinfo = new AccountBillInfo();
		billinfo.setPayType(payType);
		this.setBillingSegment(accountType, billinfo);
		account.getAccBillInfoList().add(billinfo);
	}

	/**
	 * Builds the payinfo.
	 *
	 * @param payType the pay type
	 * @param paymentType the payment type
	 */
	private void buildPayinfo(String payType, String paymentType) {
		AccountPayInfo accountPayinfo = new AccountPayInfo();
		accountPayinfo.setPayType(payType);
	//	accountPayinfo.setPaymentOffset(PropertyUtil.getCommonProperties().getProperty(BRMConstants.PAYMENT_OFFSET));
	//	accountPayinfo.setName(PropertyUtil.getCommonProperties().getProperty(BRMConstants.PROGRAM_NAME));
		accountPayinfo.setPaymentType(paymentType);
		account.getPayinfoList().add(accountPayinfo);
	}

	/**
	 * Builds the account name info.
	 *
	 * @param contactType the contact type
	 * @param city the city
	 * @param state the state
	 * @param zip the zip
	 * @param country the country
	 */
	private void buildAccountNameInfo(String contactType, String city, String state, String zip, String country) {
		AccountNameInfo accountNameinfo = new AccountNameInfo();
		accountNameinfo.setContactType(contactType);
		accountNameinfo.setCity(city);
		accountNameinfo.setState(state);
		accountNameinfo.setZip(zip);
		accountNameinfo.setCountry(country);
		account.getAccountNameInfoList().add(accountNameinfo);
	}

	/**
	 * Gets the account.
	 *
	 * @return the account
	 */
	public Account getAccount() {
		return this.account;
	}

	/**
	 * The main method.
	 *
	 * @param args the arguments
	 * @throws Exception the exception
	 */
	public static void main(String[] args) throws Exception {
		/*
		 * AccountBuilder builder = new
		 * AccountBuilder(AccountType.DEDICATED,"12345","840","10001","0","100",
		 * "1","890","1004"); Account account = builder.getAccount();
		 * System.out.println("Currency:" + account.getCurrency());
		 * System.out.println("Bill Segment:" + account.getBillingSegment());
		 * System.out.println("Currency:" + account.getCurrency());
		 */
	}
}
