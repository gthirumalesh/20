package com.rackspace.brm.account.model;

public class AccountBill {

	protected String billObj = null;
	protected String bill_no = null;

	protected double adjusted = 0.0d;
	protected double currentTotal = 0.0d;
	protected double disputed = 0.0d;
	protected double due = 0.0d;
	protected double previousTotal = 0.0d;
	protected double recvd = 0.0d;
	protected double subordTotal = 0.0d;
	protected double totalDue = 0.0d;
	protected double transfered = 0.0d;
	protected double writeOff = 0.0d;

	protected long startT = 0l;
	protected long dueT = 0l;
	protected long endT = 0l;

	protected AccountInvoice invoice = null;

	public String getBillObj() {
		return billObj;
	}

	public void setBillObj(String billObj) {
		this.billObj = billObj;
	}

	public String getBill_no() {
		return bill_no;
	}

	public void setBill_no(String bill_no) {
		this.bill_no = bill_no;
	}

	public double getAdjusted() {
		return adjusted;
	}

	public void setAdjusted(double adjusted) {
		this.adjusted = adjusted;
	}

	public double getCurrentTotal() {
		return currentTotal;
	}

	public void setCurrentTotal(double currentTotal) {
		this.currentTotal = currentTotal;
	}

	public double getDisputed() {
		return disputed;
	}

	public void setDisputed(double disputed) {
		this.disputed = disputed;
	}

	public double getDue() {
		return due;
	}

	public void setDue(double due) {
		this.due = due;
	}

	public double getPreviousTotal() {
		return previousTotal;
	}

	public void setPreviousTotal(double previousTotal) {
		this.previousTotal = previousTotal;
	}

	public double getRecvd() {
		return recvd;
	}

	public void setRecvd(double recvd) {
		this.recvd = recvd;
	}

	public double getSubordTotal() {
		return subordTotal;
	}

	public void setSubordTotal(double subordTotal) {
		this.subordTotal = subordTotal;
	}

	public double getTotalDue() {
		return totalDue;
	}

	public void setTotalDue(double totalDue) {
		this.totalDue = totalDue;
	}

	public double getTransfered() {
		return transfered;
	}

	public void setTransfered(double transfered) {
		this.transfered = transfered;
	}

	public double getWriteOff() {
		return writeOff;
	}

	public void setWriteOff(double writeOff) {
		this.writeOff = writeOff;
	}

	public long getStartT() {
		return startT;
	}

	public void setStartT(long startT) {
		this.startT = startT;
	}

	public long getDueT() {
		return dueT;
	}

	public void setDueT(long dueT) {
		this.dueT = dueT;
	}

	public long getEndT() {
		return endT;
	}

	public void setEndT(long endT) {
		this.endT = endT;
	}

	public AccountInvoice getInvoice() {
		return invoice;
	}

	public void setInvoice(AccountInvoice invoice) {
		this.invoice = invoice;
	}

}
