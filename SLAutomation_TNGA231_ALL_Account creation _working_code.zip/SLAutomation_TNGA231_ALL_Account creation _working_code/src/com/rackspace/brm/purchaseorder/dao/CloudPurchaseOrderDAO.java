package com.rackspace.brm.purchaseorder.dao;

/**
 * The Class CloudPurchaseOrderDAO.
 */
public class CloudPurchaseOrderDAO {

}
