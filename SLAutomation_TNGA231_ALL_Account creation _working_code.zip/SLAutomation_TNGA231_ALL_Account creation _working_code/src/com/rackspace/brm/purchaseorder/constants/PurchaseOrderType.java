package com.rackspace.brm.purchaseorder.constants;

/**
 * The ENUM PurchaseOrderType.
 */
public enum PurchaseOrderType {

	DEDICATED, CLOUD
}
