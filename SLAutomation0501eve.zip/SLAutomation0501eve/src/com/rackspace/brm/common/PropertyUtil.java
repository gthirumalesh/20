/**
 * 
 */
package com.rackspace.brm.common;

import java.io.FileInputStream;
import java.util.Properties;

/**
 * Static class to hold the property object.
 *
 */
public class PropertyUtil {

	private static Properties commonProperties = null;
	private static Properties infranetProperties = null;
	private static Properties bslProperties = null;

	static {
		try {
			FileInputStream commonfs = new FileInputStream("common.properties");
			commonProperties = new Properties();
			commonProperties.load(commonfs);

			FileInputStream inframetfs = new FileInputStream("Infranet.properties");
			infranetProperties = new Properties();
			infranetProperties.load(inframetfs);

			FileInputStream bslfs = new FileInputStream("bsl.properties");
			bslProperties = new Properties();
			bslProperties.load(bslfs);

		} catch (Exception exception) {
			//Utils.APP_LOGS.error("Error occured while attempting to load properties", exception);
		}
	}

	public static Properties getCommonProperties() {
		return commonProperties;
	}

	public static Properties getInfranetProperties() {
		return infranetProperties;
	}

	public static Properties getBslProperties() {
		return bslProperties;
	}
	
public static void main (String args[]){

		
		System.out.println(
				getBslProperties().getProperty("abcd"));

	}

}
