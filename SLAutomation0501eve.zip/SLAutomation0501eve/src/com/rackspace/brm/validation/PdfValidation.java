package com.rackspace.brm.validation;

import org.testng.Assert;

import com.rackspace.brm.account.model.AccountInvoice;
import com.rackspace.brm.common.Utils;
import com.rackspace.brm.constants.BRMConstants;

public class PdfValidation {

	public static void validatePdfStatus(String billNumber) throws Exception {

		try {
			Utils.APP_LOGS.info("Enter:validatePdfStatus()");

			String pdfStatus = Utils.retrieveDetailsFromDB("pdfStatusQuery", billNumber);
			int pdfStatusValue = Integer.parseInt(pdfStatus);

			if (pdfStatusValue == 1) {

				Assert.assertNotNull(pdfStatusValue);

			} else {
				Assert.fail("Pdf status not generated");
			}

		} catch (Exception e) {
			Utils.APP_LOGS.error("Pdf Status not validated" + e);
		}

		Utils.APP_LOGS.info("Exit:validatePdfStatus()");

	}

	/*
	 * public static void validatePdfFields(String... pdfValues) {
	 * 
	 * InvoicePdfParser invoicePdfParser = new InvoicePdfParser();
	 * 
	 * 
	 * 
	 * AccountInvoice accountInvoice = new AccountInvoice();
	 * 
	 * 
	 * System.out.println("pdfValues[1], accountInvoice.getAccountNumber()"
	 * +pdfValues[0]+", " +accountInvoice.getAccountNumber());
	 * System.out.println("pdfValues[2], accountInvoice.getCustomerNumber()"
	 * +pdfValues[1]+", " + accountInvoice.getCustomerNumber());
	 * System.out.println("pdfValues[3], accountInvoice.getInvoiceNumber()"
	 * +pdfValues[2]+", " + accountInvoice.getInvoiceNumber());
	 * System.out.println("pdfValues[4], accountInvoice.getInvoiceDate()"
	 * +pdfValues[3]+", " + accountInvoice.getInvoiceDate());
	 * System.out.println(
	 * "BRMConstants.currencySymbol(pdfValues[5]), accountInvoice.getCurrency()"
	 * +BRMConstants.currencySymbol(pdfValues[4])+", " +
	 * accountInvoice.getCurrency());
	 * 
	 * System.out.println("pdfValues[6], accountInvoice.getTotalGross()"
	 * +pdfValues[5]+", " + accountInvoice.getTotalGross()); System.out.println(
	 * "pdfValues[7], accountInvoice.getTotalDiscount()"+pdfValues[6]+", " +
	 * accountInvoice.getTotalDiscount()); System.out.println(
	 * "pdfValues[8], accountInvoice.getTotalNetCharge()"+pdfValues[7]+", "
	 * +accountInvoice.getTotalNetCharge()); System.out.println(
	 * "pdfValues[9], accountInvoice.getTotalTaxAmount()"+pdfValues[8]+", " +
	 * accountInvoice.getTotalTaxAmount());
	 * 
	 * System.out.println("pdfValues[10], accountInvoice.getTotalCharges()"
	 * +pdfValues[9]+", " + accountInvoice.getTotalCharges());
	 * 
	 * Assert.assertEquals(pdfValues[0], accountInvoice.getAccountNumber());
	 * Assert.assertEquals(pdfValues[1], accountInvoice.getCustomerNumber());
	 * Assert.assertEquals(pdfValues[2], accountInvoice.getInvoiceNumber());
	 * Assert.assertEquals(pdfValues[3], accountInvoice.getInvoiceDate());
	 * Assert.assertEquals(BRMConstants.currencySymbol(pdfValues[4]),
	 * accountInvoice.getCurrency()); Assert.assertEquals(pdfValues[5],
	 * accountInvoice.getTotalGross()); Assert.assertEquals(pdfValues[6],
	 * accountInvoice.getTotalDiscount()); Assert.assertEquals(pdfValues[7],
	 * accountInvoice.getTotalNetCharge()); Assert.assertEquals(pdfValues[8],
	 * accountInvoice.getTotalTaxAmount()); Assert.assertEquals(pdfValues[9],
	 * accountInvoice.getTotalCharges());
	 * 
	 * 
	 * 
	 * }
	 */

	public static void validateInvoice(AccountInvoice invObject, String... validateParameters) {
		/*
		 * System.out.println("pdf assertion"); System.out.println(
		 * "invObject.getAccountNumber(), validateParameters[0]"
		 * +invObject.getAccountNumber() +", "+ validateParameters[0]);
		 * System.out.println(
		 * "invObject.getCustomerNumber(), validateParameters[1]"
		 * +invObject.getCustomerNumber()+", "+ validateParameters[1]);
		 * System.out.println(
		 * "invObject.getInvoiceNumber(), validateParameters[2]"
		 * +invObject.getInvoiceNumber()+", "+ validateParameters[2]);
		 * System.out.println(
		 * "invObject.getInvoiceDate(), validateParameters[3]"
		 * +invObject.getInvoiceDate()+", "+ validateParameters[3]);
		 * System.out.println(
		 * "invObject.getCurrency(), BRMConstants.currencySymbol(validateParameters[4])"
		 * +invObject.getCurrency()+", "+
		 * BRMConstants.currencySymbol(validateParameters[4]));
		 * System.out.println(
		 * "invObject.getInvoiceAmountDue(), validateParameters[5]"
		 * +invObject.getInvoiceAmountDue()+", "+ validateParameters[5]);
		 */
		Assert.assertEquals(invObject.getAccountNumber(), validateParameters[0]);
		Assert.assertEquals(invObject.getCustomerNumber(), validateParameters[1]);
		Assert.assertEquals(invObject.getInvoiceNumber(), validateParameters[2]);
		Assert.assertEquals(invObject.getInvoiceDate(), validateParameters[3]);
		Assert.assertEquals(invObject.getCurrency(), BRMConstants.currencySymbol(validateParameters[4]));
		Assert.assertEquals(invObject.getInvoiceAmountDue(), validateParameters[5]);

	}

}
