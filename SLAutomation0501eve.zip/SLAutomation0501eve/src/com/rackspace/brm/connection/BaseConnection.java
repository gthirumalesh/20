package com.rackspace.brm.connection;

/**
 * The Class BaseConnection.
 */
public abstract class BaseConnection {

	/**
	 * Instantiates a new base connection.
	 */
	public BaseConnection() {
	}

}
