
package com.rackspace.sl.rbacprofile.model;

import java.util.List;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/**
 * The Class User.
 */
public class User {

    /** The r AXAUTH session inactivity timeout. */
    @SerializedName("RAX-AUTH:sessionInactivityTimeout")
    @Expose
    private String rAXAUTHSessionInactivityTimeout;
    
    /** The r AXAUTH default region. */
    @SerializedName("RAX-AUTH:defaultRegion")
    @Expose
    private String rAXAUTHDefaultRegion;
    
    /** The roles. */
    @SerializedName("roles")
    @Expose
    private List<Role> roles = null;
    
    /** The name. */
    @SerializedName("name")
    @Expose
    private String name;
    
    /** The id. */
    @SerializedName("id")
    @Expose
    private String id;

    /**
     * Gets the RAXAUTH session inactivity timeout.
     *
     * @return the RAXAUTH session inactivity timeout
     */
    public String getRAXAUTHSessionInactivityTimeout() {
        return rAXAUTHSessionInactivityTimeout;
    }

    /**
     * Sets the RAXAUTH session inactivity timeout.
     *
     * @param rAXAUTHSessionInactivityTimeout the new RAXAUTH session inactivity timeout
     */
    public void setRAXAUTHSessionInactivityTimeout(String rAXAUTHSessionInactivityTimeout) {
        this.rAXAUTHSessionInactivityTimeout = rAXAUTHSessionInactivityTimeout;
    }

    /**
     * Gets the RAXAUTH default region.
     *
     * @return the RAXAUTH default region
     */
    public String getRAXAUTHDefaultRegion() {
        return rAXAUTHDefaultRegion;
    }

    /**
     * Sets the RAXAUTH default region.
     *
     * @param rAXAUTHDefaultRegion the new RAXAUTH default region
     */
    public void setRAXAUTHDefaultRegion(String rAXAUTHDefaultRegion) {
        this.rAXAUTHDefaultRegion = rAXAUTHDefaultRegion;
    }

    /**
     * Gets the roles.
     *
     * @return the roles
     */
    public List<Role> getRoles() {
        return roles;
    }

    /**
     * Sets the roles.
     *
     * @param roles the new roles
     */
    public void setRoles(List<Role> roles) {
        this.roles = roles;
    }

    /**
     * Gets the name.
     *
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the name.
     *
     * @param name the new name
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * Gets the id.
     *
     * @return the id
     */
    public String getId() {
        return id;
    }

    /**
     * Sets the id.
     *
     * @param id the new id
     */
    public void setId(String id) {
        this.id = id;
    }

}
